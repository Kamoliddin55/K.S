ZENO — telefonga o'rnatish

1) Android Studio'ni oching: File > Open > shu "ZenoApp" papkasini tanlang.
2) Gradle sinxronlanishini kuting (birinchi marta bir necha daqiqa, internet kerak).
3) Telefonda: Sozlamalar > Telefon haqida > "Build raqami"ni 7 marta bosing,
   so'ng Dasturchi sozlamalari > "USB orqali nosozliklarni tuzatish"ni yoqing.
4) Telefonni USB bilan ulang, ruxsat bering, Android Studio'da yashil ▶ (Run) tugmasini bosing.

APK fayl olish (boshqa telefonga yuborish uchun):
   Build > Build Bundle(s) / APK(s) > Build APK(s)
   Fayl: app/build/outputs/apk/debug/app-debug.apk
   Telefonda faylni oching va "Noma'lum manbalardan o'rnatish"ga ruxsat bering.

Birinchi ishga tushirgandan keyin: Sozlamalar (menyu) ichida bildirishnoma,
foydalanish statistikasi, batareya cheklovi va avtostart ruxsatlarini yoqing.

KOMPYUTERSIZ (faqat telefon bilan):
1) github.com'da bepul akkaunt oching, yangi repository yarating.
2) "Add file > Upload files" orqali shu papkadagi hamma fayllarni (.github papkasi bilan) yuklang.
3) "Actions" bo'limiga kiring, "APK yig'ish" ishini kuting (5-10 daqiqa).
4) Tugagach, ish ichidagi "Zeno-APK" faylini yuklab oling, zipdan chiqarib, app-debug.apk ni o'rnating.
