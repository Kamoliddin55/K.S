package com.zeno.virtualfriend

import android.Manifest
import android.app.AlarmManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequest
import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.random.Random
import org.json.JSONArray
import org.json.JSONObject

// ======================== ZenoDb.kt ========================
data class Mem(val id: Long, val category: String, val text: String)
data class Goal(val id: Long, val title: String)
data class Workout(val day: String, val note: String, val amount: Int)

object Util {
    fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    fun todayDots(): String = SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date())
    fun hour(): Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    fun midnight(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}

class ZenoDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "zeno.db", null, 1) {

    companion object {
        @Volatile private var inst: ZenoDb? = null
        fun get(ctx: Context): ZenoDb = inst ?: synchronized(this) {
            inst ?: ZenoDb(ctx.applicationContext).also { inst = it }
        }
        private const val MAX_MEMORIES = 300
        private const val MAX_CHAT = 60
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE memories(id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT, text TEXT, norm TEXT UNIQUE, ts INTEGER)")
        db.execSQL("CREATE TABLE goals(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, done INTEGER DEFAULT 0, ts INTEGER)")
        db.execSQL("CREATE TABLE workouts(id INTEGER PRIMARY KEY AUTOINCREMENT, day TEXT, note TEXT, amount INTEGER, ts INTEGER)")
        db.execSQL("CREATE TABLE style_days(day TEXT PRIMARY KEY, n INTEGER, sum REAL)")
        db.execSQL("CREATE TABLE notif_log(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, kind TEXT, text TEXT)")
        db.execSQL("CREATE TABLE usage_alerts(day TEXT, pkg TEXT, threshold INTEGER, PRIMARY KEY(day, pkg, threshold))")
        db.execSQL("CREATE TABLE chat(id INTEGER PRIMARY KEY AUTOINCREMENT, who TEXT, text TEXT, ts INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    // ---------- Xotira ----------
    fun addMemory(category: String, text: String): Boolean {
        val clean = text.trim().take(160)
        if (clean.isEmpty()) return false
        val norm = clean.lowercase().replace(Regex("\\s+"), " ")
        val cv = ContentValues().apply {
            put("category", category); put("text", clean)
            put("norm", norm); put("ts", System.currentTimeMillis())
        }
        val id = writableDatabase.insertWithOnConflict("memories", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        if (id != -1L) {
            // eski yozuvlarni siqish: faqat oxirgi MAX_MEMORIES ta qoladi
            writableDatabase.execSQL(
                "DELETE FROM memories WHERE id NOT IN (SELECT id FROM memories ORDER BY id DESC LIMIT $MAX_MEMORIES)"
            )
        }
        return id != -1L
    }

    fun memories(): List<Mem> = readableDatabase.rawQuery(
        "SELECT id, category, text FROM memories ORDER BY id DESC", null
    ).use { c ->
        val out = ArrayList<Mem>()
        while (c.moveToNext()) out.add(Mem(c.getLong(0), c.getString(1), c.getString(2)))
        out
    }

    fun deleteMemory(id: Long): Boolean =
        writableDatabase.delete("memories", "id=?", arrayOf(id.toString())) > 0

    fun clearAll() {
        val d = writableDatabase
        listOf("memories", "goals", "workouts", "style_days", "chat").forEach { d.execSQL("DELETE FROM $it") }
    }

    // ---------- Maqsadlar ----------
    fun addGoal(title: String): Long {
        val cv = ContentValues().apply {
            put("title", title.trim().take(120)); put("done", 0); put("ts", System.currentTimeMillis())
        }
        return writableDatabase.insert("goals", null, cv)
    }

    fun openGoals(): List<Goal> = readableDatabase.rawQuery(
        "SELECT id, title FROM goals WHERE done=0 ORDER BY id", null
    ).use { c ->
        val out = ArrayList<Goal>()
        while (c.moveToNext()) out.add(Goal(c.getLong(0), c.getString(1)))
        out
    }

    fun completeGoal(id: Long): String? {
        val title = readableDatabase.rawQuery(
            "SELECT title FROM goals WHERE id=? AND done=0", arrayOf(id.toString())
        ).use { if (it.moveToFirst()) it.getString(0) else null } ?: return null
        val cv = ContentValues().apply { put("done", 1) }
        writableDatabase.update("goals", cv, "id=?", arrayOf(id.toString()))
        return title
    }

    // ---------- Mashg'ulotlar ----------
    fun addWorkout(note: String, amount: Int) {
        val cv = ContentValues().apply {
            put("day", Util.today()); put("note", note); put("amount", amount)
            put("ts", System.currentTimeMillis())
        }
        writableDatabase.insert("workouts", null, cv)
    }

    fun lastWorkout(): Workout? = readableDatabase.rawQuery(
        "SELECT day, note, amount FROM workouts ORDER BY id DESC LIMIT 1", null
    ).use { if (it.moveToFirst()) Workout(it.getString(0), it.getString(1), it.getInt(2)) else null }

    fun recentWorkouts(limit: Int): List<Workout> = readableDatabase.rawQuery(
        "SELECT day, note, amount FROM workouts ORDER BY id DESC LIMIT $limit", null
    ).use { c ->
        val out = ArrayList<Workout>()
        while (c.moveToNext()) out.add(Workout(c.getString(0), c.getString(1), c.getInt(2)))
        out
    }

    fun workoutCount(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM workouts", null)
        .use { if (it.moveToFirst()) it.getInt(0) else 0 }

    // ---------- Muloqot uslubi statistikasi ----------
    fun addStyleSample(score: Double) {
        val day = Util.today()
        val row = readableDatabase.rawQuery("SELECT n, sum FROM style_days WHERE day=?", arrayOf(day))
            .use { if (it.moveToFirst()) Pair(it.getInt(0), it.getDouble(1)) else null }
        val cv = ContentValues().apply {
            put("day", day)
            put("n", (row?.first ?: 0) + 1)
            put("sum", (row?.second ?: 0.0) + score)
        }
        writableDatabase.insertWithOnConflict("style_days", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    /** (xabarlar soni, ball yig'indisi) — oxirgi `limit` kun, bugun ham kiradi */
    fun styleDays(limit: Int): List<Pair<Int, Double>> = readableDatabase.rawQuery(
        "SELECT n, sum FROM style_days ORDER BY day DESC LIMIT $limit", null
    ).use { c ->
        val out = ArrayList<Pair<Int, Double>>()
        while (c.moveToNext()) out.add(Pair(c.getInt(0), c.getDouble(1)))
        out
    }

    // ---------- Bildirishnomalar jurnali ----------
    fun logNotif(kind: String, text: String) {
        val cv = ContentValues().apply {
            put("ts", System.currentTimeMillis()); put("kind", kind); put("text", text)
        }
        writableDatabase.insert("notif_log", null, cv)
    }

    /** Kunlik limitga "inactive" (suhbat taklifi) kirmaydi — u alohida hisoblanadi */
    fun notifCountToday(): Int = readableDatabase.rawQuery(
        "SELECT COUNT(*) FROM notif_log WHERE ts>=? AND kind NOT IN ('inactive','test')", arrayOf(Util.midnight().toString())
    ).use { if (it.moveToFirst()) it.getInt(0) else 0 }

    fun recentNotifTexts(limit: Int): Set<String> = readableDatabase.rawQuery(
        "SELECT text FROM notif_log ORDER BY id DESC LIMIT $limit", null
    ).use { c ->
        val out = HashSet<String>()
        while (c.moveToNext()) out.add(c.getString(0))
        out
    }

    fun lastNotifTs(kind: String): Long = readableDatabase.rawQuery(
        "SELECT MAX(ts) FROM notif_log WHERE kind=?", arrayOf(kind)
    ).use { if (it.moveToFirst()) it.getLong(0) else 0L }

    fun prune() {
        val d = writableDatabase
        val weekAgo = System.currentTimeMillis() - 14L * 24 * 3600 * 1000
        d.execSQL("DELETE FROM notif_log WHERE ts < $weekAgo")
        d.execSQL("DELETE FROM usage_alerts WHERE day < ?", arrayOf(Util.today()))
        d.execSQL("DELETE FROM style_days WHERE day NOT IN (SELECT day FROM style_days ORDER BY day DESC LIMIT 30)")
    }

    // ---------- Ilova vaqti ogohlantirishlari ----------
    fun usageAlertSent(day: String, pkg: String, t: Int): Boolean = readableDatabase.rawQuery(
        "SELECT 1 FROM usage_alerts WHERE day=? AND pkg=? AND threshold=?", arrayOf(day, pkg, t.toString())
    ).use { it.moveToFirst() }

    fun markUsageAlert(day: String, pkg: String, t: Int) {
        val cv = ContentValues().apply { put("day", day); put("pkg", pkg); put("threshold", t) }
        writableDatabase.insertWithOnConflict("usage_alerts", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
    }

    // ---------- Suhbat tarixi (oxirgi MAX_CHAT ta xabar) ----------
    fun addChat(who: String, text: String) {
        val cv = ContentValues().apply { put("who", who); put("text", text); put("ts", System.currentTimeMillis()) }
        writableDatabase.insert("chat", null, cv)
        writableDatabase.execSQL(
            "DELETE FROM chat WHERE id NOT IN (SELECT id FROM chat ORDER BY id DESC LIMIT $MAX_CHAT)"
        )
    }

    fun recentChat(): List<Pair<String, String>> = readableDatabase.rawQuery(
        "SELECT who, text FROM (SELECT id, who, text FROM chat ORDER BY id DESC LIMIT $MAX_CHAT) ORDER BY id ASC", null
    ).use { c ->
        val out = ArrayList<Pair<String, String>>()
        while (c.moveToNext()) out.add(Pair(c.getString(0), c.getString(1)))
        out
    }
}

// ======================== ZenoPrefs.kt ========================
data class TrackedApp(
    val pkg: String,
    val label: String,
    val enabled: Boolean,
    val thresholds: List<Int>
)

class ZenoPrefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("zeno_prefs", Context.MODE_PRIVATE)

    var lastActive: Long
        get() {
            val v = sp.getLong("last_active", 0L)
            if (v != 0L) return v
            val now = System.currentTimeMillis()
            sp.edit().putLong("last_active", now).apply()
            return now
        }
        set(v) { sp.edit().putLong("last_active", v).apply() }

    var dailyCap: Int
        get() = sp.getInt("cap", 15)
        set(v) { sp.edit().putInt("cap", v).apply() }

    var quietStart: Int
        get() = sp.getInt("quiet_start", 23)
        set(v) { sp.edit().putInt("quiet_start", v).apply() }

    var quietEnd: Int
        get() = sp.getInt("quiet_end", 7)
        set(v) { sp.edit().putInt("quiet_end", v).apply() }

    var inactivityNudges: Boolean
        get() = sp.getBoolean("inactivity", true)
        set(v) { sp.edit().putBoolean("inactivity", v).apply() }

    var motivation: Boolean
        get() = sp.getBoolean("motivation", true)
        set(v) { sp.edit().putBoolean("motivation", v).apply() }

    var usageTracking: Boolean
        get() = sp.getBoolean("usage_tracking", true)
        set(v) { sp.edit().putBoolean("usage_tracking", v).apply() }

    var pausedUntil: Long
        get() = sp.getLong("paused_until", 0L)
        set(v) { sp.edit().putLong("paused_until", v).apply() }

    var lastInactivityNudge: Long
        get() = sp.getLong("last_inactivity_nudge", 0L)
        set(v) { sp.edit().putLong("last_inactivity_nudge", v).apply() }

    /** Doimiy fon xizmati (ishonchli eslatmalar uchun) */
    var keepAlive: Boolean
        get() = sp.getBoolean("keep_alive", true)
        set(v) { sp.edit().putBoolean("keep_alive", v).apply() }

    var lastTick: Long
        get() = sp.getLong("last_tick", 0L)
        set(v) { sp.edit().putLong("last_tick", v).apply() }

    /** "auto" | "neutral" | "serious" | "playful" */
    var styleMode: String
        get() = sp.getString("style_mode", "auto") ?: "auto"
        set(v) { sp.edit().putString("style_mode", v).apply() }

    fun tracked(): List<TrackedApp> {
        val s = sp.getString("tracked", null) ?: return presets()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val t = o.getJSONArray("t")
                TrackedApp(
                    o.getString("pkg"), o.getString("label"), o.getBoolean("on"),
                    (0 until t.length()).map { t.getInt(it) }
                )
            }
        } catch (e: Exception) {
            presets()
        }
    }

    fun saveTracked(list: List<TrackedApp>) {
        val a = JSONArray()
        list.forEach {
            a.put(
                JSONObject()
                    .put("pkg", it.pkg).put("label", it.label).put("on", it.enabled)
                    .put("t", JSONArray(it.thresholds))
            )
        }
        sp.edit().putString("tracked", a.toString()).apply()
    }

    private fun presets(): List<TrackedApp> {
        val d = listOf(30, 60, 90)
        return listOf(
            TrackedApp("com.mobile.legends", "Mobile Legends", false, d),
            TrackedApp("com.instagram.android", "Instagram", false, d),
            TrackedApp("com.google.android.youtube", "YouTube", false, d),
            TrackedApp("org.telegram.messenger", "Telegram", false, d),
            TrackedApp("com.mojang.minecraftpe", "Minecraft", false, d)
        )
    }
}

// ======================== ZenoBrain.kt ========================
enum class Tone { PLAYFUL, NEUTRAL, SERIOUS }

/** Tayyor jumlalar banki. pick() ketma-ket bir xil jumlani qaytarmaydi. */
object Msg {
    private val last = HashMap<String, Int>()

    fun pick(key: String, list: List<String>): String {
        if (list.size == 1) return list[0]
        var i = Random.nextInt(list.size)
        if (i == last[key]) i = (i + 1) % list.size
        last[key] = i
        return list[i]
    }

    val greet = mapOf(
        Tone.PLAYFUL to listOf("Qalesan, bro! 😄 Bugun nima gap?", "O‘o, salom! Kayfiyatlar zo‘rmi? 😎", "Salom-salom! Yangilik bormi? 😊"),
        Tone.NEUTRAL to listOf("Salom! Bugun qanday o‘tyapti?", "Salom, bro. Eshitaman — nima yangilik?", "Salom! Reja yoki mashg‘ulotlar haqida gaplashamizmi?"),
        Tone.SERIOUS to listOf("Salom. Eshitaman.", "Salom. Bugun nimadan boshlaymiz?")
    )
    val ack = mapOf(
        Tone.PLAYFUL to listOf("Hmm, qiziq-ku 😄 Yana aytchi.", "Tushundim, bro 😎 Davom et!", "Ha-ha, mayli! Keyin nima bo‘ldi?"),
        Tone.NEUTRAL to listOf("Tushundim. Davom ettir, eshitaman.", "Mayli, buni yodda tutaman. Yana nima bor?", "Ha, tushundim. Bu haqda ko‘proq aytib bera olasanmi?"),
        Tone.SERIOUS to listOf("Tushundim.", "Eshitdim. Davom ettir.")
    )
    val thanks = listOf("Arzimaydi, bro 🙂", "Doim tayyorman.", "Marhamat! Yana kerak bo‘lsam, yoz.")
    val support = listOf(
        "Ko‘rinishidan bugun og‘irroq kun bo‘lganga o‘xshaydi. Xohlasang, gaplashamiz; xohlamasang, shunchaki shu yerdaman.",
        "Bunaqa kunlar bo‘ladi. Biroz dam olib ko‘rsang-chi? Xohlasang, nima bo‘lganini aytib ber."
    )
    val noAnswer = listOf(
        "Bu savolga aniq javob topa olmadim — hozircha menda faqat telefondagi qoidalar va xotira bor. Boshqacharoq aytib ko‘rasanmi?",
        "Buni hozir ishonchli aytolmayman (internetsiz bilimim cheklangan). Savolni qisqaroq yozsang, urinib ko‘raman."
    )
    val helpCmds = setOf("yordam", "/yordam", "/help", "help", "/start", "menyu", "pomosh", "yordam ber")
    val memoryCmds = setOf("/xotira", "xotira", "xotiram", "eslaganlaring")
    val goalCmds = setOf("maqsadlarim", "maqsadlar", "rejalarim", "rejalar")
    val resultCmds = setOf("natijalarim", "natijalar", "mashqlarim", "mashqlar")
    val greetWords = setOf(
        "salom", "salam", "assalomu", "assalom", "qale", "qalesan", "hayrli",
        "hello", "hi", "hey", "privet", "zdravstvuyte"
    )
    val thanksWords = setOf("rahmat", "raxmat", "tashakkur", "minnatdorman", "thanks", "thank", "spasibo", "sagol")
    val byeWords = setOf("xayr", "hayr", "bay", "bye", "poka", "ko'rishguncha")
    val lowWords = setOf(
        "charchadim", "charchab", "xafaman", "hafaman", "xafa", "hafa", "yomon", "zerikdim",
        "toliqdim", "horib", "qiynalyapman", "qiyin", "tushkunman", "bezorman", "stress"
    )
    val bye = listOf("Xayr, bro! Kerak bo‘lsam, yoz 🙂", "Ko‘rishguncha! Omad.", "Xayr! Yaxshi dam ol.")
    val howAreYou = mapOf(
        Tone.PLAYFUL to listOf("Zo‘rman, bro! 😄 O‘zing qalaysan?", "Ishlar yaxshi 😎 Sendachi?"),
        Tone.NEUTRAL to listOf("Yaxshi, rahmat. O‘zingda nima yangilik?", "Hammasi joyida. Sen qalaysan?"),
        Tone.SERIOUS to listOf("Yaxshi. O‘zing-chi?", "Normal. Eshitaman.")
    )
    const val WHO = "Men Zenoman — telefondagi virtual do‘sting. Maqsadlar, mashq natijalari, xotira va hisob-kitobda yordam beraman. «yordam» deb yozsang, hammasini ko‘rsataman."

    const val HELP = "Men quyidagilarni tushunaman:\n" +
        "• maqsad: <matn> — maqsad qo‘shish\n" +
        "• maqsadlarim — ochiq maqsadlar\n" +
        "• tayyor <raqam> — maqsadni bajarilgan deb belgilash\n" +
        "• mashq: 100 takror — natijani yozish\n" +
        "• natijalarim — oxirgi natijalar\n" +
        "• eslab qol: <matn> — xotiraga yozish\n" +
        "• /xotira — xotirani ko‘rish, /unut <raqam> — o‘chirish\n" +
        "• hisobla 12*(3+4) — hisob-kitob\n" +
        "• /uslub avto|oddiy|jiddiy|quvnoq — muloqot uslubi"

    // Fon bildirishnomalari uchun
    val inactiveShort = "Bro, bugun band bo‘lsang kerak 😅 Vaqting bo‘lsa, keyin gaplashamiz."
    val inactiveLong = "Bro, anchadan beri ko‘rinmaysan-ku 😅 Hammasi yaxshimi? Vaqting bo‘lsa, biroz suhbatlashamiz!"
    val motivNeutral = listOf(
        "Kichik qadam ham qadam. Bugun nimaga vaqt ajratasan?",
        "Dam olish ham rejaning bir qismi. Suv ichib, biroz cho‘zilib ol 🙂",
        "Hozir bir daqiqa to‘xtab, nafas olib ol — keyin yana davom etasan.",
        "Bugun kun qanday o‘tyapti? Xohlasang, yozib qo‘y, gaplashamiz.",
        "Telefondan bosh ko‘tarib, ko‘zlaringga dam berib qo‘y 👀",
        "Bugun boshlagan ishingga 10 daqiqa ajratsang ham yetadi."
    )
    val motivPlayful = listOf(
        "Bro, suv ichdingmi? 💧 Yo‘q bo‘lsa, hoziroq!",
        "Ey, qalaysan? 😄 Bugun nima qilib yuribsan?",
        "Kichik g‘alaba ham g‘alaba 😎 Bugun bittasini qo‘lga kiritamizmi?",
        "Biroz cho‘zilib ol, bro — yelkalar qotib qolmasin 😅",
        "Telefondan bosh ko‘tar-chi, atrofda nimalar bor 👀",
        "Ruhiyat qalay? Gaplashging kelsa, shu yerdaman 🙂"
    )
}

/** Kirill yozuvini lotinga o‘giradi (o‘zbekcha), shunda ikkala yozuvda ham tushunadi. */
object Norm {
    private val cyr = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e", 'ё' to "yo",
        'ж' to "j", 'з' to "z", 'и' to "i", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m",
        'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t", 'у' to "u",
        'ф' to "f", 'х' to "x", 'ц' to "s", 'ч' to "ch", 'ш' to "sh", 'щ' to "sh", 'ъ' to "'",
        'ы' to "i", 'ь' to "", 'э' to "e", 'ю' to "yu", 'я' to "ya", 'ў' to "o'", 'қ' to "q",
        'ғ' to "g'", 'ҳ' to "h"
    )

    fun latin(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            val low = ch.lowercaseChar()
            val m = cyr[low]
            if (m == null) sb.append(ch)
            else sb.append(if (ch != low) m.replaceFirstChar { it.uppercase() } else m)
        }
        return sb.toString()
    }
}

object Calc {
    fun eval(src: String): Double? = try {
        val s = src.replace(',', '.').replace('x', '*').replace('×', '*').replace('÷', '/').replace(" ", "")
        if (s.length > 200) null else P(s).parse().takeIf { it.isFinite() }
    } catch (e: Exception) {
        null
    } catch (e: StackOverflowError) {
        null // juda ko‘p qavs — ilova qulamasin
    }

    fun format(d: Double): String =
        if (d == Math.floor(d) && Math.abs(d) < 1e15) d.toLong().toString()
        else String.format(java.util.Locale.US, "%.6f", d).trimEnd('0').trimEnd('.')

    private class P(val s: String) {
        var i = 0
        fun parse(): Double { val v = expr(); if (i != s.length) throw IllegalArgumentException(); return v }
        fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                val op = s[i++]; val r = term(); v = if (op == '+') v + r else v - r
            }
            return v
        }
        fun term(): Double {
            var v = factor()
            while (i < s.length && (s[i] == '*' || s[i] == '/')) {
                val op = s[i++]; val r = factor()
                if (op == '/' && r == 0.0) throw ArithmeticException()
                v = if (op == '*') v * r else v / r
            }
            return v
        }
        fun factor(): Double {
            if (i < s.length && s[i] == '-') { i++; return -factor() }
            if (i < s.length && s[i] == '(') {
                i++; val v = expr()
                if (i >= s.length || s[i] != ')') throw IllegalArgumentException()
                i++; return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) throw IllegalArgumentException()
            return s.substring(st, i).toDouble()
        }
    }
}

class ZenoBrain(ctx: Context) {
    private val db = ZenoDb.get(ctx)
    private val prefs = ZenoPrefs(ctx)

    companion object {
        /** Joriy suhbatdagi oxirgi 3 xabar balli — faqat shu javob uchun vaqtinchalik kayfiyat */
        private val session = ArrayDeque<Double>()
    }

    // ---------------- Uslub (xarakter) ----------------

    /** Uzoq muddatli uslub: oxirgi 5 kunning o‘rtachasi (kamida 3 kun, kuniga ≥2 xabar). */
    fun baseTone(): Tone {
        when (prefs.styleMode) {
            "serious" -> return Tone.SERIOUS
            "playful" -> return Tone.PLAYFUL
            "neutral" -> return Tone.NEUTRAL
        }
        val days = db.styleDays(5).filter { it.first >= 2 }
        if (days.size < 3) return Tone.NEUTRAL
        val avg = days.sumOf { it.second / it.first } / days.size
        return when {
            avg >= 0.35 -> Tone.PLAYFUL
            avg <= -0.2 -> Tone.SERIOUS
            else -> Tone.NEUTRAL
        }
    }

    /** Bir kunlik kayfiyat umumiy xarakterni o‘zgartirmaydi: faqat shu javobga ta’sir qiladi. */
    private fun effectiveTone(): Tone {
        val base = baseTone()
        if (prefs.styleMode != "auto" || session.size < 3) return base
        if (session.all { it <= -0.5 }) return Tone.SERIOUS
        if (session.all { it >= 1.0 }) return Tone.PLAYFUL
        return base
    }

    private val playfulRe = Regex("(😂|🤣|😄|😅|😁|😎|😜|\\)\\)|haha|xaxa|ahah|lol|hazil)")

    private fun styleScore(lower: String): Double {
        val words = lower.split(Regex("\\s+")).count { it.isNotBlank() }
        return when {
            playfulRe.containsMatchIn(lower) -> 1.0
            words <= 2 && !lower.contains('?') -> -0.5
            else -> 0.0
        }
    }

    // ---------------- Asosiy javob ----------------

    fun respond(raw: String): String {
        val text = raw.trim()
        val lower = Norm.latin(text.lowercase())
            .replace('‘', '\'').replace('’', '\'').replace('ʻ', '\'').replace('ʼ', '\'')
        val ic = RegexOption.IGNORE_CASE
        val cmd = lower.trimEnd('.', '!', '?', ' ')
        // buyruq matnlarini (katta-kichik harf saqlangan holda) lotinga o‘giramiz
        val latinText = Norm.latin(text)
            .replace('‘', '\'').replace('’', '\'').replace('ʻ', '\'').replace('ʼ', '\'')

        // --- buyruqlar ---
        if (cmd in Msg.helpCmds) return Msg.HELP
        if (cmd in Msg.memoryCmds) return memoryList()

        Regex("^/?unut\\s+(\\d+)").find(lower)?.let {
            val ok = it.groupValues[1].toLongOrNull()?.let { id -> db.deleteMemory(id) } ?: false
            return if (ok) "Xotiradan o‘chirdim." else "Bunday raqamli yozuv topilmadi. /xotira orqali tekshirib ko‘r."
        }

        Regex("^/uslub\\s+(\\S+)").find(lower)?.let {
            val mode = when (it.groupValues[1]) {
                "avto", "auto" -> "auto"
                "oddiy" -> "neutral"
                "jiddiy" -> "serious"
                "quvnoq" -> "playful"
                else -> null
            } ?: return "Uslublar: avto, oddiy, jiddiy, quvnoq."
            prefs.styleMode = mode
            return when (mode) {
                "auto" -> "Yaxshi, endi muloqot uslubingga asta-sekin moslashaman."
                "serious" -> "Mayli, jiddiyroq gaplashaman."
                "playful" -> "Bo‘ldi, bro! Endi hazilni ham qo‘shamiz 😄"
                else -> "Oddiy, o‘rtacha uslubga qaytdim."
            }
        }

        Regex("^(?:(?:hisoblab ber|hisobla|hisob|calc)(?!\\p{L})|=(?=\\s*[-\\d(.]))\\s*(.*)$").find(lower)?.let {
            val v = Calc.eval(it.groupValues[1]) ?: return "Buni hisoblay olmadim. Misol: hisobla 12*(3+4)"
            return "= ${Calc.format(v)}"
        }

        Regex("^(maqsadim|maqsad|rejam|reja)(?:\\s*[:\\-]\\s*|\\s+)(.+)$", ic).find(latinText)?.let {
            val title = it.groupValues[2].trim()
            val id = db.addGoal(title)
            return "Maqsad yozildi (#$id): «$title». Bosim yo‘q — qadam-baqadam boramiz."
        }

        if (cmd in Msg.goalCmds) {
            val g = db.openGoals()
            return if (g.isEmpty()) "Hozircha ochiq maqsad yo‘q. «maqsad: ...» deb yozsang, qo‘shaman."
            else g.joinToString("\n", "Ochiq maqsadlaring:\n") { "#${it.id} ${it.title}" } +
                "\n\nBajarsang: tayyor <raqam>"
        }

        Regex("^(?:tayyor|bajarildi|bajardim|done)\\s+#?(\\d+)").find(lower)?.let {
            val t = it.groupValues[1].toLongOrNull()?.let { id -> db.completeGoal(id) }
            return if (t != null) "Zo‘r! «$t» bajarildi deb belgiladim 👏" else "Bunday ochiq maqsad topilmadi. «maqsadlarim» deb ko‘r."
        }

        if (Regex("^mashq(?!\\p{L})").containsMatchIn(lower)) {
            val m = Regex("^mashq[^\\d]*(\\d+)\\s*(.*)$", ic).find(latinText)
                ?: return "Natijani raqam bilan yoz, masalan: «mashq: 100 takror»."
            val amount = m.groupValues[1].toIntOrNull() ?: return "Raqam juda katta chiqdi, qayta yozib ko‘r."
            val note = m.groupValues[2].trim().ifEmpty { "takror" }
            val prev = db.lastWorkout()
            db.addWorkout(note, amount)
            db.addMemory("Mashg‘ulot", "${Util.todayDots()} — Mashg‘ulot: $amount $note")
            val cmp = if (prev != null && prev.note.equals(note, true)) {
                val d = amount - prev.amount
                " Oldingi natija (${prev.day}): ${prev.amount} " + when {
                    d > 0 -> "edi — bu safar $d ta ko‘p."
                    d < 0 -> "edi — bu safar ${-d} ta kam. Hechqisi yo‘q, davom etamiz."
                    else -> "edi — xuddi shuncha."
                }
            } else ""
            return "Yozib qo‘ydim: $amount $note.$cmp"
        }

        if (cmd in Msg.resultCmds) {
            val w = db.recentWorkouts(5)
            return if (w.isEmpty()) "Hali natija yozmagansan. «mashq: 100 takror» deb yozsang, saqlayman."
            else w.joinToString("\n", "Oxirgi natijalar:\n") { "${it.day}: ${it.amount} ${it.note}" }
        }

        Regex("^(?:eslab qol|yodda tut|yozib qo'y|yodla|esla|unutma)(?!\\p{L})\\s*[:\\-]?\\s*(.+)$", ic).find(latinText)?.let {
            val saved = db.addMemory("Muhim", it.groupValues[1])
            return if (saved) "Eslab qoldim. (/xotira orqali ko‘rib, /unut bilan o‘chira olasan.)" else "Buni allaqachon eslab qolgan ekanman."
        }

        // --- oddiy suhbat ---
        val score = styleScore(lower)
        db.addStyleSample(score)
        session.addLast(score)
        if (session.size > 3) session.removeFirst()
        val tone = effectiveTone()

        val words = lower.split(Regex("[^\\p{L}']+")).filter { it.isNotBlank() }

        if (words.any { it in Msg.greetWords }) {
            val g = Msg.pick("greet$tone", Msg.greet.getValue(tone))
            val goals = db.openGoals()
            return if (goals.isNotEmpty() && Random.nextInt(100) < 40)
                "$g\nMaqsadlaringdan biri hali ochiq: «${goals.random().title}» — xohlasang, shuni gaplashamiz."
            else g
        }

        if (words.any { it in Msg.byeWords }) return Msg.pick("bye", Msg.bye)
        if (Regex("(qalaysan|yaxshimisan|ahvol|nima gap|nima yangilik|ishlar qalay)").containsMatchIn(lower))
            return Msg.pick("how$tone", Msg.howAreYou.getValue(tone))
        if (Regex("(isming|kimsan|nima qila olasan|nimalar qila olasan)").containsMatchIn(lower)) return Msg.WHO
        if (words.any { it in Msg.thanksWords })
            return Msg.pick("thanks", Msg.thanks)

        val low = Msg.lowWords
        if (words.any { it in low }) return Msg.pick("support", Msg.support)

        val interest = Regex("(yoqtiraman|qiziqaman|o'ynayman|o'rganyapman|tomosha qilaman|yaxshi ko'raman|sevaman|o'qiyapman|tinglayman)")
        if (interest.containsMatchIn(lower) && text.length <= 120) {
            val saved = db.addMemory("Qiziqish", text)
            val base = Msg.pick("ack$tone", Msg.ack.getValue(tone))
            return if (saved) "$base\n(Buni xotiraga yozib qo‘ydim — /xotira.)" else base
        }

        // oldin aytgan gapiga bog‘liq bo‘lsa, shuni eslatamiz (faqat haqiqiy yozuvlar)
        val stop = setOf(
            "bugun", "qanday", "haqida", "yaxshi", "kerak", "mumkin", "lekin", "chunki", "hozir",
            "keyin", "bilan", "uchun", "menga", "senga", "qilib", "qilyapman", "qilyapsan",
            "bo'ldi", "bo'lsa", "nimani", "qayerda", "qachon", "yana", "juda"
        )
        val keys = words.filter { it.length >= 5 && it !in stop }
        if (keys.isNotEmpty()) {
            val rel = db.memories().firstOrNull { m ->
                m.category != "Mashg‘ulot" && m.text.lowercase()
                    .replace('‘', '\'').replace('’', '\'').replace('ʻ', '\'').replace('ʼ', '\'')
                    .let { t -> keys.any { k -> t.contains(k) } }
            }
            if (rel != null) return "Bu haqda oldin shuni yozib qo‘ygan ekanman: «${rel.text}». Hozir nima o‘zgardi?"
        }

        if (text.contains('?')) return Msg.pick("noAnswer", Msg.noAnswer)
        return Msg.pick("ack$tone", Msg.ack.getValue(tone))
    }

    private fun memoryList(): String {
        val m = db.memories()
        if (m.isEmpty()) return "Hozircha hech narsa eslab qolmadim."
        val shown = m.take(15).joinToString("\n") { "#${it.id} [${it.category}] ${it.text}" }
        val more = if (m.size > 15) "\n… yana ${m.size - 15} ta (Sozlamalarda hammasi ko‘rinadi)" else ""
        return "Xotiramda:\n$shown$more\n\nO‘chirish: /unut <raqam>"
    }
}

// ======================== UsageTracker.kt ========================
object UsageTracker {

    @Suppress("DEPRECATION")
    fun hasAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        } else {
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        }
        // Ba'zi qurilmalarda ruxsat berilgan bo'lsa ham MODE_DEFAULT qaytadi — shunda oddiy ruxsatni tekshiramiz
        return if (mode == AppOpsManager.MODE_DEFAULT) {
            ctx.checkCallingOrSelfPermission(Manifest.permission.PACKAGE_USAGE_STATS) == PackageManager.PERMISSION_GRANTED
        } else {
            mode == AppOpsManager.MODE_ALLOWED
        }
    }

    /**
     * Bugun (soat 00:00 dan hozirgacha) har bir ilovada o'tkazilgan daqiqalar.
     * Faqat `pkgs` ichidagi ilovalar hisoblanadi; boshqa ilovalar yoki ularning ichidagi ma'lumotlar o'qilmaydi.
     * Kun yangilanganda hisob o'z-o'zidan 0 dan boshlanadi, telefon qayta yonsa ham tizim statistikasi saqlanadi.
     */
    fun todayMinutes(ctx: Context, pkgs: Set<String>): Map<String, Long> {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val events = usm.queryEvents(Util.midnight(), end)
        val e = UsageEvents.Event()
        val fg = HashMap<String, Long>()
        val total = HashMap<String, Long>()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val p = e.packageName
            if (p !in pkgs) continue
            when (e.eventType) {
                // 1 = MOVE_TO_FOREGROUND / ACTIVITY_RESUMED
                1 -> if (!fg.containsKey(p)) fg[p] = e.timeStamp
                // 2 = MOVE_TO_BACKGROUND / ACTIVITY_PAUSED
                2 -> fg.remove(p)?.let { total[p] = (total[p] ?: 0L) + (e.timeStamp - it) }
            }
        }
        // hozir ochiq turgan ilova
        fg.forEach { (p, s) -> total[p] = (total[p] ?: 0L) + (end - s) }
        return total.mapValues { it.value / 60000L }
    }
}

// ======================== Notifier.kt ========================
object Notifier {
    private const val CH = "zeno_main"

    /** Bildirishnomani yuboradi va jurnalga yozadi. Bosilganda ilova shu matn bilan suhbatni ochadi. */
    fun send(ctx: Context, kind: String, text: String): Boolean {
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return false

        if (Build.VERSION.SDK_INT >= 26) {
            val m = ctx.getSystemService(NotificationManager::class.java)
            if (m.getNotificationChannel(CH) == null) {
                m.createNotificationChannel(
                    NotificationChannel(CH, "Zeno xabarlari", NotificationManager.IMPORTANCE_DEFAULT)
                )
            }
        }

        val open = Intent(ctx, MainActivity::class.java).apply {
            putExtra("zeno_open", text)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val id = (System.currentTimeMillis() % 100000).toInt()
        val pi = PendingIntent.getActivity(ctx, id, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val n = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_info) // o'z ikonkangizga almashtiring
            .setContentTitle("Zeno")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()

        return try {
            nm.notify(id, n)
            ZenoDb.get(ctx).logNotif(kind, text)
            true
        } catch (e: SecurityException) {
            false
        }
    }
}

// ======================== ZenoWorker.kt ========================
/**
 * Har ~15 daqiqada (WorkManager minimumi) uyg'onadi va qoidalarni tekshiradi.
 * WorkManager telefon qayta yoqilgandan keyin ham ishni o'zi tiklaydi.
 * Android (ayniqsa MIUI) fon ishini kechiktirishi mumkin — aniq soniyaga kafolat yo'q.
 */
class ZenoWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {

    override fun doWork(): Result {
        try {
            val p = ZenoPrefs(applicationContext)
            val now = System.currentTimeMillis()
            // bir nechta manba (xizmat, signal, WorkManager) bir vaqtda chaqirsa, qayta ishlamaymiz
            if (now - p.lastTick < 13L * 60_000L) return Result.success()
            p.lastTick = now
            tick(applicationContext, ZenoDb.get(applicationContext), p)
        } catch (e: Exception) {
            // fon ishi hech qachon ilovani qulatmasin, lekin xatoni Logcat'da ko'rish mumkin
            Log.e("ZenoWorker", "tick xatosi", e)
        }
        return Result.success()
    }

    private fun isQuiet(p: ZenoPrefs): Boolean {
        val h = Util.hour()
        return if (p.quietStart > p.quietEnd) h >= p.quietStart || h < p.quietEnd
        else h >= p.quietStart && h < p.quietEnd
    }

    private fun canSend(p: ZenoPrefs, db: ZenoDb, ignoreCap: Boolean): Boolean {
        if (System.currentTimeMillis() < p.pausedUntil) return false
        if (isQuiet(p)) return false
        return ignoreCap || db.notifCountToday() < p.dailyCap
    }

    private fun sentToday(db: ZenoDb, kind: String) = db.lastNotifTs(kind) >= Util.midnight()

    private fun fmt(min: Int): String = when {
        min < 60 -> "$min daqiqa"
        min % 60 == 0 -> "${min / 60} soat"
        min % 60 == 30 -> "${min / 60},5 soat"
        else -> "${min / 60} soat ${min % 60} daqiqa"
    }

    private fun usageText(label: String, t: Int): String {
        val base = "Siz «$label» ilovasida bugun ${fmt(t)} vaqt o‘tkazdingiz."
        return when {
            t >= 90 -> "$base Endi tanaffus qilish vaqti kelgandir 🙂"
            t >= 60 -> "$base Biroz dam olishingiz ma’qul."
            else -> base
        }
    }

    private fun tick(c: Context, db: ZenoDb, prefs: ZenoPrefs) {
        val hour = Util.hour()
        db.prune()

        // 1) Tanlangan ilovalar bo'yicha kunlik vaqt ogohlantirishlari
        if (prefs.usageTracking && UsageTracker.hasAccess(c)) {
            val apps = prefs.tracked().filter { it.enabled }
            if (apps.isNotEmpty()) {
                val mins = UsageTracker.todayMinutes(c, apps.map { it.pkg }.toSet())
                val day = Util.today()
                for (a in apps) {
                    val m = mins[a.pkg] ?: 0L
                    val crossed = a.thresholds.filter { m >= it && !db.usageAlertSent(day, a.pkg, it) }
                    val top = crossed.maxOrNull() ?: continue
                    if (!canSend(prefs, db, false)) break
                    if (Notifier.send(c, "usage", usageText(a.label, top))) {
                        crossed.forEach { db.markUsageAlert(day, a.pkg, it) } // oradagi chegaralar takrorlanmasin
                    }
                }
            }
        }

        // Bir tikda boshqa turdagi eng ko'pi bilan bitta xabar (ketma-ket yog'ilib ketmasin)
        // 2) Maqsad va mashq eslatmalari (kuniga bir martadan, bosimsiz)
        if (canSend(prefs, db, false)) {
            if (hour in 18..20 && !sentToday(db, "goal")) {
                val g = db.openGoals().randomOrNull()
                if (g != null && Notifier.send(c, "goal", "Maqsadlaringdan biri: «${g.title}». Bosim yo‘q — vaqting bo‘lsa, kichik bir qadam qo‘y 🙂")) return
            }
            if (hour in 17..19 && !sentToday(db, "workout") && db.workoutCount() > 0 && db.lastWorkout()?.day != Util.today()) {
                if (Notifier.send(c, "workout", "Bugun hali mashq natijasini yozmading. Imkoning bo‘lsa, bajarib, menga ayt — majburlamayman 🙂")) return
            }
        }

        // 3) Foydalanuvchi ilovaga kirmasa: kamida 48 soatda bir marta, kunlik limitga kirmaydi
        if (prefs.inactivityNudges && canSend(prefs, db, true) && hour in 9..21) {
            val now = System.currentTimeMillis()
            val days = (now - prefs.lastActive) / 86_400_000L
            if (days >= 1 && now - prefs.lastInactivityNudge >= 48L * 3_600_000L) {
                val text = if (days >= 2) Msg.inactiveLong else Msg.inactiveShort
                if (Notifier.send(c, "inactive", text)) {
                    prefs.lastInactivityNudge = now
                    return
                }
            }
        }

        // 4) Aralash tizim: tasodifiy vaqtlarda qisqa motivatsion xabar
        if (prefs.motivation && canSend(prefs, db, false) && hour in 9..21) {
            val sinceLast = System.currentTimeMillis() - db.lastNotifTs("motivation")
            val chance = (prefs.dailyCap / 3.0) / 48.0 // taxminan limitning uchdan biri, kun bo'yi tarqalgan
            if (sinceLast >= 90L * 60_000L && Random.nextDouble() < chance) {
                val goals = db.openGoals()
                val text = if (goals.isNotEmpty() && Random.nextInt(100) < 40) {
                    "Maqsading — «${goals.random().title}». Bugun kichik bo‘lsa ham bir qadam qo‘ysak-chi?"
                } else {
                    val pool = if (ZenoBrain(c).baseTone() == Tone.PLAYFUL) Msg.motivPlayful else Msg.motivNeutral
                    val recent = db.recentNotifTexts(40)
                    (pool.filter { it !in recent }.ifEmpty { pool }).random()
                }
                Notifier.send(c, "motivation", text)
            }
        }
    }
}

// ======================== Keeper.kt (fon ishini tirik saqlash) ========================
/**
 * Fon ishi uch qatlam bilan himoyalanadi: WorkManager + AlarmManager (o‘zini qayta rejalaydi)
 * + doimiy xizmat (foreground service). Telefon qayta yonganda BootReceiver hammasini tiklaydi.
 */
object Keeper {
    private const val ALARM_CODE = 7001
    private const val EVERY = 15L * 60_000L

    fun ensure(ctx: Context) {
        val app = ctx.applicationContext
        try {
            WorkManager.getInstance(app).enqueueUniquePeriodicWork(
                "zeno_tick", ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequest.Builder(ZenoWorker::class.java, 15, TimeUnit.MINUTES).build()
            )
        } catch (e: Exception) {
            Log.e("Keeper", "work xatosi", e)
        }
        scheduleAlarm(app)
        if (ZenoPrefs(app).keepAlive) startService(app)
    }

    fun scheduleAlarm(ctx: Context) {
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                ctx, ALARM_CODE, Intent(ctx, AlarmReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + EVERY, pi)
        } catch (e: Exception) {
            Log.e("Keeper", "alarm xatosi", e)
        }
    }

    fun runNow(ctx: Context) {
        try {
            WorkManager.getInstance(ctx.applicationContext).enqueueUniqueWork(
                "zeno_tick_once", ExistingWorkPolicy.KEEP, OneTimeWorkRequest.from(ZenoWorker::class.java)
            )
        } catch (e: Exception) {
            Log.e("Keeper", "runNow xatosi", e)
        }
    }

    fun startService(ctx: Context) {
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, ZenoService::class.java))
        } catch (e: Exception) {
            Log.e("Keeper", "xizmatni boshlab bo‘lmadi", e)
        }
    }

    fun stopService(ctx: Context) {
        try {
            ctx.stopService(Intent(ctx, ZenoService::class.java))
        } catch (e: Exception) {
            Log.e("Keeper", "xizmatni to‘xtatib bo‘lmadi", e)
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        Keeper.scheduleAlarm(ctx)
        Keeper.runNow(ctx)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        Keeper.ensure(ctx)
    }
}

class ZenoService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val loop = object : Runnable {
        override fun run() {
            Keeper.runNow(applicationContext)
            Keeper.scheduleAlarm(applicationContext)
            handler.postDelayed(this, 10L * 60_000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ch = "zeno_service"
        if (Build.VERSION.SDK_INT >= 26) {
            val m = getSystemService(NotificationManager::class.java)
            if (m.getNotificationChannel(ch) == null) {
                m.createNotificationChannel(
                    NotificationChannel(ch, "Zeno fon rejimi", NotificationManager.IMPORTANCE_MIN)
                )
            }
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, ch)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Zeno ishlayapti")
            .setContentText("Eslatmalar uchun fonda kutyapman")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(open)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            Log.e("ZenoService", "startForeground xatosi", e)
            stopSelf()
            return START_NOT_STICKY
        }
        handler.removeCallbacks(loop)
        handler.post(loop)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(loop)
        super.onDestroy()
    }
}

// ======================== MainActivity.kt ========================
class MainActivity : AppCompatActivity() {

    private lateinit var db: ZenoDb
    private lateinit var prefs: ZenoPrefs
    private lateinit var brain: ZenoBrain
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = ZenoDb.get(this)
        prefs = ZenoPrefs(this)
        brain = ZenoBrain(this)

        logView = findViewById(R.id.chatLogTextView)
        scroll = findViewById(R.id.chatScroll)
        input = findViewById(R.id.messageInput)

        findViewById<Button>(R.id.sendButton).setOnClickListener { send() }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                send()
                true
            } else {
                false
            }
        }

        ensureWelcome()
        handleIntent(intent)
        render()

        askNotificationPermission()
        Keeper.ensure(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
        render()
    }

    override fun onResume() {
        super.onResume()
        prefs.lastActive = System.currentTimeMillis()
        ensureWelcome()
        render()
    }

    private fun ensureWelcome() {
        if (db.recentChat().isEmpty()) {
            db.addChat("zeno", "Salom! Men Zenoman — virtual do‘sting. Nima qila olishimni bilish uchun «yordam» deb yoz.")
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, MENU_SETTINGS, 0, "Sozlamalar")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == MENU_SETTINGS) {
            startActivity(Intent(this, SettingsActivity::class.java))
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    /** Bildirishnomani bosib kirilganda, uning matni suhbatga Zeno xabari sifatida qo‘shiladi. */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val t = i.getStringExtra("zeno_open") ?: return
        i.removeExtra("zeno_open")
        val last = db.recentChat().lastOrNull()
        if (last == null || last.second != t) db.addChat("zeno", t)
    }

    private fun send() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        db.addChat("me", t)
        val reply = try {
            brain.respond(t)
        } catch (e: Exception) {
            Log.e("Zeno", "respond xatosi", e)
            "Kechir, xatolik chiqdi. Qayta urinib ko‘rasanmi?"
        }
        db.addChat("zeno", reply)
        render()
    }

    private fun render() {
        val sb = StringBuilder()
        for ((who, text) in db.recentChat()) {
            sb.append(if (who == "me") "Sen: " else "Zeno: ").append(text).append("\n\n")
        }
        logView.text = sb.toString().trimEnd()
        // fullScroll() EditText fokusini olib qo‘yib, klaviaturani yopib yuborardi
        scroll.post { scroll.scrollTo(0, logView.bottom) }
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    /** Har ~15 daqiqada ZenoWorker ni ishga tushiradi (allaqachon rejalashtirilgan bo‘lsa, tegmaydi). */
    private fun scheduleWorker() {
        val req = PeriodicWorkRequest.Builder(ZenoWorker::class.java, 15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(applicationContext)
            .enqueueUniquePeriodicWork("zeno_tick", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    companion object {
        private const val MENU_SETTINGS = 1
    }
}

// ======================== SettingsActivity.kt ========================
/** Sozlamalar ekrani: butun interfeys kodda quriladi, shuning uchun qo‘shimcha XML kerak emas. */
class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: ZenoPrefs
    private lateinit var db: ZenoDb
    private lateinit var root: LinearLayout
    private lateinit var usageStatus: TextView
    private lateinit var pauseStatus: TextView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Sozlamalar"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        prefs = ZenoPrefs(this)
        db = ZenoDb.get(this)

        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(8), dp(16), dp(24))

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)

        build()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ---------------- Ekran tuzilishi ----------------

    private fun build() {
        header("Bildirishnomalar")
        toggle("Faoliyatsizlik eslatmalari", prefs.inactivityNudges) { prefs.inactivityNudges = it }
        toggle("Motivatsion xabarlar", prefs.motivation) { prefs.motivation = it }
        slider({ "Kunlik limit: $it ta xabar" }, 1, 30, prefs.dailyCap) { prefs.dailyCap = it }
        slider({ "Tinch soatlar boshlanishi: ${hh(it)}" }, 0, 23, prefs.quietStart) { prefs.quietStart = it }
        slider({ "Tinch soatlar tugashi: ${hh(it)}" }, 0, 23, prefs.quietEnd) { prefs.quietEnd = it }

        pauseStatus = TextView(this)
        pauseStatus.setPadding(0, dp(8), 0, 0)
        root.addView(pauseStatus)
        btn("1 soatga jim turish") { pause(1) }
        btn("8 soatga jim turish") { pause(8) }
        btn("Jim turishni bekor qilish") {
            prefs.pausedUntil = 0L
            refreshStatus()
        }
        toggle("Doimiy fon rejimi (ishonchliroq; doimiy belgi chiqadi)", prefs.keepAlive) { on ->
            prefs.keepAlive = on
            if (on) Keeper.startService(this) else Keeper.stopService(this)
        }
        btn("Batareya cheklovini o‘chirish") { requestBatteryExemption() }
        btn("Avtostartga ruxsat (Xiaomi, Huawei, Oppo…)") { openAutostart() }
        btn("Sinov bildirishnomasi yuborish") {
            val ok = Notifier.send(this, "test", "Bu sinov xabari. Hammasi ishlayapti 🙂")
            toast(if (ok) "Yuborildi" else "Yuborib bo‘lmadi — bildirishnoma ruxsatini tekshiring")
        }

        header("Ilova vaqti ogohlantirishlari")
        toggle("Ilova vaqtini kuzatish", prefs.usageTracking) { prefs.usageTracking = it }
        usageStatus = TextView(this)
        root.addView(usageStatus)
        btn("Foydalanish statistikasi ruxsatini ochish") {
            try {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            } catch (e: Exception) {
                toast("Sozlamalarni ochib bo‘lmadi")
            }
        }
        val list = prefs.tracked().toMutableList()
        list.forEachIndexed { i, a ->
            toggle("${a.label} (${a.thresholds.joinToString("/")} daq)", a.enabled) { on ->
                list[i] = list[i].copy(enabled = on)
                prefs.saveTracked(list)
            }
        }

        btn("Boshqa ilova qo‘shish") { addAppDialog() }

        header("Muloqot uslubi")
        val modes = listOf(
            "auto" to "Avto (moslashadi)",
            "neutral" to "Oddiy",
            "serious" to "Jiddiy",
            "playful" to "Quvnoq"
        )
        val rg = RadioGroup(this)
        modes.forEachIndexed { i, m ->
            val rb = RadioButton(this)
            rb.id = 1000 + i
            rb.text = m.second
            rg.addView(rb)
        }
        val cur = modes.indexOfFirst { it.first == prefs.styleMode }.coerceAtLeast(0)
        rg.check(1000 + cur)
        rg.setOnCheckedChangeListener { _, checkedId ->
            val idx = checkedId - 1000
            if (idx in modes.indices) prefs.styleMode = modes[idx].first
        }
        root.addView(rg)

        header("Xotira")
        btn("Xotirani ko‘rish / o‘chirish") { showMemories() }
        btn("Hammasini o‘chirish") {
            AlertDialog.Builder(this)
                .setTitle("Hammasini o‘chirish?")
                .setMessage("Xotira, maqsadlar, mashq natijalari va suhbat tarixi o‘chadi.")
                .setPositiveButton("Ha") { _, _ ->
                    db.clearAll()
                    toast("O‘chirildi")
                }
                .setNegativeButton("Yo‘q", null)
                .show()
        }
    }

    // ---------------- Yordamchilar ----------------

    private fun hh(h: Int): String = String.format(Locale.US, "%02d:00", h)

    private fun toast(t: String) {
        Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    }

    private fun header(t: String) {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 18f
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setPadding(0, dp(24), 0, dp(6))
        root.addView(tv)
    }

    private fun toggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val s = SwitchCompat(this)
        s.text = label
        s.isChecked = checked
        s.setPadding(0, dp(8), 0, dp(8))
        s.setOnCheckedChangeListener { _, v -> onChange(v) }
        root.addView(s)
    }

    private fun btn(t: String, action: () -> Unit) {
        val b = Button(this)
        b.text = t
        b.setOnClickListener { action() }
        root.addView(b)
    }

    private fun slider(label: (Int) -> String, lo: Int, hi: Int, cur: Int, onSet: (Int) -> Unit) {
        val tv = TextView(this)
        tv.text = label(cur)
        tv.setPadding(0, dp(8), 0, 0)
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = cur - lo
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + lo
                tv.text = label(v)
                if (fromUser) onSet(v)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(tv)
        root.addView(sb)
    }

    private fun pause(hours: Int) {
        prefs.pausedUntil = System.currentTimeMillis() + hours * 3_600_000L
        refreshStatus()
    }

    private fun refreshStatus() {
        usageStatus.text = if (UsageTracker.hasAccess(this))
            "Ruxsat holati: berilgan ✅"
        else
            "Ruxsat holati: berilmagan ❌ (quyidagi tugma orqali Zeno’ni yoqing)"

        val p = prefs.pausedUntil
        pauseStatus.text = if (System.currentTimeMillis() < p)
            "Jim turish: ${SimpleDateFormat("dd.MM HH:mm", Locale.US).format(Date(p))} gacha"
        else
            "Jim turish: o‘chiq"
    }

    /** Ro‘yxatda yo‘q ilovani paket nomi bilan qo‘shish (masalan: com.whatsapp). */
    private fun addAppDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val pkgIn = EditText(this)
        pkgIn.hint = "Paket nomi (masalan: com.whatsapp)"
        val nameIn = EditText(this)
        nameIn.hint = "Nomi (ixtiyoriy)"
        box.addView(pkgIn)
        box.addView(nameIn)
        AlertDialog.Builder(this)
            .setTitle("Ilova qo‘shish")
            .setView(box)
            .setPositiveButton("Qo‘shish") { _, _ ->
                val pkg = pkgIn.text.toString().trim()
                if (!Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+$").matches(pkg)) {
                    toast("Paket nomi noto‘g‘ri")
                    return@setPositiveButton
                }
                val cur = prefs.tracked()
                if (cur.any { it.pkg == pkg }) {
                    toast("Bu ilova ro‘yxatda bor")
                    return@setPositiveButton
                }
                val label = nameIn.text.toString().trim().ifEmpty { pkg.substringAfterLast('.') }
                prefs.saveTracked(cur + TrackedApp(pkg, label, true, listOf(30, 60, 90)))
                root.removeAllViews()
                build()
                refreshStatus()
            }
            .setNegativeButton("Bekor", null)
            .show()
    }

    private fun requestBatteryExemption() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            toast("Batareya cheklovi allaqachon o‘chirilgan ✅")
            return
        }
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                toast("Sozlamalarni ochib bo‘lmadi")
            }
        }
    }

    /** Ishlab chiqaruvchiga xos avtostart sahifasini ochadi; topilmasa, ilova sozlamalariga yuboradi. */
    private fun openAutostart() {
        val targets = listOf(
            "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
            "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
            "com.samsung.android.lool" to "com.samsung.android.sm.ui.battery.BatteryActivity"
        )
        for ((pkg, cls) in targets) {
            try {
                startActivity(Intent().setComponent(ComponentName(pkg, cls)))
                return
            } catch (e: Exception) {
                // keyingisini sinaymiz
            }
        }
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            toast("Ilova sozlamalarida «Batareya» va «Avtostart»ni yoqing")
        } catch (e: Exception) {
            toast("Sozlamalarni ochib bo‘lmadi")
        }
    }

    private fun showMemories() {
        val m = db.memories()
        if (m.isEmpty()) {
            toast("Xotira bo‘sh")
            return
        }
        val items = m.map { "#${it.id} [${it.category}] ${it.text}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Xotira (o‘chirish uchun bosing)")
            .setItems(items) { _, which -> confirmDelete(m[which]) }
            .setNegativeButton("Yopish", null)
            .show()
    }

    private fun confirmDelete(mem: Mem) {
        AlertDialog.Builder(this)
            .setTitle("O‘chirilsinmi?")
            .setMessage(mem.text)
            .setPositiveButton("Ha") { _, _ ->
                db.deleteMemory(mem.id)
                showMemories()
            }
            .setNegativeButton("Yo‘q", null)
            .show()
    }
}
