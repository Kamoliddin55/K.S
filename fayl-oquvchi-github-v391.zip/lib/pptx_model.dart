import 'dart:io';
import 'dart:isolate';
import 'dart:math' as math;

import 'package:archive/archive.dart';
import 'package:path/path.dart' as p;
import 'package:xml/xml.dart';

import 'document_parser.dart';

// =====================================================================
// Model (faqat oddiy qiymatlar - isolate orqali uzatiladi)
// =====================================================================

class PRun {
  final String text;
  final double size;
  final bool bold;
  final bool italic;
  final bool underline;
  final bool strike;
  final int? color;
  final String? font;
  final int baseline;
  const PRun({
    required this.text,
    this.size = 18,
    this.bold = false,
    this.italic = false,
    this.underline = false,
    this.strike = false,
    this.color,
    this.font,
    this.baseline = 0,
  });
}

class PPara {
  final List<PRun> runs;
  final String align;
  final double marL;
  final double indent;
  final double before;
  final double after;
  final double lineMul;
  final String? bullet;
  final int? bulletColor;
  final double size;
  const PPara({
    required this.runs,
    this.align = 'left',
    this.marL = 0,
    this.indent = 0,
    this.before = 0,
    this.after = 0,
    this.lineMul = 1,
    this.bullet,
    this.bulletColor,
    this.size = 18,
  });

  String get plain => runs.map((r) => r.text).join();
}

class PCell {
  final List<PPara> paras;
  final int? fill;
  final int span;
  final bool merged; // hMerge/vMerge
  final int? lineColor;
  const PCell({
    required this.paras,
    this.fill,
    this.span = 1,
    this.merged = false,
    this.lineColor,
  });
}

class PRow {
  final double height;
  final List<PCell> cells;
  const PRow(this.height, this.cells);
}

class PShape {
  final String kind; // sp, pic, tbl, line, other
  final double x;
  final double y;
  final double w;
  final double h;
  final double rot; // gradus
  final bool flipH;
  final bool flipV;
  final String geom;
  final double adj;
  final int? fill;
  final int? fill2;
  final double gradAngle;
  final int? lineColor;
  final double lineW;
  final String? image;
  final double cropL;
  final double cropT;
  final double cropR;
  final double cropB;
  final List<PPara> paras;
  final String anchor;
  final double padL;
  final double padT;
  final double padR;
  final double padB;
  final bool wrap;
  final List<double> cols;
  final List<PRow> rows;
  const PShape({
    required this.kind,
    this.x = 0,
    this.y = 0,
    this.w = 0,
    this.h = 0,
    this.rot = 0,
    this.flipH = false,
    this.flipV = false,
    this.geom = 'rect',
    this.adj = 0.16667,
    this.fill,
    this.fill2,
    this.gradAngle = 0,
    this.lineColor,
    this.lineW = 0,
    this.image,
    this.cropL = 0,
    this.cropT = 0,
    this.cropR = 0,
    this.cropB = 0,
    this.paras = const <PPara>[],
    this.anchor = 't',
    this.padL = 7.2,
    this.padT = 3.6,
    this.padR = 7.2,
    this.padB = 3.6,
    this.wrap = true,
    this.cols = const <double>[],
    this.rows = const <PRow>[],
  });
}

class PSlide {
  final int? bg;
  final int? bg2;
  final List<PShape> shapes;
  final List<String> media; // "VID\u0002yo'l" yoki "AUD\u0002yo'l"
  final String plain;
  const PSlide(this.bg, this.bg2, this.shapes, this.media, this.plain);
}

class PDeck {
  final double w;
  final double h;
  final List<PSlide> slides;
  const PDeck(this.w, this.h, this.slides);
}

Future<PDeck> loadPptx(String path, {String? mediaDir}) =>
    Isolate.run(() => parsePptx(path, mediaDir));

// =====================================================================
// Yordamchilar
// =====================================================================

String? _a(XmlElement? e, String local) => e == null ? null : xmlAttr(e, local);

XmlElement? _c(XmlElement? e, String name) {
  if (e == null) return null;
  for (final x in e.childElements) {
    if (x.name.local == name) return x;
  }
  return null;
}

XmlElement? _firstOf(List<XmlElement?> list, String name) {
  for (final e in list) {
    final c = _c(e, name);
    if (c != null) return c;
  }
  return null;
}

String? _firstAttr(List<XmlElement?> list, String name) {
  for (final e in list) {
    final v = _a(e, name);
    if (v != null) return v;
  }
  return null;
}

double? _emu(String? v) {
  if (v == null) return null;
  final n = double.tryParse(v);
  return n == null ? null : n / 12700;
}

bool? _bool(String? v) {
  if (v == null) return null;
  return v == '1' || v == 'true';
}

class _Tmpl {
  final XmlElement root;
  final bool showMaster;
  final Map<String, XmlElement> byIdx = <String, XmlElement>{};
  final Map<String, XmlElement> byType = <String, XmlElement>{};
  _Tmpl(this.root, this.showMaster) {
    for (final sp in root.findAllElements('sp')) {
      final ph = _phOf(sp);
      if (ph == null) continue;
      final idx = _a(ph, 'idx');
      final type = _normType(_a(ph, 'type'));
      if (idx != null) byIdx.putIfAbsent(idx, () => sp);
      byType.putIfAbsent(type, () => sp);
    }
  }
}

XmlElement? _phOf(XmlElement sp) {
  final nv = _c(sp, 'nvSpPr');
  final pr = _c(nv, 'nvPr');
  return _c(pr, 'ph');
}

String _normType(String? t) {
  switch (t) {
    case null:
    case 'body':
    case 'obj':
    case 'subTitle':
      return 'body';
    case 'title':
    case 'ctrTitle':
      return 'title';
    default:
      return t;
  }
}

class _Env {
  final Archive archive;
  final MediaSink media;
  final Map<String, int> theme = <String, int>{};
  final Map<String, String> clrMap = <String, String>{
    'bg1': 'lt1',
    'tx1': 'dk1',
    'bg2': 'lt2',
    'tx2': 'dk2',
    'accent1': 'accent1',
    'accent2': 'accent2',
    'accent3': 'accent3',
    'accent4': 'accent4',
    'accent5': 'accent5',
    'accent6': 'accent6',
    'hlink': 'hlink',
    'folHlink': 'folHlink',
  };
  final Map<String, _Tmpl> tmpls = <String, _Tmpl>{};
  _Env(this.archive, this.media);
}

// ---------- Ranglar ----------

List<double> _rgbToHsl(int c) {
  final r = ((c >> 16) & 0xFF) / 255;
  final g = ((c >> 8) & 0xFF) / 255;
  final b = (c & 0xFF) / 255;
  final mx = math.max(r, math.max(g, b));
  final mn = math.min(r, math.min(g, b));
  final l = (mx + mn) / 2;
  var h = 0.0;
  var s = 0.0;
  if (mx != mn) {
    final d = mx - mn;
    s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
    if (mx == r) {
      h = (g - b) / d + (g < b ? 6 : 0);
    } else if (mx == g) {
      h = (b - r) / d + 2;
    } else {
      h = (r - g) / d + 4;
    }
    h /= 6;
  }
  return [h, s, l];
}

double _hue(double p0, double q, double t0) {
  var t = t0;
  if (t < 0) t += 1;
  if (t > 1) t -= 1;
  if (t < 1 / 6) return p0 + (q - p0) * 6 * t;
  if (t < 1 / 2) return q;
  if (t < 2 / 3) return p0 + (q - p0) * (2 / 3 - t) * 6;
  return p0;
}

int _hslToRgb(double h, double s, double l) {
  double r;
  double g;
  double b;
  if (s == 0) {
    r = g = b = l;
  } else {
    final q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    final pp = 2 * l - q;
    r = _hue(pp, q, h + 1 / 3);
    g = _hue(pp, q, h);
    b = _hue(pp, q, h - 1 / 3);
  }
  int to(double v) => (v * 255).round().clamp(0, 255);
  return 0xFF000000 | (to(r) << 16) | (to(g) << 8) | to(b);
}

const _presetColors = <String, int>{
  'black': 0xFF000000,
  'white': 0xFFFFFFFF,
  'red': 0xFFFF0000,
  'green': 0xFF008000,
  'blue': 0xFF0000FF,
  'yellow': 0xFFFFFF00,
  'gray': 0xFF808080,
  'orange': 0xFFFFA500,
};

int? _clr(XmlElement c, _Env env, int? phClr) {
  int? base;
  switch (c.name.local) {
    case 'srgbClr':
      final n = int.tryParse(_a(c, 'val') ?? '', radix: 16);
      if (n != null) base = 0xFF000000 | n;
      break;
    case 'sysClr':
      final n = int.tryParse(_a(c, 'lastClr') ?? '', radix: 16);
      if (n != null) base = 0xFF000000 | n;
      break;
    case 'prstClr':
      base = _presetColors[_a(c, 'val') ?? ''];
      break;
    case 'schemeClr':
      final v = _a(c, 'val') ?? '';
      if (v == 'phClr') {
        base = phClr;
      } else {
        base = env.theme[env.clrMap[v] ?? v];
      }
      break;
    default:
      return null;
  }
  if (base == null) return null;

  var alpha = 255;
  for (final m in c.childElements) {
    final v = double.tryParse(_a(m, 'val') ?? '');
    if (v == null) continue;
    switch (m.name.local) {
      case 'lumMod':
        final hsl = _rgbToHsl(base!);
        base = _hslToRgb(hsl[0], hsl[1], (hsl[2] * v / 100000).clamp(0.0, 1.0));
        break;
      case 'lumOff':
        final hsl = _rgbToHsl(base!);
        base = _hslToRgb(hsl[0], hsl[1], (hsl[2] + v / 100000).clamp(0.0, 1.0));
        break;
      case 'tint':
        final t = v / 100000;
        base = _mix(base!, 0xFFFFFFFF, t);
        break;
      case 'shade':
        final t = v / 100000;
        base = _mix(base!, 0xFF000000, t);
        break;
      case 'alpha':
        alpha = (v / 100000 * 255).round().clamp(0, 255);
        break;
    }
  }
  return (alpha << 24) | (base! & 0xFFFFFF);
}

/// [t] - asl rangning ulushi, qolgani [other] bilan aralashadi.
int _mix(int color, int other, double t) {
  int ch(int shift) {
    final a = (color >> shift) & 0xFF;
    final b = (other >> shift) & 0xFF;
    return (a * t + b * (1 - t)).round().clamp(0, 255);
  }

  return 0xFF000000 | (ch(16) << 16) | (ch(8) << 8) | ch(0);
}

int? _colorIn(XmlElement? holder, _Env env, int? phClr) {
  if (holder == null) return null;
  for (final c in holder.childElements) {
    final v = _clr(c, env, phClr);
    if (v != null) return v;
  }
  return null;
}

/// spPr/rPr ichidagi solidFill rangini qaytaradi. [none] - noFill topilganini bildiradi.
class _Fill {
  int? c1;
  int? c2;
  double angle = 0;
  bool none = false;
  bool found = false;
}

_Fill _readFill(XmlElement? parent, _Env env, int? phClr) {
  final f = _Fill();
  if (parent == null) return f;
  for (final e in parent.childElements) {
    switch (e.name.local) {
      case 'noFill':
        f.none = true;
        f.found = true;
        return f;
      case 'solidFill':
        f.c1 = _colorIn(e, env, phClr);
        f.found = true;
        return f;
      case 'pattFill':
        f.c1 = _colorIn(_c(e, 'fgClr'), env, phClr);
        f.found = true;
        return f;
      case 'gradFill':
        final stops = _c(e, 'gsLst')?.childElements.toList() ?? <XmlElement>[];
        if (stops.isNotEmpty) {
          f.c1 = _colorIn(stops.first, env, phClr);
          f.c2 = _colorIn(stops.last, env, phClr);
        }
        final lin = _c(e, 'lin');
        f.angle = (double.tryParse(_a(lin, 'ang') ?? '') ?? 0) / 60000;
        f.found = true;
        return f;
    }
  }
  return f;
}

// =====================================================================
// O'qish
// =====================================================================

class _Rel {
  final String id;
  final String type;
  final String target;
  const _Rel(this.id, this.type, this.target);
}

List<_Rel> _rels(Archive archive, String relsName, String baseDir) {
  final out = <_Rel>[];
  final xml = zipText(archive, relsName);
  if (xml == null) return out;
  try {
    for (final r in parseOfficeXml(xml).findAllElements('Relationship')) {
      final id = r.getAttribute('Id');
      final type = r.getAttribute('Type') ?? '';
      final target = r.getAttribute('Target');
      if (id == null || target == null) continue;
      if (r.getAttribute('TargetMode') == 'External') continue;
      final path = target.startsWith('/')
          ? target.substring(1)
          : p.posix.normalize(p.posix.join(baseDir, target));
      out.add(_Rel(id, type, path));
    }
  } catch (_) {}
  return out;
}

PDeck parsePptx(String path, String? mediaDir) {
  final bytes = File(path).readAsBytesSync();
  final archive = openZip(bytes);
  final env = _Env(archive, MediaSink(mediaDir));

  // Mavzu ranglari
  final themeXml = zipText(archive, 'ppt/theme/theme1.xml');
  if (themeXml != null) {
    try {
      final scheme = parseOfficeXml(themeXml).findAllElements('clrScheme');
      if (scheme.isNotEmpty) {
        for (final el in scheme.first.childElements) {
          for (final ch in el.childElements) {
            final v = _a(ch, 'val') ?? '';
            final last = _a(ch, 'lastClr') ?? '';
            final src = v.length == 6 ? v : last;
            final n = int.tryParse(src, radix: 16);
            if (n != null) env.theme[el.name.local] = 0xFF000000 | n;
          }
        }
      }
    } catch (_) {}
  }
  env.theme.putIfAbsent('lt1', () => 0xFFFFFFFF);
  env.theme.putIfAbsent('dk1', () => 0xFF000000);
  env.theme.putIfAbsent('lt2', () => 0xFFE7E6E6);
  env.theme.putIfAbsent('dk2', () => 0xFF44546A);
  env.theme.putIfAbsent('accent1', () => 0xFF4472C4);

  var sw = 720.0;
  var sh = 405.0;
  final presXml = zipText(archive, 'ppt/presentation.xml');
  final slidePaths = <String>[];
  if (presXml != null) {
    final pres = parseOfficeXml(presXml);
    final size = pres.findAllElements('sldSz');
    if (size.isNotEmpty) {
      sw = _emu(_a(size.first, 'cx')) ?? sw;
      sh = _emu(_a(size.first, 'cy')) ?? sh;
    }
    final rels = _rels(archive, 'ppt/_rels/presentation.xml.rels', 'ppt/');
    final byId = {for (final r in rels) r.id: r.target};
    for (final id in pres.findAllElements('sldId')) {
      final rid = _a(id, 'id');
      // r:id atributi
      String? target;
      for (final at in id.attributes) {
        if (at.name.prefix == 'r' || at.name.qualified == 'r:id') {
          target = byId[at.value];
        }
      }
      target ??= rid == null ? null : byId[rid];
      if (target != null && archive.findFile(target) != null) {
        slidePaths.add(target);
      }
    }
  }
  if (slidePaths.isEmpty) {
    final files = archive.files
        .where((f) => RegExp(r'^ppt/slides/slide\d+\.xml$').hasMatch(f.name))
        .toList();
    files.sort((a, b) => _num(a.name).compareTo(_num(b.name)));
    slidePaths.addAll(files.map((f) => f.name));
  }
  if (slidePaths.isEmpty) {
    throw const FormatException('Slaydlar topilmadi');
  }

  final slides = <PSlide>[];
  for (final sp in slidePaths) {
    try {
      slides.add(_slide(sp, env));
    } catch (_) {
      slides.add(const PSlide(null, null, <PShape>[], <String>[], ''));
    }
  }
  return PDeck(sw, sh, slides);
}

int _num(String name) {
  final m = RegExp(r'(\d+)\.xml$').firstMatch(name);
  return m == null ? 0 : int.parse(m.group(1)!);
}

_Tmpl? _tmpl(_Env env, String path, bool master) {
  final cached = env.tmpls[path];
  if (cached != null) return cached;
  final xml = zipText(env.archive, path);
  if (xml == null) return null;
  final doc = parseOfficeXml(xml);
  final root = doc.rootElement;
  final show = _bool(_a(root, 'showMasterSp')) ?? true;
  final t = _Tmpl(root, show);
  env.tmpls[path] = t;
  if (master) {
    final map = _c(root, 'clrMap');
    if (map != null) {
      for (final at in map.attributes) {
        env.clrMap[at.name.local] = at.value;
      }
    }
  }
  return t;
}

class _Xf {
  double x;
  double y;
  double w;
  double h;
  double rot;
  bool flipH;
  bool flipV;
  _Xf(this.x, this.y, this.w, this.h, this.rot, this.flipH, this.flipV);
}

class _Tf {
  final double ox;
  final double oy;
  final double sx;
  final double sy;
  final double cx;
  final double cy;
  const _Tf(this.ox, this.oy, this.sx, this.sy, this.cx, this.cy);
  static const identity = _Tf(0, 0, 1, 1, 0, 0);
}

_Xf? _readXf(XmlElement? xfrm) {
  if (xfrm == null) return null;
  final off = _c(xfrm, 'off');
  final ext = _c(xfrm, 'ext');
  if (off == null || ext == null) return null;
  return _Xf(
    _emu(_a(off, 'x')) ?? 0,
    _emu(_a(off, 'y')) ?? 0,
    _emu(_a(ext, 'cx')) ?? 0,
    _emu(_a(ext, 'cy')) ?? 0,
    (double.tryParse(_a(xfrm, 'rot') ?? '') ?? 0) / 60000,
    _bool(_a(xfrm, 'flipH')) ?? false,
    _bool(_a(xfrm, 'flipV')) ?? false,
  );
}

class _SlideCtx {
  final Map<String, String> imageRels = <String, String>{};
  final _Env env;
  final _Tmpl? layout;
  final _Tmpl? master;
  final StringBuffer plain = StringBuffer();
  _SlideCtx(this.env, this.layout, this.master);
}

PSlide _slide(String path, _Env env) {
  final xml = zipText(env.archive, path)!;
  final root = parseOfficeXml(xml).rootElement;
  final slideFile = p.posix.basename(path);
  final rels = _rels(env.archive, 'ppt/slides/_rels/$slideFile.rels', 'ppt/slides/');

  _Tmpl? layout;
  _Tmpl? master;
  for (final r in rels) {
    if (r.type.endsWith('/slideLayout')) {
      layout = _tmpl(env, r.target, false);
      final lrels = _rels(
        env.archive,
        'ppt/slideLayouts/_rels/${p.posix.basename(r.target)}.rels',
        'ppt/slideLayouts/',
      );
      for (final lr in lrels) {
        if (lr.type.endsWith('/slideMaster')) {
          master = _tmpl(env, lr.target, true);
        }
      }
    }
  }

  final ctx = _SlideCtx(env, layout, master);
  for (final r in rels) {
    ctx.imageRels[r.id] = r.target;
  }

  // Fon
  int? bg;
  int? bg2;
  void readBg(XmlElement? rootEl) {
    if (rootEl == null || bg != null) return;
    final b = _c(_c(rootEl, 'cSld'), 'bg');
    if (b == null) return;
    final props = _c(b, 'bgPr');
    if (props != null) {
      final f = _readFill(props, env, null);
      if (f.c1 != null) {
        bg = f.c1;
        bg2 = f.c2;
      }
      return;
    }
    final ref = _c(b, 'bgRef');
    if (ref != null) bg = _colorIn(ref, env, null);
  }

  readBg(root);
  final showLayoutShapes = _bool(_a(root, 'showMasterSp')) ?? true;
  readBg(layout?.root);
  readBg(master?.root);

  final shapes = <PShape>[];
  if (showLayoutShapes && layout != null) {
    if (layout.showMaster && master != null) {
      _tree(_c(_c(master.root, 'cSld'), 'spTree'), shapes, ctx, _Tf.identity, false, null);
    }
    _tree(_c(_c(layout.root, 'cSld'), 'spTree'), shapes, ctx, _Tf.identity, false, null);
  }
  ctx.plain.clear();
  _tree(_c(_c(root, 'cSld'), 'spTree'), shapes, ctx, _Tf.identity, true, null);

  // Video va audio
  final media = <String>[];
  for (final r in rels) {
    final line = env.media.line(env.archive, r.target);
    if (line == null) continue;
    final cut = line.indexOf(mediaSep);
    if (cut < 0) continue;
    final tag = line.substring(1, cut);
    if (tag == 'VID' || tag == 'AUD') {
      final entry = '$tag$mediaSep${line.substring(cut + 1)}';
      if (!media.contains(entry)) media.add(entry);
    }
  }

  return PSlide(bg, bg2, shapes, media, ctx.plain.toString().trim());
}

void _tree(
  XmlElement? tree,
  List<PShape> out,
  _SlideCtx ctx,
  _Tf tf,
  bool isSlide,
  XmlElement? groupParent,
) {
  if (tree == null) return;
  for (final n in tree.childElements) {
    switch (n.name.local) {
      case 'sp':
        final ph = _phOf(n);
        if (ph != null && !isSlide) break; // shablon placeholderlari chizilmaydi
        final s = _shape(n, ctx, tf, isSlide);
        if (s != null) out.add(s);
        break;
      case 'cxnSp':
        final s = _connector(n, ctx, tf);
        if (s != null) out.add(s);
        break;
      case 'pic':
        final s = _picture(n, ctx, tf);
        if (s != null) out.add(s);
        break;
      case 'graphicFrame':
        final s = _frame(n, ctx, tf);
        if (s != null) out.add(s);
        break;
      case 'grpSp':
        final pr = _c(n, 'grpSpPr');
        final xfrm = _c(pr, 'xfrm');
        final xf = _readXf(xfrm);
        if (xf == null) {
          _tree(n, out, ctx, tf, isSlide, n);
          break;
        }
        final chOff = _c(xfrm, 'chOff');
        final chExt = _c(xfrm, 'chExt');
        final cx = _emu(_a(chOff, 'x')) ?? 0;
        final cy = _emu(_a(chOff, 'y')) ?? 0;
        final cw = _emu(_a(chExt, 'cx')) ?? xf.w;
        final ch = _emu(_a(chExt, 'cy')) ?? xf.h;
        final ax = tf.ox + (xf.x - tf.cx) * tf.sx;
        final ay = tf.oy + (xf.y - tf.cy) * tf.sy;
        final aw = xf.w * tf.sx;
        final ah = xf.h * tf.sy;
        final nt = _Tf(
          ax,
          ay,
          cw == 0 ? 1 : aw / cw,
          ch == 0 ? 1 : ah / ch,
          cx,
          cy,
        );
        _tree(n, out, ctx, nt, isSlide, n);
        break;
      case 'AlternateContent':
        final choice = _c(n, 'Choice') ?? _c(n, 'Fallback');
        if (choice != null) _tree(choice, out, ctx, tf, isSlide, groupParent);
        break;
    }
  }
}

_Xf? _place(_Xf? xf, _Tf tf) {
  if (xf == null) return null;
  return _Xf(
    tf.ox + (xf.x - tf.cx) * tf.sx,
    tf.oy + (xf.y - tf.cy) * tf.sy,
    xf.w * tf.sx,
    xf.h * tf.sy,
    xf.rot,
    xf.flipH,
    xf.flipV,
  );
}

XmlElement? _matchIn(_Tmpl? t, XmlElement? ph, bool master) {
  if (t == null || ph == null) return null;
  if (!master) {
    final idx = _a(ph, 'idx');
    if (idx != null && t.byIdx.containsKey(idx)) return t.byIdx[idx];
  }
  return t.byType[_normType(_a(ph, 'type'))];
}

String _styleKind(XmlElement? ph) {
  final t = _normType(_a(ph, 'type'));
  if (ph == null) return 'otherStyle';
  if (t == 'title') return 'titleStyle';
  if (t == 'body') return 'bodyStyle';
  return 'otherStyle';
}

PShape? _shape(XmlElement sp, _SlideCtx ctx, _Tf tf, bool isSlide) {
  final env = ctx.env;
  final ph = _phOf(sp);
  final lSp = _matchIn(ctx.layout, ph, false);
  final mSp = _matchIn(ctx.master, ph, true);

  final spPr = _c(sp, 'spPr');
  final lPr = _c(lSp, 'spPr');
  final mPr = _c(mSp, 'spPr');

  var xf = _readXf(_c(spPr, 'xfrm')) ??
      _readXf(_c(lPr, 'xfrm')) ??
      _readXf(_c(mPr, 'xfrm'));
  xf = _place(xf, tf);
  if (xf == null) return null;

  // Rang
  int? phColor;
  final style = _c(sp, 'style');
  int? styleFill;
  int? styleLine;
  if (style != null) {
    styleFill = _colorIn(_c(style, 'fillRef'), env, null);
    styleLine = _colorIn(_c(style, 'lnRef'), env, null);
    phColor = styleFill;
  }

  _Fill fill = _readFill(spPr, env, phColor);
  if (!fill.found) fill = _readFill(lPr, env, phColor);
  if (!fill.found) fill = _readFill(mPr, env, phColor);
  int? fill1 = fill.none ? null : fill.c1;
  if (!fill.found && styleFill != null && ph == null) fill1 = styleFill;

  final ln = _c(spPr, 'ln') ?? _c(lPr, 'ln') ?? _c(mPr, 'ln');
  int? lineColor;
  var lineW = 0.0;
  if (ln != null) {
    final lf = _readFill(ln, env, styleLine);
    if (!lf.none) lineColor = lf.c1;
    lineW = _emu(_a(ln, 'w')) ?? 0;
    if (lineColor != null && lineW == 0) lineW = 1;
  }
  if (ln == null && styleLine != null && ph == null) {
    lineColor = styleLine;
    lineW = 1;
  }

  var geom = 'rect';
  var adj = 0.16667;
  final pg = _c(spPr, 'prstGeom');
  if (pg != null) {
    geom = _a(pg, 'prst') ?? 'rect';
    final gd = _c(_c(pg, 'avLst'), 'gd');
    final fm = _a(gd, 'fmla');
    if (fm != null) {
      final v = double.tryParse(fm.replaceFirst('val ', ''));
      if (v != null) adj = v / 100000;
    }
  }

  // Matn
  final tx = _c(sp, 'txBody');
  final paras = <PPara>[];
  var anchor = 't';
  var padL = 7.2;
  var padT = 3.6;
  var padR = 7.2;
  var padB = 3.6;
  var wrap = true;
  if (tx != null) {
    final bodyChain = <XmlElement?>[
      _c(tx, 'bodyPr'),
      _c(_c(lSp, 'txBody'), 'bodyPr'),
      _c(_c(mSp, 'txBody'), 'bodyPr'),
    ];
    anchor = _firstAttr(bodyChain, 'anchor') ?? 't';
    padL = _emu(_firstAttr(bodyChain, 'lIns')) ?? 7.2;
    padT = _emu(_firstAttr(bodyChain, 'tIns')) ?? 3.6;
    padR = _emu(_firstAttr(bodyChain, 'rIns')) ?? 7.2;
    padB = _emu(_firstAttr(bodyChain, 'bIns')) ?? 3.6;
    wrap = (_firstAttr(bodyChain, 'wrap') ?? 'square') != 'none';
    var scale = 1.0;
    final fit = _firstOf(bodyChain, 'normAutofit');
    if (fit != null) {
      final fs = double.tryParse(_a(fit, 'fontScale') ?? '');
      if (fs != null) scale = fs / 100000;
    }

    final styles = _c(_c(ctx.master?.root, 'txStyles'), _styleKind(ph));
    final lstChain = <XmlElement?>[
      _c(tx, 'lstStyle'),
      _c(_c(lSp, 'txBody'), 'lstStyle'),
      _c(_c(mSp, 'txBody'), 'lstStyle'),
      styles,
    ];
    _paragraphs(tx, lstChain, env, scale, paras, ctx, null);
  }

  final hasContent = fill1 != null || lineColor != null || paras.any((p) => p.runs.isNotEmpty);
  if (!hasContent) return null;

  return PShape(
    kind: 'sp',
    x: xf.x,
    y: xf.y,
    w: xf.w,
    h: xf.h,
    rot: xf.rot,
    flipH: xf.flipH,
    flipV: xf.flipV,
    geom: geom,
    adj: adj,
    fill: fill1,
    fill2: fill.none ? null : fill.c2,
    gradAngle: fill.angle,
    lineColor: lineColor,
    lineW: lineW,
    paras: paras,
    anchor: anchor,
    padL: padL,
    padT: padT,
    padR: padR,
    padB: padB,
    wrap: wrap,
  );
}

PShape? _connector(XmlElement n, _SlideCtx ctx, _Tf tf) {
  final spPr = _c(n, 'spPr');
  final xf = _place(_readXf(_c(spPr, 'xfrm')), tf);
  if (xf == null) return null;
  final style = _c(n, 'style');
  final styleLine = style == null ? null : _colorIn(_c(style, 'lnRef'), ctx.env, null);
  final ln = _c(spPr, 'ln');
  int? color;
  var width = 1.0;
  if (ln != null) {
    final lf = _readFill(ln, ctx.env, styleLine);
    if (!lf.none) color = lf.c1;
    width = _emu(_a(ln, 'w')) ?? 1;
  }
  color ??= styleLine ?? 0xFF000000;
  return PShape(
    kind: 'line',
    x: xf.x,
    y: xf.y,
    w: xf.w,
    h: xf.h,
    rot: xf.rot,
    flipH: xf.flipH,
    flipV: xf.flipV,
    geom: 'line',
    lineColor: color,
    lineW: math.max(width, 0.5),
  );
}

PShape? _picture(XmlElement n, _SlideCtx ctx, _Tf tf) {
  final spPr = _c(n, 'spPr');
  final xf = _place(_readXf(_c(spPr, 'xfrm')), tf);
  if (xf == null) return null;
  final bf = _c(n, 'blipFill');
  final blip = _c(bf, 'blip');
  final id = _a(blip, 'embed');
  String? image;
  if (id != null) {
    final entry = ctx.imageRels[id];
    if (entry != null) {
      final line = ctx.env.media.line(ctx.env.archive, entry);
      if (line != null) {
        final cut = line.indexOf(mediaSep);
        if (cut > 0 && line.substring(1, cut) == 'IMG') {
          image = line.substring(cut + 1);
        }
      }
    }
  }
  if (image == null) return null;
  final src = _c(bf, 'srcRect');
  double crop(String name) => (double.tryParse(_a(src, name) ?? '') ?? 0) / 100000;
  return PShape(
    kind: 'pic',
    x: xf.x,
    y: xf.y,
    w: xf.w,
    h: xf.h,
    rot: xf.rot,
    flipH: xf.flipH,
    flipV: xf.flipV,
    image: image,
    cropL: crop('l'),
    cropT: crop('t'),
    cropR: crop('r'),
    cropB: crop('b'),
  );
}

PShape? _frame(XmlElement n, _SlideCtx ctx, _Tf tf) {
  final xf = _place(_readXf(_c(n, 'xfrm')), tf);
  if (xf == null) return null;
  final data = _c(_c(n, 'graphic'), 'graphicData');
  final tbl = _c(data, 'tbl');
  if (tbl == null) {
    return PShape(kind: 'other', x: xf.x, y: xf.y, w: xf.w, h: xf.h);
  }

  final env = ctx.env;
  final cols = <double>[];
  for (final g in _c(tbl, 'tblGrid')?.childElements ?? const <XmlElement>[]) {
    cols.add((_emu(_a(g, 'w')) ?? 50) * tf.sx);
  }
  final tblPr = _c(tbl, 'tblPr');
  final firstRow = _bool(_a(tblPr, 'firstRow')) ?? false;
  final bandRow = _bool(_a(tblPr, 'bandRow')) ?? false;
  final accent = env.theme['accent1'] ?? 0xFF4472C4;
  final styled = _c(tblPr, 'tableStyleId') != null;

  final rows = <PRow>[];
  var ri = 0;
  for (final tr in tbl.findElements('tr')) {
    final cells = <PCell>[];
    for (final tc in tr.findElements('tc')) {
      final tcPr = _c(tc, 'tcPr');
      final span = int.tryParse(_a(tc, 'gridSpan') ?? '') ?? 1;
      if (_bool(_a(tc, 'hMerge')) ?? false) continue;
      final merged = _bool(_a(tc, 'vMerge')) ?? false;
      final f = _readFill(tcPr, env, null);
      int? fill = f.none ? null : f.c1;
      var header = false;
      if (fill == null && !f.none && styled) {
        if (ri == 0 && firstRow) {
          fill = accent;
          header = true;
        } else if (bandRow) {
          final odd = (ri - (firstRow ? 1 : 0)) % 2 == 0;
          fill = _mix(accent, 0xFFFFFFFF, odd ? 0.4 : 0.2);
        }
      }
      final paras = <PPara>[];
      final txBody = _c(tc, 'txBody');
      if (txBody != null) {
        _paragraphs(
          txBody,
          <XmlElement?>[_c(txBody, 'lstStyle')],
          env,
          1,
          paras,
          ctx,
          header ? 0xFFFFFFFF : null,
          forceBold: header,
          defaultSize: 18,
        );
      }
      cells.add(PCell(
        paras: paras,
        fill: fill,
        span: span,
        merged: merged,
        lineColor: styled ? 0xFFFFFFFF : null,
      ));
    }
    rows.add(PRow((_emu(_a(tr, 'h')) ?? 20) * tf.sy, cells));
    ri++;
  }
  return PShape(
    kind: 'tbl',
    x: xf.x,
    y: xf.y,
    w: xf.w,
    h: xf.h,
    cols: cols,
    rows: rows,
  );
}

const _autoFormats = <String>[
  'arabicPeriod',
  'arabicParenR',
  'arabicParenBoth',
  'alphaLcPeriod',
  'alphaUcPeriod',
  'alphaLcParenR',
  'alphaUcParenR',
  'romanLcPeriod',
  'romanUcPeriod',
];

String _autoNumber(String type, int n) {
  String letters(int v, bool upper) {
    var x = v;
    final sb = StringBuffer();
    while (x > 0) {
      x--;
      sb.write(String.fromCharCode((upper ? 65 : 97) + x % 26));
      x ~/= 26;
    }
    return sb.toString().split('').reversed.join();
  }

  String roman(int v, bool upper) {
    const vals = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1];
    const syms = ['M', 'CM', 'D', 'CD', 'C', 'XC', 'L', 'XL', 'X', 'IX', 'V', 'IV', 'I'];
    var x = math.min(v, 3999);
    final sb = StringBuffer();
    for (var i = 0; i < vals.length; i++) {
      while (x >= vals[i]) {
        sb.write(syms[i]);
        x -= vals[i];
      }
    }
    return upper ? sb.toString() : sb.toString().toLowerCase();
  }

  switch (type) {
    case 'arabicParenR':
      return '$n)';
    case 'arabicParenBoth':
      return '($n)';
    case 'alphaLcPeriod':
      return '${letters(n, false)}.';
    case 'alphaUcPeriod':
      return '${letters(n, true)}.';
    case 'alphaLcParenR':
      return '${letters(n, false)})';
    case 'alphaUcParenR':
      return '${letters(n, true)})';
    case 'romanLcPeriod':
      return '${roman(n, false)}.';
    case 'romanUcPeriod':
      return '${roman(n, true)}.';
    default:
      return '$n.';
  }
}

String _bulletChar(String c) {
  if (c.isEmpty) return '•';
  final code = c.codeUnitAt(0);
  if (code >= 0xF000 && code <= 0xF0FF) {
    if (code == 0xF0A7) return '▪';
    if (code == 0xF0D8) return '➢';
    if (code == 0xF0FC) return '✓';
    return '•';
  }
  return c;
}

void _paragraphs(
  XmlElement txBody,
  List<XmlElement?> lstChain,
  _Env env,
  double scale,
  List<PPara> out,
  _SlideCtx ctx,
  int? forcedColor, {
  bool forceBold = false,
  double defaultSize = 18,
}) {
  final counters = List<int>.filled(10, 0);

  for (final para in txBody.findElements('p')) {
    final pPr = _c(para, 'pPr');
    final lvl = (int.tryParse(_a(pPr, 'lvl') ?? '') ?? 0).clamp(0, 8);
    final lvlEls = <XmlElement?>[
      pPr,
      for (final l in lstChain) _c(l, 'lvl${lvl + 1}pPr'),
    ];
    final defs = <XmlElement?>[for (final e in lvlEls) _c(e, 'defRPr')];

    final alignRaw = _firstAttr(lvlEls, 'algn');
    final align = switch (alignRaw) {
      'ctr' => 'center',
      'r' => 'right',
      'just' || 'dist' => 'both',
      _ => 'left',
    };
    final marL = _emu(_firstAttr(lvlEls, 'marL')) ?? 0;
    final indent = _emu(_firstAttr(lvlEls, 'indent')) ?? 0;

    final szAttr = _firstAttr(defs, 'sz');
    final baseSize = (szAttr == null
            ? defaultSize
            : (double.tryParse(szAttr) ?? defaultSize * 100) / 100) *
        scale;

    // Oraliqlar
    double spacing(String name) {
      final el = _firstOf(lvlEls, name);
      if (el == null) return 0;
      final pts = _c(el, 'spcPts');
      if (pts != null) return (double.tryParse(_a(pts, 'val') ?? '') ?? 0) / 100;
      final pct = _c(el, 'spcPct');
      if (pct != null) {
        return (double.tryParse(_a(pct, 'val') ?? '') ?? 0) / 100000 * baseSize * 1.2;
      }
      return 0;
    }

    var lineMul = 1.0;
    final ls = _firstOf(lvlEls, 'lnSpc');
    final lsPct = _c(ls, 'spcPct');
    if (lsPct != null) {
      lineMul = (double.tryParse(_a(lsPct, 'val') ?? '') ?? 100000) / 100000;
    }

    // Marker
    String? bullet;
    for (final e in lvlEls) {
      if (e == null) continue;
      if (_c(e, 'buNone') != null) break;
      final ch = _c(e, 'buChar');
      if (ch != null) {
        bullet = _bulletChar(_a(ch, 'char') ?? '•');
        break;
      }
      final auto = _c(e, 'buAutoNum');
      if (auto != null) {
        final type = _a(auto, 'type') ?? 'arabicPeriod';
        final start = int.tryParse(_a(auto, 'startAt') ?? '') ?? 1;
        counters[lvl] = counters[lvl] == 0 ? start : counters[lvl] + 1;
        bullet = _autoNumber(_autoFormats.contains(type) ? type : 'arabicPeriod', counters[lvl]);
        break;
      }
    }
    if (bullet == null) {
      counters[lvl] = 0;
    }
    for (var i = lvl + 1; i < counters.length; i++) {
      counters[i] = 0;
    }

    final runs = <PRun>[];
    void addRun(XmlElement? rPr, String text) {
      if (text.isEmpty) return;
      final chain = <XmlElement?>[rPr, ...defs];
      final sz = _firstAttr(chain, 'sz');
      final size = (sz == null ? baseSize : (double.tryParse(sz) ?? baseSize * 100) / 100 * scale);
      int? color = forcedColor;
      if (color == null) {
        for (final e in chain) {
          final fill = _c(e, 'solidFill');
          if (fill != null) {
            color = _colorIn(fill, env, null);
            if (color != null) break;
          }
        }
      }
      final latin = _firstOf(chain, 'latin');
      final u = _firstAttr(chain, 'u');
      final st = _firstAttr(chain, 'strike');
      final base = double.tryParse(_firstAttr(chain, 'baseline') ?? '') ?? 0;
      runs.add(PRun(
        text: text,
        size: size,
        bold: forceBold || (_bool(_firstAttr(chain, 'b')) ?? false),
        italic: _bool(_firstAttr(chain, 'i')) ?? false,
        underline: u != null && u != 'none',
        strike: st != null && st != 'noStrike',
        color: color,
        font: _a(latin, 'typeface'),
        baseline: base > 0 ? 1 : (base < 0 ? -1 : 0),
      ));
    }

    for (final n in para.childElements) {
      switch (n.name.local) {
        case 'r':
          addRun(_c(n, 'rPr'), _c(n, 't')?.innerText ?? '');
          break;
        case 'br':
          addRun(_c(n, 'rPr'), '\n');
          break;
        case 'fld':
          addRun(_c(n, 'rPr'), _c(n, 't')?.innerText ?? '');
          break;
      }
    }

    var paraSize = baseSize;
    final endRp = _c(para, 'endParaRPr');
    final es = _a(endRp, 'sz');
    if (es != null) paraSize = (double.tryParse(es) ?? baseSize * 100) / 100 * scale;

    final text = runs.map((r) => r.text).join();
    if (text.trim().isNotEmpty) {
      ctx.plain.write(text);
      ctx.plain.write('\n');
    }

    out.add(PPara(
      runs: runs,
      align: align,
      marL: marL,
      indent: indent,
      before: spacing('spcBef'),
      after: spacing('spcAft'),
      lineMul: lineMul,
      bullet: runs.isEmpty ? null : bullet,
      size: paraSize,
    ));
  }
}
