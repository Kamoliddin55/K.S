import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/widgets.dart' as fw show Text;
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import 'package:share_plus/share_plus.dart';

import 'archive_reader.dart';
import 'dialogs.dart';
import 'document_parser.dart';
import 'l10n.dart';
import 'library.dart';
import 'pptx_model.dart';
import 'text_screen.dart';
import 'user_data.dart';

// =====================================================================
// Slayd chizish
// =====================================================================

String? _family(String? font) {
  if (font == null) return null;
  final f = font.toLowerCase();
  if (f.contains('courier') || f.contains('consolas') || f.contains('mono')) {
    return 'monospace';
  }
  if (f.contains('times') ||
      f.contains('cambria') ||
      f.contains('georgia') ||
      f.contains('garamond') ||
      f.contains('palatino')) {
    return 'serif';
  }
  return null;
}

Path _geomPath(String geom, Size size, double adj) {
  final w = size.width;
  final h = size.height;
  final path = Path();
  switch (geom) {
    case 'ellipse':
      path.addOval(Rect.fromLTWH(0, 0, w, h));
      break;
    case 'roundRect':
    case 'round2SameRect':
    case 'round1Rect':
    case 'snipRoundRect':
      path.addRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(0, 0, w, h),
          Radius.circular(math.min(w, h) * adj.clamp(0.0, 0.5)),
        ),
      );
      break;
    case 'flowChartTerminator':
      path.addRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(0, 0, w, h),
          Radius.circular(math.min(w, h) / 2),
        ),
      );
      break;
    case 'triangle':
      path
        ..moveTo(w / 2, 0)
        ..lineTo(w, h)
        ..lineTo(0, h)
        ..close();
      break;
    case 'rtTriangle':
      path
        ..moveTo(0, 0)
        ..lineTo(0, h)
        ..lineTo(w, h)
        ..close();
      break;
    case 'diamond':
    case 'flowChartDecision':
      path
        ..moveTo(w / 2, 0)
        ..lineTo(w, h / 2)
        ..lineTo(w / 2, h)
        ..lineTo(0, h / 2)
        ..close();
      break;
    case 'parallelogram':
    case 'flowChartInputOutput':
      final o = w * 0.2;
      path
        ..moveTo(o, 0)
        ..lineTo(w, 0)
        ..lineTo(w - o, h)
        ..lineTo(0, h)
        ..close();
      break;
    case 'hexagon':
      final o = w * 0.25;
      path
        ..moveTo(o, 0)
        ..lineTo(w - o, 0)
        ..lineTo(w, h / 2)
        ..lineTo(w - o, h)
        ..lineTo(o, h)
        ..lineTo(0, h / 2)
        ..close();
      break;
    case 'homePlate':
    case 'pentagon':
      final o = math.min(w * 0.3, h * 0.5);
      path
        ..moveTo(0, 0)
        ..lineTo(w - o, 0)
        ..lineTo(w, h / 2)
        ..lineTo(w - o, h)
        ..lineTo(0, h)
        ..close();
      break;
    case 'chevron':
      final o = math.min(w * 0.3, h * 0.5);
      path
        ..moveTo(0, 0)
        ..lineTo(w - o, 0)
        ..lineTo(w, h / 2)
        ..lineTo(w - o, h)
        ..lineTo(0, h)
        ..lineTo(o, h / 2)
        ..close();
      break;
    case 'plus':
    case 'mathPlus':
      final a = math.min(w, h) * 0.33;
      path
        ..moveTo(a, 0)
        ..lineTo(w - a, 0)
        ..lineTo(w - a, a)
        ..lineTo(w, a)
        ..lineTo(w, h - a)
        ..lineTo(w - a, h - a)
        ..lineTo(w - a, h)
        ..lineTo(a, h)
        ..lineTo(a, h - a)
        ..lineTo(0, h - a)
        ..lineTo(0, a)
        ..lineTo(a, a)
        ..close();
      break;
    case 'star5':
      final cx = w / 2;
      final cy = h / 2;
      for (var i = 0; i < 10; i++) {
        final rr = i.isEven ? 1.0 : 0.4;
        final ang = -math.pi / 2 + i * math.pi / 5;
        final px = cx + math.cos(ang) * cx * rr;
        final py = cy + math.sin(ang) * cy * rr;
        if (i == 0) {
          path.moveTo(px, py);
        } else {
          path.lineTo(px, py);
        }
      }
      path.close();
      break;
    case 'upArrow':
    case 'downArrow':
      final tw = w * 0.5;
      final head = math.min(h * 0.4, w);
      final up = geom == 'upArrow';
      final ys = up ? [head, 0.0, head, h, h] : [h - head, h, h - head, 0.0, 0.0];
      path
        ..moveTo((w - tw) / 2, up ? h : 0)
        ..lineTo((w - tw) / 2, ys[0])
        ..lineTo(0, ys[0])
        ..lineTo(w / 2, ys[1])
        ..lineTo(w, ys[0])
        ..lineTo((w + tw) / 2, ys[0])
        ..lineTo((w + tw) / 2, up ? h : 0)
        ..close();
      break;
    case 'rightArrow':
      final th = h * 0.5;
      final head = math.min(w * 0.4, h);
      path
        ..moveTo(0, (h - th) / 2)
        ..lineTo(w - head, (h - th) / 2)
        ..lineTo(w - head, 0)
        ..lineTo(w, h / 2)
        ..lineTo(w - head, h)
        ..lineTo(w - head, (h + th) / 2)
        ..lineTo(0, (h + th) / 2)
        ..close();
      break;
    case 'leftArrow':
      final th = h * 0.5;
      final head = math.min(w * 0.4, h);
      path
        ..moveTo(w, (h - th) / 2)
        ..lineTo(head, (h - th) / 2)
        ..lineTo(head, 0)
        ..lineTo(0, h / 2)
        ..lineTo(head, h)
        ..lineTo(head, (h + th) / 2)
        ..lineTo(w, (h + th) / 2)
        ..close();
      break;
    default:
      path.addRect(Rect.fromLTWH(0, 0, w, h));
  }
  return path;
}

class _ShapePainter extends CustomPainter {
  final PShape shape;
  final double scale;
  _ShapePainter(this.shape, this.scale);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    if (shape.flipH || shape.flipV) {
      canvas.translate(shape.flipH ? size.width : 0, shape.flipV ? size.height : 0);
      canvas.scale(shape.flipH ? -1 : 1, shape.flipV ? -1 : 1);
    }
    if (shape.kind == 'line') {
      final paint = Paint()
        ..color = Color(shape.lineColor ?? 0xFF000000)
        ..strokeWidth = math.max(0.8, shape.lineW * scale)
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(Offset.zero, Offset(size.width, size.height), paint);
      canvas.restore();
      return;
    }

    final path = _geomPath(shape.geom, size, shape.adj);
    final c1 = shape.fill;
    if (c1 != null) {
      final paint = Paint()..style = PaintingStyle.fill;
      final c2 = shape.fill2;
      if (c2 != null && c2 != c1) {
        final a = shape.gradAngle * math.pi / 180;
        final dx = math.cos(a);
        final dy = math.sin(a);
        paint.shader = LinearGradient(
          begin: Alignment(-dx, -dy),
          end: Alignment(dx, dy),
          colors: [Color(c1), Color(c2)],
        ).createShader(Offset.zero & size);
      } else {
        paint.color = Color(c1);
      }
      canvas.drawPath(path, paint);
    }
    final lc = shape.lineColor;
    if (lc != null && shape.lineW > 0) {
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..color = Color(lc)
          ..strokeWidth = math.max(0.6, shape.lineW * scale),
      );
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(_ShapePainter old) =>
      old.shape != shape || old.scale != scale;
}

class SlideView extends StatelessWidget {
  final PDeck deck;
  final PSlide slide;
  const SlideView({super.key, required this.deck, required this.slide});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, cons) {
        final w = cons.maxWidth.isFinite ? cons.maxWidth : 360.0;
        final s = w / deck.w;
        final h = deck.h * s;

        BoxDecoration bg;
        final b1 = slide.bg;
        final b2 = slide.bg2;
        if (b1 == null) {
          bg = const BoxDecoration(color: Colors.white);
        } else if (b2 != null && b2 != b1) {
          bg = BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(b1), Color(b2)],
            ),
          );
        } else {
          bg = BoxDecoration(color: Color(b1));
        }

        return SizedBox(
          width: w,
          height: h,
          child: ClipRect(
            child: DecoratedBox(
              decoration: bg,
              child: Stack(
                clipBehavior: Clip.hardEdge,
                children: [
                  for (final sh in slide.shapes) _place(sh, s),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _place(PShape sh, double s) {
    Widget child;
    switch (sh.kind) {
      case 'pic':
        child = _picture(sh, s);
        break;
      case 'tbl':
        child = _table(sh, s);
        break;
      case 'line':
        child = CustomPaint(
          size: Size.infinite,
          painter: _ShapePainter(sh, s),
        );
        break;
      case 'other':
        child = const SizedBox.shrink();
        break;
      default:
        child = Stack(
          fit: StackFit.expand,
          children: [
            if (sh.fill != null || sh.lineColor != null)
              CustomPaint(painter: _ShapePainter(sh, s)),
            if (sh.paras.isNotEmpty) _text(sh, s),
          ],
        );
    }

    if (sh.rot != 0) {
      child = Transform.rotate(angle: sh.rot * math.pi / 180, child: child);
    }
    final lineBox = sh.kind == 'line';
    return Positioned(
      left: sh.x * s,
      top: sh.y * s,
      width: math.max(sh.w * s, lineBox ? 1 : 0),
      height: math.max(sh.h * s, lineBox ? 1 : 0),
      child: child,
    );
  }

  Widget _picture(PShape sh, double s) {
    final w = sh.w * s;
    final h = sh.h * s;
    final cw = (1 - sh.cropL - sh.cropR).clamp(0.05, 1.0);
    final ch = (1 - sh.cropT - sh.cropB).clamp(0.05, 1.0);
    final sw = w / cw;
    final shh = h / ch;
    Widget img = Image.file(
      File(sh.image!),
      width: sw,
      height: shh,
      fit: BoxFit.fill,
      errorBuilder: (_, __, ___) => const SizedBox.shrink(),
    );
    img = ClipRect(
      child: OverflowBox(
        alignment: Alignment.topLeft,
        minWidth: sw,
        maxWidth: sw,
        minHeight: shh,
        maxHeight: shh,
        child: Transform.translate(
          offset: Offset(-sh.cropL * sw, -sh.cropT * shh),
          child: img,
        ),
      ),
    );
    if (sh.flipH || sh.flipV) {
      img = Transform.scale(
        scaleX: sh.flipH ? -1 : 1,
        scaleY: sh.flipV ? -1 : 1,
        child: img,
      );
    }
    return img;
  }

  Widget _text(PShape sh, double s) {
    final y = switch (sh.anchor) {
      'ctr' => 0.0,
      'b' => 1.0,
      _ => -1.0,
    };
    return Padding(
      padding: EdgeInsets.fromLTRB(
        sh.padL * s,
        sh.padT * s,
        sh.padR * s,
        sh.padB * s,
      ),
      child: OverflowBox(
        alignment: Alignment(-1, y),
        minHeight: 0,
        maxHeight: double.infinity,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [for (final pa in sh.paras) _paragraph(pa, s)],
        ),
      ),
    );
  }

  Widget _paragraph(PPara pa, double s) {
    final height = 1.2 * pa.lineMul;
    final spans = <InlineSpan>[];
    for (final r in pa.runs) {
      final decorations = <TextDecoration>[
        if (r.underline) TextDecoration.underline,
        if (r.strike) TextDecoration.lineThrough,
      ];
      spans.add(
        TextSpan(
          text: r.text,
          style: TextStyle(
            fontSize: math.max(r.size * s * (r.baseline != 0 ? 0.7 : 1.0), 1),
            fontWeight: r.bold ? FontWeight.w700 : FontWeight.w400,
            fontStyle: r.italic ? FontStyle.italic : FontStyle.normal,
            color: Color(r.color ?? 0xFF000000),
            decoration: decorations.isEmpty
                ? TextDecoration.none
                : TextDecoration.combine(decorations),
            fontFamily: _family(r.font),
            height: height,
          ),
        ),
      );
    }

    final align = switch (pa.align) {
      'center' => TextAlign.center,
      'right' => TextAlign.right,
      'both' => TextAlign.justify,
      _ => TextAlign.left,
    };

    Widget body;
    if (spans.isEmpty) {
      body = SizedBox(height: math.max(pa.size * s * height, 1));
    } else {
      body = fw.Text.rich(TextSpan(children: spans), textAlign: align);
    }

    var left = pa.marL * s;
    if (pa.bullet != null) {
      final hang = math.max(-pa.indent, pa.size * 0.9) * s;
      final first = pa.runs.isEmpty ? null : pa.runs.first;
      final style = TextStyle(
        fontSize: math.max((first?.size ?? pa.size) * s, 1),
        color: Color(first?.color ?? 0xFF000000),
        height: height,
      );
      left = math.max(0.0, left - hang);
      body = Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: hang, child: fw.Text(pa.bullet!, style: style)),
          Expanded(child: body),
        ],
      );
    } else if (pa.indent > 0) {
      left += pa.indent * s;
    }

    return Padding(
      padding: EdgeInsets.only(
        left: left,
        top: pa.before * s,
        bottom: pa.after * s,
      ),
      child: body,
    );
  }

  Widget _table(PShape sh, double s) {
    final rows = <Widget>[];
    for (final row in sh.rows) {
      final cells = <Widget>[];
      var col = 0;
      for (final cell in row.cells) {
        var w = 0.0;
        for (var i = col; i < col + cell.span && i < sh.cols.length; i++) {
          w += sh.cols[i];
        }
        col += cell.span;
        final lc = cell.lineColor;
        cells.add(
          Container(
            width: w * s,
            padding: EdgeInsets.symmetric(horizontal: 7 * s, vertical: 3.6 * s),
            decoration: BoxDecoration(
              color: cell.fill == null ? null : Color(cell.fill!),
              border: lc == null
                  ? null
                  : Border.all(color: Color(lc), width: math.max(0.6, s)),
            ),
            child: cell.merged
                ? const SizedBox.shrink()
                : Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisSize: MainAxisSize.min,
                    children: [for (final pa in cell.paras) _paragraph(pa, s)],
                  ),
          ),
        );
      }
      rows.add(
        ConstrainedBox(
          constraints: BoxConstraints(minHeight: row.height * s),
          child: IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: cells,
            ),
          ),
        ),
      );
    }
    return OverflowBox(
      alignment: Alignment.topLeft,
      minHeight: 0,
      maxHeight: double.infinity,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: rows,
      ),
    );
  }
}

// =====================================================================
// Ekran
// =====================================================================

class PptScreen extends StatefulWidget {
  final String path;
  const PptScreen({super.key, required this.path});

  @override
  State<PptScreen> createState() => _PptScreenState();
}

class _PptScreenState extends State<PptScreen> {
  final _data = UserData.instance;
  final _itemScroll = ItemScrollController();
  final _positions = ItemPositionsListener.create();
  final _searchController = TextEditingController();
  final _searchFocus = FocusNode();

  late final String _key;
  late final bool _persist;

  PDeck? _deck;
  String? _error;
  bool _loading = true;
  int _start = 0;
  int _top = 0;
  Timer? _saveTimer;

  bool _searching = false;
  String _query = '';
  List<int> _matches = const <int>[];
  int _matchPos = -1;

  @override
  void initState() {
    super.initState();
    _key = p.basename(widget.path);
    _persist = Library.isInLibrary(widget.path);
    _start = _persist ? (_data.position(_key) ?? 0) : 0;
    _top = _start;
    _positions.itemPositions.addListener(_onPositions);
    _load();
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    _save();
    _positions.itemPositions.removeListener(_onPositions);
    _searchController.dispose();
    _searchFocus.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      String? mediaDir;
      try {
        final cache = await ArchiveReader.cacheDirectory();
        final id = sha1
            .convert(utf8.encode(widget.path))
            .toString()
            .substring(0, 16);
        mediaDir = p.join(cache.path, 'media', id);
      } catch (_) {
        mediaDir = null;
      }
      final deck = await loadPptx(widget.path, mediaDir: mediaDir);
      if (!mounted) return;
      setState(() {
        _deck = deck;
        _start = _start.clamp(0, deck.slides.length - 1);
        _top = _start;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = errorText(e);
        _loading = false;
      });
    }
  }

  void _onPositions() {
    final visible = _positions.itemPositions.value
        .where((x) => x.itemTrailingEdge > 0.05)
        .toList();
    if (visible.isEmpty) return;
    visible.sort((a, b) => a.itemLeadingEdge.compareTo(b.itemLeadingEdge));
    final first = visible.first.index;
    if (first != _top) {
      _top = first;
      _saveTimer?.cancel();
      _saveTimer = Timer(const Duration(seconds: 1), _save);
    }
  }

  void _save() {
    if (_persist) _data.setPosition(_key, _top);
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  void _scrollTo(int index) {
    if (!_itemScroll.isAttached) return;
    _itemScroll.scrollTo(
      index: index,
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOut,
    );
  }

  // ---------- Qidiruv ----------

  void _startSearch() {
    setState(() => _searching = true);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _searchFocus.requestFocus();
    });
  }

  void _closeSearch() {
    _searchController.clear();
    setState(() {
      _searching = false;
      _query = '';
      _matches = const <int>[];
      _matchPos = -1;
    });
  }

  void _onQuery(String value) {
    final q = value.trim().toLowerCase();
    if (q.isEmpty) {
      setState(() {
        _query = '';
        _matches = const <int>[];
        _matchPos = -1;
      });
      return;
    }
    final found = <int>[];
    final slides = _deck!.slides;
    for (var i = 0; i < slides.length; i++) {
      if (slides[i].plain.toLowerCase().contains(q)) found.add(i);
    }
    setState(() {
      _query = q;
      _matches = found;
      _matchPos = found.isEmpty ? -1 : 0;
    });
    if (found.isNotEmpty) _scrollTo(found.first);
  }

  void _step(int delta) {
    if (_matches.isEmpty) return;
    setState(() {
      _matchPos = (_matchPos + delta) % _matches.length;
      if (_matchPos < 0) _matchPos += _matches.length;
    });
    _scrollTo(_matches[_matchPos]);
  }

  // ---------- Amallar ----------

  void _present(int index) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => _SlideShow(deck: _deck!, initial: index),
      ),
    );
  }

  Future<void> _share() async {
    try {
      await Share.shareXFiles([XFile(widget.path)]);
    } catch (e) {
      _snack("Ulashib bo'lmadi: ${errorText(e)}");
    }
  }

  Future<void> _onMenu(String value) async {
    switch (value) {
      case 'present':
        if (_deck != null) _present(_top);
        break;
      case 'text':
        await Navigator.of(context).pushReplacement(
          MaterialPageRoute<void>(
            builder: (_) => TextScreen(path: widget.path),
          ),
        );
        break;
      case 'share':
        await _share();
        break;
      case 'external':
        await OpenFilex.open(widget.path);
        break;
    }
  }

  // ---------- Ko'rinish ----------

  Widget _mediaTile(String entry) {
    final cut = entry.indexOf(mediaSep);
    final tag = entry.substring(0, cut);
    final path = entry.substring(cut + 1);
    final name = p.basename(path).replaceFirst(RegExp(r'^\d+_'), '');
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: Material(
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
        child: ListTile(
          dense: true,
          leading: Icon(tag == 'VID' ? Icons.play_circle_outline : Icons.audiotrack),
          title: fw.Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(tag == 'VID' ? 'Video' : 'Audio'),
          onTap: () => OpenFilex.open(path),
        ),
      ),
    );
  }

  Widget _slideItem(int i) {
    final deck = _deck!;
    final slide = deck.slides[i];
    final scheme = Theme.of(context).colorScheme;
    final isCurrent = _matchPos >= 0 &&
        _matchPos < _matches.length &&
        _matches[_matchPos] == i;
    final isMatch = _matches.contains(i);
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 4),
            child: fw.Text(
              '${i + 1} / ${deck.slides.length}',
              style: TextStyle(color: scheme.outline, fontSize: 12),
            ),
          ),
          GestureDetector(
            onTap: () => _present(i),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(6),
                border: Border.all(
                  color: isCurrent
                      ? Colors.orange
                      : (isMatch ? scheme.primary : scheme.outlineVariant),
                  width: isCurrent ? 3 : (isMatch ? 2 : 1),
                ),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x22000000),
                    blurRadius: 6,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(5),
                child: SlideView(deck: deck, slide: slide),
              ),
            ),
          ),
          for (final m in slide.media) _mediaTile(m),
        ],
      ),
    );
  }

  Widget _body() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, size: 48),
              const SizedBox(height: 12),
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () => _onMenu('text'),
                child: Text('Matn sifatida ochish'),
              ),
            ],
          ),
        ),
      );
    }
    final deck = _deck!;
    return ScrollablePositionedList.builder(
      itemCount: deck.slides.length,
      itemScrollController: _itemScroll,
      itemPositionsListener: _positions,
      initialScrollIndex: _start,
      itemBuilder: (context, i) => _slideItem(i),
    );
  }

  PreferredSizeWidget _appBar() {
    if (_searching) {
      return AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: _closeSearch,
        ),
        title: TextField(
          controller: _searchController,
          focusNode: _searchFocus,
          onChanged: _onQuery,
          onSubmitted: (_) => _step(1),
          textInputAction: TextInputAction.search,
          decoration: InputDecoration(
            hintText: t('Qidirish...'),
            border: InputBorder.none,
          ),
        ),
        actions: [
          if (_query.isNotEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text(
                  _matches.isEmpty ? '0' : '${_matchPos + 1}/${_matches.length}',
                ),
              ),
            ),
          IconButton(
            tooltip: t('Oldingi'),
            icon: const Icon(Icons.keyboard_arrow_up),
            onPressed: _matches.isEmpty ? null : () => _step(-1),
          ),
          IconButton(
            tooltip: t('Keyingi'),
            icon: const Icon(Icons.keyboard_arrow_down),
            onPressed: _matches.isEmpty ? null : () => _step(1),
          ),
        ],
      );
    }
    return AppBar(
      title: Text(
        Library.displayName(widget.path),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      actions: [
        if (_deck != null) ...[
          IconButton(
            tooltip: t('Namoyish'),
            icon: const Icon(Icons.slideshow),
            onPressed: () => _present(_top),
          ),
          IconButton(
            tooltip: t('Qidirish'),
            icon: const Icon(Icons.search),
            onPressed: _startSearch,
          ),
        ],
        PopupMenuButton<String>(
          onSelected: _onMenu,
          itemBuilder: (_) => [
            PopupMenuItem(value: 'text', child: Text('Matn sifatida ochish')),
            PopupMenuItem(value: 'share', child: Text('Ulashish')),
            PopupMenuItem(value: 'external', child: Text('Boshqa ilovada ochish')),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: _appBar(), body: _body());
  }
}

// =====================================================================
// Namoyish rejimi
// =====================================================================

class _SlideShow extends StatefulWidget {
  final PDeck deck;
  final int initial;
  const _SlideShow({required this.deck, required this.initial});

  @override
  State<_SlideShow> createState() => _SlideShowState();
}

class _SlideShowState extends State<_SlideShow> {
  late final PageController _controller;
  late int _page;
  bool _bars = true;

  @override
  void initState() {
    super.initState();
    _page = widget.initial.clamp(0, widget.deck.slides.length - 1);
    _controller = PageController(initialPage: _page);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final deck = widget.deck;
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => setState(() => _bars = !_bars),
            child: PageView.builder(
              controller: _controller,
              itemCount: deck.slides.length,
              onPageChanged: (i) => setState(() => _page = i),
              itemBuilder: (context, i) => Center(
                child: InteractiveViewer(
                  minScale: 1,
                  maxScale: 5,
                  child: AspectRatio(
                    aspectRatio: deck.w / deck.h,
                    child: SlideView(deck: deck, slide: deck.slides[i]),
                  ),
                ),
              ),
            ),
          ),
          if (_bars)
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: SafeArea(
                child: Row(
                  children: [
                    IconButton(
                      color: Colors.white,
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                    const Spacer(),
                    Container(
                      margin: const EdgeInsets.only(right: 12),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: fw.Text(
                        '${_page + 1} / ${deck.slides.length}',
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
