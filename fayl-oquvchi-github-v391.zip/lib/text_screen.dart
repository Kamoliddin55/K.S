import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import 'package:share_plus/share_plus.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import 'archive_reader.dart';
import 'dialogs.dart';
import 'document_parser.dart';
import 'l10n.dart';
import 'library.dart';
import 'settings.dart';
import 'settings_screen.dart';
import 'theme.dart';
import 'user_data.dart';

/// Matn ko'rinishidagi hujjatlar: TXT, HTML, DOCX, XLSX, PPTX, ePub.
class TextScreen extends StatefulWidget {
  final String path;
  const TextScreen({super.key, required this.path});

  @override
  State<TextScreen> createState() => _TextScreenState();
}

class _Row {
  final String text;
  final bool header;

  /// Media qatori bo'lsa: IMG, VID yoki AUD va fayl yo'li.
  final String? media;
  final String? path;
  const _Row(this.text, {this.header = false, this.media, this.path});

  static _Row parse(String line) {
    if (line.startsWith(mediaMark)) {
      final cut = line.indexOf(mediaSep);
      if (cut > 1) {
        return _Row(
          '',
          media: line.substring(1, cut),
          path: line.substring(cut + 1),
        );
      }
    }
    return _Row(line);
  }
}

class _TextScreenState extends State<TextScreen> {
  final _settings = AppSettings.instance;
  final _data = UserData.instance;
  final _itemScroll = ItemScrollController();
  final _positions = ItemPositionsListener.create();
  final _progress = ValueNotifier<double>(0);
  final _top = ValueNotifier<int>(0);
  final _searchController = TextEditingController();
  final _searchFocus = FocusNode();

  late final DocKind _kind;
  late final String _key;
  late final bool _persist;

  List<_Row> _rows = const <_Row>[];
  bool _loading = true;
  String? _error;
  int _startIndex = 0;

  bool _searching = false;
  String _query = '';
  RegExp? _regex;
  List<int> _matches = const <int>[];
  int _matchPos = -1;

  Timer? _saveTimer;

  final Map<int, Offset> _pointers = <int, Offset>{};
  double? _pinchStart;
  double _pinchBase = 16;
  double? _liveSize;

  FlutterTts? _tts;
  bool _speaking = false;
  bool _full = false;
  String? _encoding;
  List<int> _headers = const <int>[];

  bool get _isPlainText => _kind == DocKind.text || _kind == DocKind.html;

  @override
  void initState() {
    super.initState();
    _kind = kindOf(widget.path);
    if (Library.isInLibrary(widget.path)) {
      _encoding = _data.encoding(p.basename(widget.path));
    }
    _key = p.basename(widget.path);
    _persist = Library.isInLibrary(widget.path);
    _startIndex = _persist ? (_data.position(_key) ?? 0) : 0;
    _top.value = _startIndex;
    _positions.itemPositions.addListener(_onPositions);
    _settings.addListener(_applyWakelock);
    _applyWakelock();
    _load();
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    _savePosition();
    _positions.itemPositions.removeListener(_onPositions);
    _settings.removeListener(_applyWakelock);
    _releaseWakelock();
    _speaking = false;
    _tts?.stop().catchError((_) {});
    if (_full) {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    }
    _progress.dispose();
    _top.dispose();
    _searchController.dispose();
    _searchFocus.dispose();
    super.dispose();
  }

  // ---------- Yuklash ----------

  Future<void> _load() async {
    try {
      String? mediaDir;
      try {
        final cache = await ArchiveReader.cacheDirectory();
        final id = sha1
            .convert(utf8.encode(widget.path))
            .toString()
            .substring(0, 16);
        mediaDir = p.join(cache.path, 'media', id);
      } catch (_) {
        mediaDir = null;
      }

      final sections = await parseDocumentIsolated(
        widget.path,
        _kind,
        encoding: _encoding,
        mediaDir: mediaDir,
      );
      final rows = <_Row>[];
      for (final s in sections) {
        if (s.title.isNotEmpty) rows.add(_Row(s.title, header: true));
        for (final line in s.lines) {
          rows.add(_Row.parse(line));
        }
      }
      if (!mounted) return;

      var start = _startIndex;
      if (rows.isEmpty) {
        start = 0;
      } else if (start < 0) {
        start = 0;
      } else if (start >= rows.length) {
        start = rows.length - 1;
      }

      setState(() {
        _rows = rows;
        _headers = [
          for (var i = 0; i < rows.length; i++)
            if (rows[i].header) i,
        ];
        _startIndex = start;
        _top.value = start;
        _progress.value = rows.isEmpty ? 0 : (start + 1) / rows.length;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = errorText(e);
        _loading = false;
      });
    }
  }

  // ---------- Ekran o'chmasligi ----------

  Future<void> _applyWakelock() async {
    try {
      if (_settings.keepScreenOn) {
        await WakelockPlus.enable();
      } else {
        await WakelockPlus.disable();
      }
    } catch (_) {}
  }

  Future<void> _releaseWakelock() async {
    try {
      await WakelockPlus.disable();
    } catch (_) {}
  }

  // ---------- O'qish joyi ----------

  void _onPositions() {
    if (_rows.isEmpty) return;
    final positions = _positions.itemPositions.value;
    if (positions.isEmpty) return;

    int? top;
    var atEnd = false;
    for (final pos in positions) {
      if (pos.itemTrailingEdge > 0 && (top == null || pos.index < top)) {
        top = pos.index;
      }
      if (pos.index == _rows.length - 1 && pos.itemTrailingEdge <= 1.001) {
        atEnd = true;
      }
    }
    if (top == null) return;

    _progress.value = atEnd ? 1.0 : (top + 1) / _rows.length;
    if (top != _top.value) {
      _top.value = top;
      _scheduleSave();
    }
  }

  void _scheduleSave() {
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 600), _savePosition);
  }

  void _savePosition() {
    if (_persist && _rows.isNotEmpty) {
      _data.setPosition(_key, _top.value);
      _data.setProgress(_key, _progress.value);
    }
  }

  void _jumpTo(int index) {
    if (index < 0 || index >= _rows.length) return;
    if (_itemScroll.isAttached) _itemScroll.jumpTo(index: index);
  }

  void _scrollTo(int index) {
    if (index < 0 || index >= _rows.length) return;
    if (_itemScroll.isAttached) {
      _itemScroll.scrollTo(
        index: index,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeInOut,
      );
    }
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  // ---------- Qidirish ----------

  void _startSearch() {
    setState(() => _searching = true);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _searchFocus.requestFocus();
    });
  }

  void _closeSearch() {
    _searchController.clear();
    setState(() {
      _searching = false;
      _query = '';
      _regex = null;
      _matches = const <int>[];
      _matchPos = -1;
    });
  }

  void _onQuery(String value) {
    final q = value.trim();
    if (q.isEmpty) {
      setState(() {
        _query = '';
        _regex = null;
        _matches = const <int>[];
        _matchPos = -1;
      });
      return;
    }

    final regex = RegExp(RegExp.escape(q), caseSensitive: false);
    final matches = <int>[];
    for (var i = 0; i < _rows.length; i++) {
      if (regex.hasMatch(_rows[i].text)) matches.add(i);
    }

    var pos = matches.indexWhere((m) => m >= _top.value);
    if (pos < 0 && matches.isNotEmpty) pos = 0;

    setState(() {
      _query = q;
      _regex = regex;
      _matches = matches;
      _matchPos = matches.isEmpty ? -1 : pos;
    });
    if (_matchPos >= 0) _scrollTo(_matches[_matchPos]);
  }

  void _step(int delta) {
    if (_matches.isEmpty) return;
    final next = (_matchPos + delta) % _matches.length;
    setState(() => _matchPos = next);
    _scrollTo(_matches[next]);
  }

  // ---------- Xatcho'plar ----------

  Future<void> _toggleBookmark() async {
    if (!_persist) {
      _snack("Xatcho'p faqat kutubxonadagi fayllar uchun ishlaydi.");
      return;
    }
    if (_rows.isEmpty) return;

    final index = _top.value;
    if (index < 0 || index >= _rows.length) return;

    if (_data.hasBookmark(_key, index)) {
      await _data.removeBookmark(_key, index);
      _snack("Xatcho'p olib tashlandi");
    } else {
      await _data.addBookmark(_key, index, _rows[index].text);
      _snack("Xatcho'p qo'shildi");
    }
    if (mounted) setState(() {});
  }

  void _showBookmarks() {
    if (!_persist) {
      _snack("Xatcho'plar faqat kutubxonadagi fayllar uchun ishlaydi.");
      return;
    }

    showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheet) {
            final list = _data.bookmarks(_key);
            if (list.isEmpty) {
              return const SizedBox(
                height: 160,
                child: Center(child: Text("Xatcho'plar yo'q")),
              );
            }
            return ListView(
              shrinkWrap: true,
              children: [
                for (final b in list)
                  ListTile(
                    leading: const Icon(Icons.bookmark),
                    title: Text(
                      b.label.isEmpty ? '${b.index + 1}-qator' : b.label,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    subtitle: Text('${b.index + 1}-qator'),
                    onTap: () {
                      Navigator.pop(sheetContext);
                      _jumpTo(b.index);
                    },
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        await _data.removeBookmark(_key, b.index);
                        setSheet(() {});
                        if (mounted) setState(() {});
                      },
                    ),
                  ),
              ],
            );
          },
        );
      },
    );
  }

  // ---------- Matn kodlashi ----------

  Future<void> _chooseEncoding() async {
    const labels = <String, String>{
      '': 'Avtomatik',
      'utf8': 'UTF-8',
      'cp1251': 'Windows-1251 (kirill)',
      'latin1': 'Latin-1',
      'utf16le': 'UTF-16 LE',
      'utf16be': 'UTF-16 BE',
    };

    final choice = await showDialog<String>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: const Text('Matn kodlashi'),
        children: [
          for (final entry in labels.entries)
            SimpleDialogOption(
              onPressed: () => Navigator.pop(ctx, entry.key),
              child: Row(
                children: [
                  Icon(
                    (_encoding ?? '') == entry.key
                        ? Icons.radio_button_checked
                        : Icons.radio_button_unchecked,
                    size: 20,
                  ),
                  const SizedBox(width: 12),
                  Text(entry.value),
                ],
              ),
            ),
        ],
      ),
    );
    if (choice == null || !mounted) return;

    final value = choice.isEmpty ? null : choice;
    if (value == _encoding) return;

    await _stopSpeech();
    if (_persist) await _data.setEncoding(_key, value);
    if (!mounted) return;
    if (_searching) _closeSearch();

    setState(() {
      _encoding = value;
      _startIndex = _top.value;
      _loading = true;
      _error = null;
    });
    await _load();
  }

  // ---------- Mundarija ----------

  void _showContents() {
    if (_headers.isEmpty) {
      _snack("Bu hujjatda mundarija yo'q");
      return;
    }

    showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) => ListView(
        shrinkWrap: true,
        children: [
          for (final i in _headers)
            ListTile(
              leading: const Icon(Icons.list),
              title: Text(
                _rows[i].text,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              onTap: () {
                Navigator.pop(sheetContext);
                _jumpTo(i);
              },
            ),
        ],
      ),
    );
  }

  // ---------- Ovoz chiqarib o'qish ----------

  Iterable<String> _chunks(String text) sync* {
    const limit = 3000;
    var rest = text;
    while (rest.length > limit) {
      var cut = rest.lastIndexOf(RegExp(r'[.!?;]\s'), limit);
      cut = cut <= 0 ? limit : cut + 1;
      yield rest.substring(0, cut);
      rest = rest.substring(cut).trimLeft();
    }
    if (rest.isNotEmpty) yield rest;
  }

  Future<void> _stopSpeech() async {
    _speaking = false;
    try {
      await _tts?.stop();
    } catch (_) {}
    if (mounted) setState(() {});
  }

  Future<void> _toggleSpeech() async {
    if (_speaking) {
      await _stopSpeech();
      return;
    }
    if (_rows.isEmpty) return;

    final tts = _tts ??= FlutterTts();
    try {
      await tts.awaitSpeakCompletion(true);
      await tts.setSpeechRate(_settings.ttsRate);
    } catch (e) {
      _snack("Ovoz chiqarish ishlamadi. Telefonda ovoz dvigateli (masalan, Google TTS) o'rnatilganini tekshiring.");
      return;
    }

    setState(() => _speaking = true);
    var index = _top.value;
    try {
      while (_speaking && mounted && index < _rows.length) {
        final text = _rows[index].text.trim();
        if (text.isNotEmpty) {
          _scrollTo(index);
          for (final chunk in _chunks(text)) {
            if (!_speaking || !mounted) break;
            await tts.speak(chunk);
          }
        }
        index++;
      }
    } catch (e) {
      _snack("Ovoz chiqarishda xatolik. Ovoz dvigateli o'rnatilganini tekshiring.");
    } finally {
      _speaking = false;
      if (mounted) setState(() {});
    }
  }

  // ---------- Ikki barmoq bilan kattalashtirish ----------

  double _pinchDistance() {
    final points = _pointers.values.toList();
    if (points.length < 2) return 0;
    return (points[0] - points[1]).distance;
  }

  void _endPointer(PointerEvent event) {
    final hadTwo = _pointers.length >= 2;
    _pointers.remove(event.pointer);

    if (hadTwo && _pointers.length < 2) {
      _pinchStart = null;
      final size = _liveSize;
      if (size != null) {
        _liveSize = null;
        _settings.update(() => _settings.fontSize = size);
      }
    }
  }

  Widget _withPinch(Widget child) {
    return Listener(
      onPointerDown: (event) {
        _pointers[event.pointer] = event.position;
        if (_pointers.length == 2) {
          _pinchStart = _pinchDistance();
          _pinchBase = _settings.fontSize;
        }
      },
      onPointerMove: (event) {
        if (!_pointers.containsKey(event.pointer)) return;
        _pointers[event.pointer] = event.position;

        final start = _pinchStart;
        if (_pointers.length == 2 && start != null && start > 0) {
          final next = (_pinchBase * _pinchDistance() / start)
              .clamp(12.0, 40.0)
              .roundToDouble();
          if (next != (_liveSize ?? _settings.fontSize)) {
            setState(() => _liveSize = next);
          }
        }
      },
      onPointerUp: _endPointer,
      onPointerCancel: _endPointer,
      child: child,
    );
  }

  // ---------- To'liq ekran ----------

  Future<void> _toggleFullscreen() async {
    final next = !_full;
    try {
      await SystemChrome.setEnabledSystemUIMode(
        next ? SystemUiMode.immersiveSticky : SystemUiMode.edgeToEdge,
      );
    } catch (_) {}
    if (mounted) setState(() => _full = next);
  }

  // ---------- Boshqa amallar ----------

  void _showReaderSettings() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (_) => const Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 24),
        child: SingleChildScrollView(child: ReaderControls()),
      ),
    );
  }

  Future<void> _share() async {
    try {
      await Share.shareXFiles([XFile(widget.path)]);
    } catch (e) {
      _snack("Ulashib bo'lmadi: $e");
    }
  }

  Future<void> _onMenu(String value) async {
    switch (value) {
      case 'bookmarks':
        _showBookmarks();
        break;
      case 'contents':
        _showContents();
        break;
      case 'encoding':
        await _chooseEncoding();
        break;
      case 'fullscreen':
        await _toggleFullscreen();
        break;
      case 'share':
        await _share();
        break;
      case 'external':
        await OpenFilex.open(widget.path);
        break;
    }
  }

  // ---------- Ko'rinish ----------

  TextSpan _spans(String text, int index, TextStyle style) {
    final regex = _regex;
    if (regex == null) return TextSpan(text: text, style: style);

    final isCurrent = _matchPos >= 0 &&
        _matchPos < _matches.length &&
        _matches[_matchPos] == index;
    final background =
        isCurrent ? const Color(0xFFFFB74D) : const Color(0x99FFEB3B);

    final children = <InlineSpan>[];
    var last = 0;
    for (final m in regex.allMatches(text)) {
      if (m.end == m.start) continue;
      if (m.start > last) {
        children.add(TextSpan(text: text.substring(last, m.start)));
      }
      children.add(
        TextSpan(
          text: text.substring(m.start, m.end),
          style: TextStyle(backgroundColor: background, color: Colors.black),
        ),
      );
      last = m.end;
    }

    if (children.isEmpty) return TextSpan(text: text, style: style);
    if (last < text.length) children.add(TextSpan(text: text.substring(last)));
    return TextSpan(style: style, children: children);
  }

  String _mediaName(String path) =>
      p.basename(path).replaceFirst(RegExp(r'^\d+_'), '');

  void _viewImage(String path) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.black,
            foregroundColor: Colors.white,
            title: Text(_mediaName(path)),
          ),
          body: Center(
            child: InteractiveViewer(
              maxScale: 8,
              child: Image.file(
                File(path),
                errorBuilder: (_, __, ___) => const Icon(
                  Icons.broken_image_outlined,
                  color: Colors.white54,
                  size: 64,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _mediaTile(String tag, String path) {
    final scheme = Theme.of(context).colorScheme;
    final video = tag == 'VID';
    final broken = tag == 'IMG';

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Material(
        color: scheme.surfaceContainerHigh,
        borderRadius: BorderRadius.circular(16),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () async {
            final result = await OpenFilex.open(path);
            if (result.type != ResultType.done) {
              _snack("Faylni ochib bo'lmadi. Mos ilova o'rnatilmagan bo'lishi mumkin.");
            }
          },
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Icon(
                  broken
                      ? Icons.broken_image_outlined
                      : video
                          ? Icons.movie_outlined
                          : Icons.audiotrack_outlined,
                  size: 32,
                  color: scheme.primary,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _mediaName(path),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w600),
                      ),
                      Text(
                        video ? 'Video' : (broken ? 'Rasm' : 'Audio'),
                        style: TextStyle(
                          fontSize: 12.5,
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(Icons.play_circle_outline, color: scheme.primary),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _mediaLine(_Row row) {
    final path = row.path!;
    if (row.media != 'IMG') return _mediaTile(row.media!, path);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: GestureDetector(
        onTap: () => _viewImage(path),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.file(
            File(path),
            fit: BoxFit.contain,
            cacheWidth: 1400,
            errorBuilder: (_, __, ___) => _mediaTile('IMG', path),
          ),
        ),
      ),
    );
  }

  Widget _line(int index, TextStyle base) {
    final row = _rows[index];

    if (row.media != null && row.path != null) return _mediaLine(row);

    if (row.header) {
      final headerStyle = base.copyWith(
        fontWeight: FontWeight.bold,
        fontSize: (base.fontSize ?? 16) * 1.15,
      );
      return Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 8),
        child: SelectableText.rich(_spans(t(row.text), index, headerStyle)),
      );
    }

    if (row.text.isEmpty) {
      return SizedBox(height: (base.fontSize ?? 16) * 0.6);
    }

    return SelectableText.rich(_spans(row.text, index, base));
  }

  PreferredSizeWidget _buildAppBar() {
    if (_searching) {
      return AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: _closeSearch,
        ),
        title: TextField(
          controller: _searchController,
          focusNode: _searchFocus,
          onChanged: _onQuery,
          textInputAction: TextInputAction.search,
          decoration: InputDecoration(
            hintText: t('Qidirish...'),
            border: InputBorder.none,
          ),
        ),
        actions: [
          if (_query.isNotEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text(
                  _matches.isEmpty ? '0' : '${_matchPos + 1}/${_matches.length}',
                ),
              ),
            ),
          IconButton(
            tooltip: t('Oldingi'),
            icon: const Icon(Icons.keyboard_arrow_up),
            onPressed: _matches.isEmpty ? null : () => _step(-1),
          ),
          IconButton(
            tooltip: t('Keyingi'),
            icon: const Icon(Icons.keyboard_arrow_down),
            onPressed: _matches.isEmpty ? null : () => _step(1),
          ),
        ],
      );
    }

    return AppBar(
      title: Text(
        Library.displayName(widget.path),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      actions: [
        IconButton(
          tooltip: t('Qidirish'),
          icon: const Icon(Icons.search),
          onPressed: _rows.isEmpty ? null : _startSearch,
        ),
        IconButton(
          tooltip: t(_speaking ? "O'qishni to'xtatish" : "Ovoz chiqarib o'qish"),
          icon: Icon(
            _speaking
                ? Icons.stop_circle_outlined
                : Icons.record_voice_over_outlined,
          ),
          onPressed: _rows.isEmpty ? null : _toggleSpeech,
        ),
        ValueListenableBuilder<int>(
          valueListenable: _top,
          builder: (context, top, _) {
            final marked = _persist && _data.hasBookmark(_key, top);
            return IconButton(
              tooltip: t("Xatcho'p"),
              icon: Icon(marked ? Icons.bookmark : Icons.bookmark_border),
              onPressed: _rows.isEmpty ? null : _toggleBookmark,
            );
          },
        ),
        IconButton(
          tooltip: t("O'qish sozlamalari"),
          icon: const Icon(Icons.text_fields),
          onPressed: _showReaderSettings,
        ),
        PopupMenuButton<String>(
          onSelected: _onMenu,
          itemBuilder: (_) => <PopupMenuEntry<String>>[
            const PopupMenuItem<String>(
              value: 'bookmarks',
              child: Text("Xatcho'plar"),
            ),
            const PopupMenuItem<String>(
              value: 'contents',
              child: Text('Mundarija'),
            ),
            if (_isPlainText)
              const PopupMenuItem<String>(
                value: 'encoding',
                child: Text('Matn kodlashi'),
              ),
            PopupMenuItem<String>(
              value: 'fullscreen',
              child: Text(_full ? 'Oddiy ekran' : "To'liq ekran"),
            ),
            const PopupMenuItem<String>(
              value: 'share',
              child: Text('Ulashish'),
            ),
            const PopupMenuItem<String>(
              value: 'external',
              child: Text('Tashqi ilovada ochish'),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "Faylni ochib bo'lmadi. Fayl buzilgan yoki noto'g'ri formatda bo'lishi mumkin.\n\n$_error",
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () => OpenFilex.open(widget.path),
                icon: const Icon(Icons.open_in_new),
                label: const Text('Tashqi ilovada ochish'),
              ),
            ],
          ),
        ),
      );
    }

    if (_rows.isEmpty) {
      return const Center(child: Text("Fayl bo'sh"));
    }

    final base = TextStyle(
      fontSize: _liveSize ?? _settings.fontSize,
      height: _settings.lineHeight,
      fontFamily: _kind == DocKind.xlsx ? 'monospace' : _settings.fontFamily,
      color: _settings.foreground ?? Theme.of(context).colorScheme.onSurface,
    );

    return Column(
      children: [
        ValueListenableBuilder<double>(
          valueListenable: _progress,
          builder: (context, value, _) =>
              LinearProgressIndicator(value: value, minHeight: 2),
        ),
        Expanded(
          child: _withPinch(
            ScrollablePositionedList.builder(
              itemCount: _rows.length,
              initialScrollIndex: _startIndex,
              itemScrollController: _itemScroll,
              itemPositionsListener: _positions,
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
              itemBuilder: (context, index) => _line(index, base),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _settings,
      builder: (context, _) {
        final gradient =
            _settings.readerGradient && _settings.background == null;
        final scaffold = Scaffold(
          backgroundColor: gradient ? Colors.transparent : _settings.background,
          appBar: _full ? null : _buildAppBar(),
          body: _full
              ? Stack(
                  children: [
                    _buildBody(),
                    Positioned(
                      top: 8,
                      right: 8,
                      child: SafeArea(
                        child: IconButton.filledTonal(
                          tooltip: t('Oddiy ekran'),
                          icon: const Icon(Icons.fullscreen_exit),
                          onPressed: _toggleFullscreen,
                        ),
                      ),
                    ),
                  ],
                )
              : _buildBody(),
        );
        return gradient ? GradientBackground(child: scaffold) : scaffold;
      },
    );
  }
}
