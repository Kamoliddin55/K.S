import 'dart:async';

import 'package:flutter/material.dart' hide Text;
import 'package:flutter/services.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import 'package:share_plus/share_plus.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import 'dialogs.dart';
import 'l10n.dart';
import 'library.dart';
import 'settings.dart';
import 'theme.dart';
import 'user_data.dart';

class PdfScreen extends StatefulWidget {
  final String path;
  const PdfScreen({super.key, required this.path});

  @override
  State<PdfScreen> createState() => _PdfScreenState();
}

class _PdfScreenState extends State<PdfScreen> {
  final _settings = AppSettings.instance;
  final _data = UserData.instance;

  PDFViewController? _controller;
  late final String _key;
  late final bool _persist;

  int _page = 0;
  int? _pages;
  String? _password;
  String? _error;
  bool _needPassword = false;
  bool _wrongPassword = false;
  bool _asking = false;
  int _generation = 0;
  bool _full = false;
  bool _scrubber = true;
  bool _continuous = false;
  double? _drag;
  Timer? _saveTimer;

  @override
  void initState() {
    super.initState();
    _key = p.basename(widget.path);
    _persist = Library.isInLibrary(widget.path);
    _page = _persist ? (_data.position(_key) ?? 0) : 0;
    _settings.addListener(_applyWakelock);
    _applyWakelock();
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    _savePosition();
    _settings.removeListener(_applyWakelock);
    _releaseWakelock();
    if (_full) {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    }
    super.dispose();
  }

  Future<void> _applyWakelock() async {
    try {
      if (_settings.keepScreenOn) {
        await WakelockPlus.enable();
      } else {
        await WakelockPlus.disable();
      }
    } catch (_) {}
  }

  Future<void> _releaseWakelock() async {
    try {
      await WakelockPlus.disable();
    } catch (_) {}
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  // ---------- O'qish joyi ----------

  void _scheduleSave() {
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 600), _savePosition);
  }

  void _savePosition() {
    final total = _pages;
    if (_persist && total != null && total > 0) {
      _data.setPosition(_key, _page);
      _data.setProgress(_key, (_page + 1) / total);
    }
  }

  // ---------- PDF hodisalari ----------

  void _onError(dynamic error) {
    if (!mounted) return;
    final text = error.toString();
    final lower = text.toLowerCase();
    const hints = ['password', 'encrypt', 'decrypt', 'protected', 'authenticat'];

    if (hints.any(lower.contains)) {
      setState(() {
        _wrongPassword = _password != null;
        _password = null;
        _needPassword = true;
        _error = null;
      });
      _askPassword();
    } else {
      setState(() => _error = text);
    }
  }

  Future<void> _askPassword() async {
    if (_asking || !mounted) return;
    _asking = true;
    try {
      final value = await promptText(
        context,
        title: _wrongPassword ? "Parol noto'g'ri, qayta kiriting" : 'PDF paroli',
        label: 'Parol',
        obscure: true,
        confirm: 'Ochish',
      );
      if (!mounted) return;

      if (value == null || value.isEmpty) {
        setState(() => _error = 'Parol kiritilmadi');
      } else {
        setState(() {
          _password = value;
          _needPassword = false;
          _wrongPassword = false;
          _error = null;
          _generation++;
        });
      }
    } finally {
      _asking = false;
    }
  }

  // ---------- Amallar ----------

  Future<void> _goToPage() async {
    final total = _pages;
    final value = await promptText(
      context,
      title: "Sahifaga o'tish",
      label: total == null ? 'Sahifa raqami' : 'Sahifa raqami (1-$total)',
      keyboardType: TextInputType.number,
      confirm: "O'tish",
    );
    if (value == null || !mounted) return;

    final n = int.tryParse(value);
    if (n == null || n < 1 || (total != null && n > total)) {
      _snack("Noto'g'ri sahifa raqami");
      return;
    }
    await _controller?.setPage(n - 1);
  }

  Future<void> _toggleBookmark() async {
    if (!_persist) {
      _snack("Xatcho'p faqat kutubxonadagi fayllar uchun ishlaydi.");
      return;
    }
    if (_data.hasBookmark(_key, _page)) {
      await _data.removeBookmark(_key, _page);
      _snack("Xatcho'p olib tashlandi");
    } else {
      await _data.addBookmark(_key, _page, 'Sahifa ${_page + 1}');
      _snack("Xatcho'p qo'shildi");
    }
    if (mounted) setState(() {});
  }

  void _showBookmarks() {
    if (!_persist) {
      _snack("Xatcho'plar faqat kutubxonadagi fayllar uchun ishlaydi.");
      return;
    }

    showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheet) {
            final list = _data.bookmarks(_key);
            if (list.isEmpty) {
              return const SizedBox(
                height: 160,
                child: Center(child: Text("Xatcho'plar yo'q")),
              );
            }
            return ListView(
              shrinkWrap: true,
              children: [
                for (final b in list)
                  ListTile(
                    leading: const Icon(Icons.bookmark),
                    title: Text('Sahifa ${b.index + 1}'),
                    onTap: () {
                      Navigator.pop(sheetContext);
                      _controller?.setPage(b.index);
                    },
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        await _data.removeBookmark(_key, b.index);
                        setSheet(() {});
                        if (mounted) setState(() {});
                      },
                    ),
                  ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _share() async {
    try {
      await Share.shareXFiles([XFile(widget.path)]);
    } catch (e) {
      _snack("Ulashib bo'lmadi: $e");
    }
  }

  Future<void> _onMenu(String value) async {
    switch (value) {
      case 'bookmarks':
        _showBookmarks();
        break;
      case 'night':
        _settings.update(() => _settings.pdfNightMode = !_settings.pdfNightMode);
        break;
      case 'horizontal':
        _settings.update(() => _settings.pdfHorizontal = !_settings.pdfHorizontal);
        break;
      case 'scrubber':
        setState(() => _scrubber = !_scrubber);
        break;
      case 'continuous':
        setState(() => _continuous = !_continuous);
        break;
      case 'fullscreen':
        await _toggleFullscreen();
        break;
      case 'share':
        await _share();
        break;
      case 'external':
        await OpenFilex.open(widget.path);
        break;
    }
  }

  Future<void> _toggleFullscreen() async {
    final next = !_full;
    try {
      await SystemChrome.setEnabledSystemUIMode(
        next ? SystemUiMode.immersiveSticky : SystemUiMode.edgeToEdge,
      );
    } catch (_) {}
    if (mounted) setState(() => _full = next);
  }

  // ---------- Ko'rinish ----------

  Widget _buildBody() {
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                _needPassword
                    ? _error!
                    : "PDF'ni ochib bo'lmadi. Fayl buzilgan bo'lishi mumkin.\n\n$_error",
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              if (_needPassword)
                FilledButton.icon(
                  onPressed: () {
                    setState(() => _error = null);
                    _askPassword();
                  },
                  icon: const Icon(Icons.lock_open),
                  label: const Text('Parolni kiritish'),
                )
              else ...[
                FilledButton.icon(
                  onPressed: () {
                    setState(() => _error = null);
                    _askPassword();
                  },
                  icon: const Icon(Icons.lock_open),
                  label: const Text('Parolni kiritish'),
                ),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: () => OpenFilex.open(widget.path),
                  icon: const Icon(Icons.open_in_new),
                  label: const Text('Tashqi ilovada ochish'),
                ),
              ],
            ],
          ),
        ),
      );
    }

    if (_needPassword && _password == null) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.lock_outline, size: 64),
            SizedBox(height: 12),
            Text('Bu PDF parol bilan himoyalangan'),
          ],
        ),
      );
    }

    return Stack(
      children: [
        PDFView(
          key: ValueKey(
            '${_settings.pdfNightMode}-${_settings.pdfHorizontal}-${_continuous}-${_password ?? ''}-$_generation',
          ),
          filePath: widget.path,
          defaultPage: _page,
          enableSwipe: true,
          swipeHorizontal: _settings.pdfHorizontal,
          nightMode: _settings.pdfNightMode,
          autoSpacing: !_continuous,
          pageFling: !_continuous,
          pageSnap: !_continuous,
          password: _password,
          onViewCreated: (controller) => _controller = controller,
          onRender: (pages) {
            if (mounted) setState(() => _pages = pages);
          },
          onPageChanged: (page, total) {
            if (!mounted) return;
            setState(() {
              _page = page ?? _page;
              _pages = total ?? _pages;
            });
            _scheduleSave();
          },
          onError: _onError,
          onPageError: (page, error) {
            if (mounted) setState(() => _error = 'Sahifa $page: $error');
          },
        ),
        if (_pages != null && _scrubber && (_pages ?? 0) > 1)
          Positioned(
            left: 12,
            right: 12,
            bottom: 12,
            child: Material(
              color: Colors.black54,
              borderRadius: BorderRadius.circular(24),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Row(
                  children: [
                    IconButton(
                      color: Colors.white,
                      tooltip: t('Birinchi sahifa'),
                      icon: const Icon(Icons.first_page),
                      onPressed: () => _controller?.setPage(0),
                    ),
                    Expanded(
                      child: Slider(
                        min: 1,
                        max: (_pages ?? 1).toDouble(),
                        divisions: (_pages ?? 1) > 1 ? (_pages ?? 1) - 1 : null,
                        value: (_drag ?? (_page + 1).toDouble())
                            .clamp(1.0, (_pages ?? 1).toDouble())
                            .toDouble(),
                        onChanged: (v) => setState(() => _drag = v),
                        onChangeEnd: (v) {
                          _drag = null;
                          _controller?.setPage(v.round() - 1);
                          setState(() {});
                        },
                      ),
                    ),
                    InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: _goToPage,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
                        child: Text(
                          '${(_drag ?? (_page + 1).toDouble()).round()} / $_pages',
                          style: const TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                    IconButton(
                      color: Colors.white,
                      tooltip: t('Oxirgi sahifa'),
                      icon: const Icon(Icons.last_page),
                      onPressed: () => _controller?.setPage((_pages ?? 1) - 1),
                    ),
                  ],
                ),
              ),
            ),
          )
        else if (_pages != null)
          Positioned(
            right: 16,
            bottom: 16,
            child: Material(
              color: Colors.black54,
              borderRadius: BorderRadius.circular(16),
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: _goToPage,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: Text(
                    '${_page + 1} / $_pages',
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _settings,
      builder: (context, _) {
        final scaffold = Scaffold(
          backgroundColor: Colors.transparent,
          appBar: _full ? null : AppBar(
            title: Text(
              Library.displayName(widget.path),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            actions: [
              IconButton(
                tooltip: t("Sahifaga o'tish"),
                icon: const Icon(Icons.format_list_numbered),
                onPressed: _pages == null ? null : _goToPage,
              ),
              IconButton(
                tooltip: t("Xatcho'p"),
                icon: Icon(
                  _persist && _data.hasBookmark(_key, _page)
                      ? Icons.bookmark
                      : Icons.bookmark_border,
                ),
                onPressed: _pages == null ? null : _toggleBookmark,
              ),
              PopupMenuButton<String>(
                onSelected: _onMenu,
                itemBuilder: (_) => <PopupMenuEntry<String>>[
                  const PopupMenuItem<String>(
                    value: 'bookmarks',
                    child: Text("Xatcho'plar"),
                  ),
                  CheckedPopupMenuItem<String>(
                    value: 'night',
                    checked: _settings.pdfNightMode,
                    child: const Text('Tungi rejim'),
                  ),
                  CheckedPopupMenuItem<String>(
                    value: 'horizontal',
                    checked: _settings.pdfHorizontal,
                    child: const Text('Gorizontal varaqlash'),
                  ),
                  CheckedPopupMenuItem<String>(
                    value: 'scrubber',
                    checked: _scrubber,
                    child: const Text('Sahifa chizg\'ichi'),
                  ),
                  CheckedPopupMenuItem<String>(
                    value: 'continuous',
                    checked: _continuous,
                    child: const Text('Uzluksiz varaqlash'),
                  ),
                  PopupMenuItem<String>(
                    value: 'fullscreen',
                    child: Text(_full ? 'Oddiy ekran' : "To'liq ekran"),
                  ),
                  const PopupMenuItem<String>(
                    value: 'share',
                    child: Text('Ulashish'),
                  ),
                  const PopupMenuItem<String>(
                    value: 'external',
                    child: Text('Tashqi ilovada ochish'),
                  ),
                ],
              ),
            ],
          ),
          body: _full
              ? Stack(
                  children: [
                    _buildBody(),
                    Positioned(
                      top: 8,
                      right: 8,
                      child: SafeArea(
                        child: IconButton.filledTonal(
                          tooltip: t('Oddiy ekran'),
                          icon: const Icon(Icons.fullscreen_exit),
                          onPressed: _toggleFullscreen,
                        ),
                      ),
                    ),
                  ],
                )
              : _buildBody(),
        );
        return GradientBackground(child: scaffold);
      },
    );
  }
}
