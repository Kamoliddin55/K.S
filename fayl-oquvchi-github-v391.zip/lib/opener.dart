import 'package:flutter/material.dart' hide Text;
import 'package:open_filex/open_filex.dart';

import 'archive_screen.dart';
import 'document_parser.dart';
import 'l10n.dart';
import 'pdf_screen.dart';
import 'pptx_screen.dart';
import 'sheet_screen.dart';
import 'text_screen.dart';
import 'word_screen.dart';

/// Fayl turiga qarab mos ekranni ochadi.
Future<void> openDocument(BuildContext context, String path) async {
  final kind = kindOf(path);
  final messenger = ScaffoldMessenger.of(context);
  final navigator = Navigator.of(context);

  if (kind == DocKind.external) {
    final result = await OpenFilex.open(path);
    if (result.type == ResultType.noAppToOpen) {
      messenger.showSnackBar(
        const SnackBar(
          content: Text(
            "Bu format uchun mos ilova topilmadi. Microsoft 365 yoki boshqa ilovani o'rnating.",
          ),
        ),
      );
    } else if (result.type != ResultType.done) {
      messenger.showSnackBar(SnackBar(content: Text(result.message)));
    }
    return;
  }

  final Widget screen;
  switch (kind) {
    case DocKind.archive:
      screen = ArchiveScreen(path: path);
      break;
    case DocKind.pdf:
      screen = PdfScreen(path: path);
      break;
    case DocKind.xlsx:
      screen = SheetScreen(path: path);
      break;
    case DocKind.pptx:
      screen = PptScreen(path: path);
      break;
    case DocKind.docx:
      screen = WordScreen(path: path);
      break;
    default:
      screen = TextScreen(path: path);
      break;
  }

  await navigator.push(MaterialPageRoute<void>(builder: (_) => screen));
}
