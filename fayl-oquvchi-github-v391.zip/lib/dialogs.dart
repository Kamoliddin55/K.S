import 'package:flutter/material.dart' hide Text;

import 'l10n.dart';

/// Xato obyektini foydalanuvchiga ko'rsatish uchun qisqa matnga aylantiradi.
/// Isolate ichida tashlangan xatolar matn ko'rinishida (RemoteError) keladi,
/// shuning uchun xabar matndan ajratib olinadi.
String errorText(Object e) {
  if (e is FormatException) return e.message;
  if (e is UnsupportedError) return e.message ?? e.toString();

  var text = e.toString().trim();
  text = text.replaceFirst(RegExp(r'^Unhandled exception:\s*'), '');
  text = text.replaceFirst(
    RegExp(r'^(FormatException|UnsupportedError|Exception|StateError|FileSystemException)(\(\))?:?\s*'),
    '',
  );
  final lines = text.split('\n');
  return lines.first.trim().isEmpty ? text : lines.first.trim();
}

/// Matn kiritish oynasi. Bekor qilinsa null qaytaradi.
Future<String?> promptText(
  BuildContext context, {
  required String title,
  String? label,
  String initial = '',
  bool obscure = false,
  TextInputType? keyboardType,
  String confirm = 'OK',
}) {
  return showDialog<String>(
    context: context,
    builder: (_) => _PromptDialog(
      title: title,
      label: label,
      initial: initial,
      obscure: obscure,
      keyboardType: keyboardType,
      confirm: confirm,
    ),
  );
}

/// Tasdiqlash oynasi.
Future<bool> confirmDialog(
  BuildContext context, {
  required String title,
  String? message,
  String confirm = 'Ha',
}) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: message == null ? null : Text(message),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: const Text('Bekor qilish'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(confirm),
        ),
      ],
    ),
  );
  return result ?? false;
}

class _PromptDialog extends StatefulWidget {
  final String title;
  final String? label;
  final String initial;
  final bool obscure;
  final TextInputType? keyboardType;
  final String confirm;

  const _PromptDialog({
    required this.title,
    required this.label,
    required this.initial,
    required this.obscure,
    required this.keyboardType,
    required this.confirm,
  });

  @override
  State<_PromptDialog> createState() => _PromptDialogState();
}

class _PromptDialogState extends State<_PromptDialog> {
  late final TextEditingController _controller =
      TextEditingController(text: widget.initial);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _submit() => Navigator.pop(context, _controller.text.trim());

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.title),
      content: TextField(
        controller: _controller,
        autofocus: true,
        obscureText: widget.obscure,
        keyboardType: widget.keyboardType,
        decoration: InputDecoration(
          labelText: widget.label == null ? null : t(widget.label!),
        ),
        onSubmitted: (_) => _submit(),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Bekor qilish'),
        ),
        FilledButton(onPressed: _submit, child: Text(widget.confirm)),
      ],
    );
  }
}
