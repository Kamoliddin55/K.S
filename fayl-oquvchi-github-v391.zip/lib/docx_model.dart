import 'dart:io';
import 'dart:isolate';
import 'dart:math' as math;

import 'package:archive/archive.dart';
import 'package:xml/xml.dart';

import 'document_parser.dart';

// =====================================================================
// Model (faqat oddiy qiymatlar - isolate orqali uzatiladi)
// =====================================================================

class DSide {
  final int color;
  final double width;
  const DSide(this.color, this.width);
}

class DRun {
  final String text;
  final bool bold;
  final bool italic;
  final bool underline;
  final bool strike;
  final int? color;
  final double size;
  final String? font;
  final int? highlight;
  final int? shade;
  final int vert; // 0 oddiy, 1 yuqori indeks, -1 pastki indeks
  final bool link;
  final String? href;
  final String? image;
  final double imgW;
  final double imgH;
  final bool pageBreak;
  const DRun({
    this.text = '',
    this.bold = false,
    this.italic = false,
    this.underline = false,
    this.strike = false,
    this.color,
    this.size = 11,
    this.font,
    this.highlight,
    this.shade,
    this.vert = 0,
    this.link = false,
    this.href,
    this.image,
    this.imgW = 0,
    this.imgH = 0,
    this.pageBreak = false,
  });
}

abstract class DBlock {
  const DBlock();
}

class DPara extends DBlock {
  final List<DRun> runs;
  final String align; // left, center, right, both
  final double left;
  final double right;
  final double firstLine; // manfiy bo'lsa osilgan (hanging)
  final double before;
  final double after;
  final double lineMul; // 0 - standart
  final double lineExact; // 0 - ishlatilmaydi
  final String? marker;
  final double markerWidth;
  final int? markerColor;
  final int? shade;
  final DSide? borderTop;
  final DSide? borderBottom;
  final int heading;
  final bool pageBreakBefore;
  final double size;
  const DPara({
    required this.runs,
    this.align = 'left',
    this.left = 0,
    this.right = 0,
    this.firstLine = 0,
    this.before = 0,
    this.after = 0,
    this.lineMul = 0,
    this.lineExact = 0,
    this.marker,
    this.markerWidth = 0,
    this.markerColor,
    this.shade,
    this.borderTop,
    this.borderBottom,
    this.heading = 0,
    this.pageBreakBefore = false,
    this.size = 11,
  });

  String get plain => runs.map((r) => r.text).join();
}

class DCell {
  final List<DBlock> blocks;
  final int span;
  final bool vContinue;
  final int? shade;
  final DSide? top;
  final DSide? left;
  final DSide? bottom;
  final DSide? right;
  const DCell({
    required this.blocks,
    this.span = 1,
    this.vContinue = false,
    this.shade,
    this.top,
    this.left,
    this.bottom,
    this.right,
  });
}

class DTable extends DBlock {
  final List<List<DCell>> rows;
  final List<double> grid;
  const DTable(this.rows, this.grid);
}

class DDoc {
  final List<DBlock> blocks;
  final double pageW;
  final double pageH;
  final double marginL;
  final double marginR;
  final double marginT;
  final double marginB;
  const DDoc(
    this.blocks,
    this.pageW,
    this.pageH,
    this.marginL,
    this.marginR,
    this.marginT,
    this.marginB,
  );
}

Future<DDoc> loadDocx(String path, {String? mediaDir}) =>
    Isolate.run(() => parseDocx(path, mediaDir));

// =====================================================================
// Yordamchilar
// =====================================================================

String? _a(XmlElement e, String local) => xmlAttr(e, local);

XmlElement? _c(XmlElement? e, String name) {
  if (e == null) return null;
  for (final x in e.childElements) {
    if (x.name.local == name) return x;
  }
  return null;
}

bool? _onOff(XmlElement? e) {
  if (e == null) return null;
  final v = _a(e, 'val');
  if (v == null) return true;
  return !(v == '0' || v == 'false' || v == 'off' || v == 'none');
}

double? _twips(String? v) {
  if (v == null) return null;
  final n = double.tryParse(v);
  return n == null ? null : n / 20;
}

const _highlights = <String, int>{
  'yellow': 0xFFFFFF00,
  'green': 0xFF00FF00,
  'cyan': 0xFF00FFFF,
  'magenta': 0xFFFF00FF,
  'blue': 0xFF0000FF,
  'red': 0xFFFF0000,
  'darkBlue': 0xFF000080,
  'darkCyan': 0xFF008080,
  'darkGreen': 0xFF008000,
  'darkMagenta': 0xFF800080,
  'darkRed': 0xFF800000,
  'darkYellow': 0xFF808000,
  'darkGray': 0xFF808080,
  'lightGray': 0xFFC0C0C0,
  'black': 0xFF000000,
  'white': 0xFFFFFFFF,
};

const _themeNames = <String, String>{
  'dark1': 'dk1',
  'light1': 'lt1',
  'dark2': 'dk2',
  'light2': 'lt2',
  'text1': 'dk1',
  'background1': 'lt1',
  'text2': 'dk2',
  'background2': 'lt2',
  'accent1': 'accent1',
  'accent2': 'accent2',
  'accent3': 'accent3',
  'accent4': 'accent4',
  'accent5': 'accent5',
  'accent6': 'accent6',
  'hyperlink': 'hlink',
  'followedHyperlink': 'folHlink',
};

// =====================================================================
// Xossalar
// =====================================================================

class _RP {
  bool? b;
  bool? i;
  bool? u;
  bool? strike;
  bool? caps;
  int? color;
  double? sz;
  String? font;
  int? hi;
  int? shd;
  int? vert;

  void apply(_RP o) {
    b = o.b ?? b;
    i = o.i ?? i;
    u = o.u ?? u;
    strike = o.strike ?? strike;
    caps = o.caps ?? caps;
    color = o.color ?? color;
    sz = o.sz ?? sz;
    font = o.font ?? font;
    hi = o.hi ?? hi;
    shd = o.shd ?? shd;
    vert = o.vert ?? vert;
  }

  _RP copy() => _RP()..apply(this);
}

class _PP {
  String? align;
  double? left;
  double? right;
  double? first; // firstLine musbat, hanging manfiy
  double? before;
  double? after;
  double? line;
  String? lineRule;
  int? numId;
  int? ilvl;
  int? shd;
  bool? pageBreakBefore;
  DSide? bTop;
  DSide? bBottom;
  int? outline;

  void apply(_PP o) {
    align = o.align ?? align;
    left = o.left ?? left;
    right = o.right ?? right;
    first = o.first ?? first;
    before = o.before ?? before;
    after = o.after ?? after;
    line = o.line ?? line;
    lineRule = o.lineRule ?? lineRule;
    numId = o.numId ?? numId;
    ilvl = o.ilvl ?? ilvl;
    shd = o.shd ?? shd;
    pageBreakBefore = o.pageBreakBefore ?? pageBreakBefore;
    bTop = o.bTop ?? bTop;
    bBottom = o.bBottom ?? bBottom;
    outline = o.outline ?? outline;
  }

  _PP copy() => _PP()..apply(this);
}

class _TB {
  DSide? top;
  DSide? left;
  DSide? bottom;
  DSide? right;
  DSide? insideH;
  DSide? insideV;
  bool any = false;
}

class _Style {
  final String id;
  final String type;
  String? name;
  String? basedOn;
  bool isDefault = false;
  final _PP pp = _PP();
  final _RP rp = _RP();
  final _TB tb = _TB();
  int? firstRowShade;
  _RP? firstRowRp;
  int? band1Shade;
  _Style(this.id, this.type);
}

class _Lvl {
  String fmt = 'decimal';
  String text = '%1.';
  int start = 1;
  double? left;
  double? hanging;
  int? color;
}

class _Ctx {
  final Archive archive;
  final Map<String, String> rels;
  final Map<String, String> links = <String, String>{};
  final MediaSink media;
  final Map<String, int> theme = <String, int>{};
  final Map<String, _Style> styles = <String, _Style>{};
  final _PP defPP = _PP();
  final _RP defRP = _RP();
  String? defParaStyle;
  final Map<int, int> numToAbs = <int, int>{};
  final Map<int, List<_Lvl?>> abstracts = <int, List<_Lvl?>>{};
  final Map<int, List<int>> counters = <int, List<int>>{};
  _Ctx(this.archive, this.rels, this.media);
}

int? _readColor(XmlElement e, _Ctx ctx) {
  final theme = _a(e, 'themeColor');
  if (theme != null) {
    final key = _themeNames[theme];
    final base = key == null ? null : ctx.theme[key];
    if (base != null) {
      var r = (base >> 16) & 0xFF;
      var g = (base >> 8) & 0xFF;
      var b = base & 0xFF;
      final shade = int.tryParse(_a(e, 'themeShade') ?? '', radix: 16);
      final tint = int.tryParse(_a(e, 'themeTint') ?? '', radix: 16);
      if (shade != null) {
        r = r * shade ~/ 255;
        g = g * shade ~/ 255;
        b = b * shade ~/ 255;
      }
      if (tint != null) {
        r = (r * tint + 255 * (255 - tint)) ~/ 255;
        g = (g * tint + 255 * (255 - tint)) ~/ 255;
        b = (b * tint + 255 * (255 - tint)) ~/ 255;
      }
      return 0xFF000000 | (r.clamp(0, 255) << 16) | (g.clamp(0, 255) << 8) | b.clamp(0, 255);
    }
  }
  final v = _a(e, 'val') ?? _a(e, 'fill');
  if (v == null || v == 'auto' || v.length != 6) return null;
  final n = int.tryParse(v, radix: 16);
  return n == null ? null : 0xFF000000 | n;
}

_RP _readRP(XmlElement? rPr, _Ctx ctx) {
  final rp = _RP();
  if (rPr == null) return rp;
  rp.b = _onOff(_c(rPr, 'b'));
  rp.i = _onOff(_c(rPr, 'i'));
  rp.strike = _onOff(_c(rPr, 'strike')) ?? _onOff(_c(rPr, 'dstrike'));
  rp.caps = _onOff(_c(rPr, 'caps'));
  final u = _c(rPr, 'u');
  if (u != null) rp.u = _a(u, 'val') != 'none';
  final color = _c(rPr, 'color');
  if (color != null) rp.color = _readColor(color, ctx);
  final sz = _c(rPr, 'sz');
  if (sz != null) {
    final v = double.tryParse(_a(sz, 'val') ?? '');
    if (v != null) rp.sz = v / 2;
  }
  final fonts = _c(rPr, 'rFonts');
  if (fonts != null) rp.font = _a(fonts, 'ascii') ?? _a(fonts, 'hAnsi');
  final hi = _c(rPr, 'highlight');
  if (hi != null) rp.hi = _highlights[_a(hi, 'val') ?? ''];
  final shd = _c(rPr, 'shd');
  if (shd != null) {
    final fill = _a(shd, 'fill');
    if (fill != null && fill != 'auto' && fill.length == 6) {
      final n = int.tryParse(fill, radix: 16);
      if (n != null) rp.shd = 0xFF000000 | n;
    }
  }
  final va = _c(rPr, 'vertAlign');
  if (va != null) {
    final v = _a(va, 'val');
    rp.vert = v == 'superscript' ? 1 : (v == 'subscript' ? -1 : 0);
  }
  return rp;
}

DSide? _readSide(XmlElement? e, _Ctx ctx) {
  if (e == null) return null;
  final v = _a(e, 'val');
  if (v == null || v == 'nil' || v == 'none') return null;
  final sz = double.tryParse(_a(e, 'sz') ?? '') ?? 4;
  final color = _readColor(e, ctx) ?? 0xFF000000;
  return DSide(color, math.max(0.5, math.min(sz / 8 * 1.333, 3.0)));
}

_PP _readPP(XmlElement? pPr, _Ctx ctx) {
  final pp = _PP();
  if (pPr == null) return pp;
  final jc = _c(pPr, 'jc');
  if (jc != null) {
    final v = _a(jc, 'val');
    pp.align = switch (v) {
      'center' => 'center',
      'right' || 'end' => 'right',
      'both' || 'distribute' => 'both',
      _ => 'left',
    };
  }
  final ind = _c(pPr, 'ind');
  if (ind != null) {
    pp.left = _twips(_a(ind, 'left') ?? _a(ind, 'start'));
    pp.right = _twips(_a(ind, 'right') ?? _a(ind, 'end'));
    final hanging = _twips(_a(ind, 'hanging'));
    final first = _twips(_a(ind, 'firstLine'));
    if (hanging != null) {
      pp.first = -hanging;
    } else if (first != null) {
      pp.first = first;
    }
  }
  final sp = _c(pPr, 'spacing');
  if (sp != null) {
    pp.before = _twips(_a(sp, 'before'));
    pp.after = _twips(_a(sp, 'after'));
    pp.line = double.tryParse(_a(sp, 'line') ?? '');
    pp.lineRule = _a(sp, 'lineRule');
  }
  final num = _c(pPr, 'numPr');
  if (num != null) {
    pp.numId = int.tryParse(_a(_c(num, 'numId') ?? num, 'val') ?? '');
    final il = _c(num, 'ilvl');
    if (il != null) pp.ilvl = int.tryParse(_a(il, 'val') ?? '');
  }
  final shd = _c(pPr, 'shd');
  if (shd != null) {
    final fill = _a(shd, 'fill');
    if (fill != null && fill != 'auto' && fill.length == 6) {
      final n = int.tryParse(fill, radix: 16);
      if (n != null) pp.shd = 0xFF000000 | n;
    }
  }
  if (_c(pPr, 'pageBreakBefore') != null) {
    pp.pageBreakBefore = _onOff(_c(pPr, 'pageBreakBefore'));
  }
  final bdr = _c(pPr, 'pBdr');
  if (bdr != null) {
    pp.bTop = _readSide(_c(bdr, 'top'), ctx);
    pp.bBottom = _readSide(_c(bdr, 'bottom'), ctx);
  }
  final ol = _c(pPr, 'outlineLvl');
  if (ol != null) pp.outline = int.tryParse(_a(ol, 'val') ?? '');
  return pp;
}

_TB _readTB(XmlElement? borders, _Ctx ctx) {
  final tb = _TB();
  if (borders == null) return tb;
  tb.any = true;
  tb.top = _readSide(_c(borders, 'top'), ctx);
  tb.left = _readSide(_c(borders, 'left') ?? _c(borders, 'start'), ctx);
  tb.bottom = _readSide(_c(borders, 'bottom'), ctx);
  tb.right = _readSide(_c(borders, 'right') ?? _c(borders, 'end'), ctx);
  tb.insideH = _readSide(_c(borders, 'insideH'), ctx);
  tb.insideV = _readSide(_c(borders, 'insideV'), ctx);
  return tb;
}

int? _shdFill(XmlElement? tcPrOrPPr) {
  final shd = _c(tcPrOrPPr, 'shd');
  if (shd == null) return null;
  final fill = _a(shd, 'fill');
  if (fill == null || fill == 'auto' || fill.length != 6) return null;
  final n = int.tryParse(fill, radix: 16);
  return n == null ? null : 0xFF000000 | n;
}

// =====================================================================
// Uslublar, mavzu, raqamlash
// =====================================================================

void _readTheme(_Ctx ctx) {
  final xml = zipText(ctx.archive, 'word/theme/theme1.xml');
  if (xml == null) return;
  try {
    final scheme = parseOfficeXml(xml).findAllElements('clrScheme');
    if (scheme.isEmpty) return;
    for (final el in scheme.first.childElements) {
      for (final ch in el.childElements) {
        final v = _a(ch, 'val') ?? _a(ch, 'lastClr');
        final last = _a(ch, 'lastClr');
        final src = (v != null && v.length == 6) ? v : last;
        final n = src == null ? null : int.tryParse(src, radix: 16);
        if (n != null) ctx.theme[el.name.local] = 0xFF000000 | n;
      }
    }
  } catch (_) {}
}

void _readStyles(_Ctx ctx) {
  final xml = zipText(ctx.archive, 'word/styles.xml');
  if (xml == null) {
    ctx.defRP.sz = 10;
    return;
  }
  try {
    final doc = parseOfficeXml(xml);
    final defaults = doc.findAllElements('docDefaults');
    if (defaults.isNotEmpty) {
      final rpr = _c(_c(defaults.first, 'rPrDefault'), 'rPr');
      final ppr = _c(_c(defaults.first, 'pPrDefault'), 'pPr');
      ctx.defRP.apply(_readRP(rpr, ctx));
      ctx.defPP.apply(_readPP(ppr, ctx));
    }
    ctx.defRP.sz ??= 10;

    for (final s in doc.findAllElements('style')) {
      final id = _a(s, 'styleId');
      if (id == null) continue;
      final st = _Style(id, _a(s, 'type') ?? 'paragraph');
      st.name = _a(_c(s, 'name') ?? s, 'val');
      st.basedOn = _a(_c(s, 'basedOn') ?? s, 'val');
      if (_c(s, 'basedOn') == null) st.basedOn = null;
      st.isDefault = _a(s, 'default') == '1' || _a(s, 'default') == 'true';
      st.pp.apply(_readPP(_c(s, 'pPr'), ctx));
      st.rp.apply(_readRP(_c(s, 'rPr'), ctx));
      final tblPr = _c(s, 'tblPr');
      if (tblPr != null) {
        final tb = _readTB(_c(tblPr, 'tblBorders'), ctx);
        st.tb
          ..any = tb.any
          ..top = tb.top
          ..left = tb.left
          ..bottom = tb.bottom
          ..right = tb.right
          ..insideH = tb.insideH
          ..insideV = tb.insideV;
      }
      for (final cond in s.findElements('tblStylePr')) {
        final type = _a(cond, 'type');
        final shade = _shdFill(_c(cond, 'tcPr'));
        if (type == 'firstRow') {
          st.firstRowShade = shade;
          st.firstRowRp = _readRP(_c(cond, 'rPr'), ctx);
        } else if (type == 'band1Horz') {
          st.band1Shade = shade;
        }
      }
      ctx.styles[id] = st;
      if (st.isDefault && st.type == 'paragraph') ctx.defParaStyle = id;
    }
  } catch (_) {
    ctx.defRP.sz ??= 10;
  }
}

void _readNumbering(_Ctx ctx) {
  final xml = zipText(ctx.archive, 'word/numbering.xml');
  if (xml == null) return;
  try {
    final doc = parseOfficeXml(xml);
    for (final a in doc.findAllElements('abstractNum')) {
      final id = int.tryParse(_a(a, 'abstractNumId') ?? '');
      if (id == null) continue;
      final levels = List<_Lvl?>.filled(9, null);
      for (final l in a.findElements('lvl')) {
        final il = int.tryParse(_a(l, 'ilvl') ?? '');
        if (il == null || il < 0 || il > 8) continue;
        final lvl = _Lvl();
        lvl.fmt = _a(_c(l, 'numFmt') ?? l, 'val') ?? 'decimal';
        if (_c(l, 'numFmt') == null) lvl.fmt = 'decimal';
        final lt = _c(l, 'lvlText');
        if (lt != null) lvl.text = _a(lt, 'val') ?? '';
        final st = _c(l, 'start');
        if (st != null) lvl.start = int.tryParse(_a(st, 'val') ?? '') ?? 1;
        final pp = _readPP(_c(l, 'pPr'), ctx);
        lvl.left = pp.left;
        lvl.hanging = pp.first == null ? null : -pp.first!;
        final rp = _readRP(_c(l, 'rPr'), ctx);
        lvl.color = rp.color;
        levels[il] = lvl;
      }
      ctx.abstracts[id] = levels;
    }
    for (final n in doc.findAllElements('num')) {
      final id = int.tryParse(_a(n, 'numId') ?? '');
      final abs = _c(n, 'abstractNumId');
      final aid = abs == null ? null : int.tryParse(_a(abs, 'val') ?? '');
      if (id != null && aid != null) ctx.numToAbs[id] = aid;
    }
  } catch (_) {}
}

_PP _stylePP(_Ctx ctx, String? id, [int depth = 0]) {
  final out = _PP();
  if (id == null || depth > 12) return out;
  final st = ctx.styles[id];
  if (st == null) return out;
  out.apply(_stylePP(ctx, st.basedOn, depth + 1));
  out.apply(st.pp);
  return out;
}

_RP _styleRP(_Ctx ctx, String? id, [int depth = 0]) {
  final out = _RP();
  if (id == null || depth > 12) return out;
  final st = ctx.styles[id];
  if (st == null) return out;
  out.apply(_styleRP(ctx, st.basedOn, depth + 1));
  out.apply(st.rp);
  return out;
}

_TB _styleTB(_Ctx ctx, String? id, [int depth = 0]) {
  if (id == null || depth > 12) return _TB();
  final st = ctx.styles[id];
  if (st == null) return _TB();
  final base = _styleTB(ctx, st.basedOn, depth + 1);
  if (st.tb.any) return st.tb;
  return base;
}

// =====================================================================
// Raqamlash
// =====================================================================

String _letters(int n, bool upper) {
  var v = n;
  if (v < 1) v = 1;
  final sb = StringBuffer();
  while (v > 0) {
    v--;
    sb.write(String.fromCharCode((upper ? 65 : 97) + v % 26));
    v ~/= 26;
  }
  return sb.toString().split('').reversed.join();
}

String _roman(int n, bool upper) {
  const vals = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1];
  const syms = ['M', 'CM', 'D', 'CD', 'C', 'XC', 'L', 'XL', 'X', 'IX', 'V', 'IV', 'I'];
  var v = math.max(1, math.min(n, 3999));
  final sb = StringBuffer();
  for (var i = 0; i < vals.length; i++) {
    while (v >= vals[i]) {
      sb.write(syms[i]);
      v -= vals[i];
    }
  }
  final s = sb.toString();
  return upper ? s : s.toLowerCase();
}

String _formatCounter(int n, String fmt) {
  switch (fmt) {
    case 'lowerLetter':
      return _letters(n, false);
    case 'upperLetter':
      return _letters(n, true);
    case 'lowerRoman':
      return _roman(n, false);
    case 'upperRoman':
      return _roman(n, true);
    case 'decimalZero':
      return n.toString().padLeft(2, '0');
    case 'none':
      return '';
    default:
      return n.toString();
  }
}

String _bulletChar(String text) {
  if (text.isEmpty) return '•';
  final code = text.codeUnitAt(0);
  if (code == 0xF0B7) return '•';
  if (code == 0xF0A7) return '▪';
  if (code == 0xF0D8) return '➢';
  if (code == 0xF0FC) return '✓';
  if (code >= 0xF000 && code <= 0xF0FF) return '•';
  if (text == 'o') return '◦';
  return text;
}

class _Marker {
  final String text;
  final double? left;
  final double? hanging;
  final int? color;
  const _Marker(this.text, this.left, this.hanging, this.color);
}

_Marker? _nextMarker(_Ctx ctx, int numId, int ilvl) {
  if (numId <= 0) return null;
  final aid = ctx.numToAbs[numId];
  final levels = aid == null ? null : ctx.abstracts[aid];
  if (levels == null || ilvl < 0 || ilvl > 8) return null;
  final lvl = levels[ilvl];
  if (lvl == null) return null;

  final c = ctx.counters.putIfAbsent(numId, () => List<int>.filled(9, 0));
  if (lvl.fmt == 'bullet') {
    return _Marker(_bulletChar(lvl.text), lvl.left, lvl.hanging, lvl.color);
  }
  c[ilvl] = c[ilvl] == 0 ? lvl.start : c[ilvl] + 1;
  for (var i = ilvl + 1; i < 9; i++) {
    c[i] = 0;
  }

  final text = lvl.text.replaceAllMapped(RegExp(r'%(\d)'), (m) {
    final level = int.parse(m[1]!) - 1;
    if (level < 0 || level > 8) return '';
    final l = levels[level];
    final value = c[level] == 0 ? (l?.start ?? 1) : c[level];
    return _formatCounter(value, l?.fmt ?? 'decimal');
  });
  return _Marker(text, lvl.left, lvl.hanging, lvl.color);
}

// =====================================================================
// O'qish
// =====================================================================

DDoc parseDocx(String path, String? mediaDir) {
  final bytes = File(path).readAsBytesSync();
  final archive = openZip(bytes);
  final docXml = zipText(archive, 'word/document.xml');
  if (docXml == null) {
    throw const FormatException('Faylda "word/document.xml" topilmadi');
  }
  final doc = parseOfficeXml(docXml);
  final bodies = doc.findAllElements('body');
  if (bodies.isEmpty) {
    throw const FormatException('Hujjat tanasi topilmadi');
  }

  final rels = zipRelationships(archive, 'word/_rels/document.xml.rels', 'word/');
  final ctx = _Ctx(archive, rels, MediaSink(mediaDir));

  final relXml = zipText(archive, 'word/_rels/document.xml.rels');
  if (relXml != null) {
    try {
      for (final r in parseOfficeXml(relXml).findAllElements('Relationship')) {
        final id = r.getAttribute('Id');
        final target = r.getAttribute('Target');
        if (id != null && target != null && r.getAttribute('TargetMode') == 'External') {
          ctx.links[id] = target;
        }
      }
    } catch (_) {}
  }

  _readTheme(ctx);
  _readStyles(ctx);
  _readNumbering(ctx);

  final blocks = <DBlock>[];
  _blocks(bodies.first, blocks, ctx, null);

  var pw = 595.0;
  var ph = 842.0;
  var ml = 72.0;
  var mr = 72.0;
  var mt = 72.0;
  var mb = 72.0;
  final sect = _c(bodies.first, 'sectPr');
  if (sect != null) {
    final sz = _c(sect, 'pgSz');
    if (sz != null) {
      pw = _twips(_a(sz, 'w')) ?? pw;
      ph = _twips(_a(sz, 'h')) ?? ph;
    }
    final mar = _c(sect, 'pgMar');
    if (mar != null) {
      ml = _twips(_a(mar, 'left')) ?? ml;
      mr = _twips(_a(mar, 'right')) ?? mr;
      mt = _twips(_a(mar, 'top')) ?? mt;
      mb = _twips(_a(mar, 'bottom')) ?? mb;
    }
  }
  if (pw < 100 || ml + mr >= pw - 50) {
    pw = 595;
    ml = 72;
    mr = 72;
  }
  return DDoc(blocks, pw, ph, ml, mr, mt, mb);
}

void _blocks(XmlElement parent, List<DBlock> out, _Ctx ctx, _RP? tableRp) {
  for (final n in parent.childElements) {
    switch (n.name.local) {
      case 'p':
        _paragraph(n, out, ctx, tableRp);
        break;
      case 'tbl':
        final t = _table(n, ctx);
        if (t != null) out.add(t);
        break;
      case 'sdt':
        final content = _c(n, 'sdtContent');
        if (content != null) _blocks(content, out, ctx, tableRp);
        break;
      case 'ins':
      case 'customXml':
      case 'smartTag':
        _blocks(n, out, ctx, tableRp);
        break;
    }
  }
}

void _paragraph(XmlElement para, List<DBlock> out, _Ctx ctx, _RP? tableRp) {
  final pPr = _c(para, 'pPr');
  final styleId = _a(_c(pPr, 'pStyle') ?? para, 'val');
  final hasStyle = _c(pPr, 'pStyle') != null;
  final sid = hasStyle ? styleId : ctx.defParaStyle;

  final pp = _PP()
    ..apply(ctx.defPP)
    ..apply(_stylePP(ctx, sid))
    ..apply(_readPP(pPr, ctx));

  final baseRp = _RP()
    ..apply(ctx.defRP)
    ..apply(_styleRP(ctx, sid));
  if (tableRp != null) baseRp.apply(tableRp);

  final runs = <DRun>[];
  final extra = <DBlock>[];
  _collect(para, baseRp, runs, ctx, false, extra);

  // Raqamlash
  String? marker;
  double markerWidth = 0;
  int? markerColor;
  var left = pp.left ?? 0;
  var first = pp.first ?? 0;
  if (pp.numId != null && pp.numId! > 0) {
    final m = _nextMarker(ctx, pp.numId!, pp.ilvl ?? 0);
    if (m != null && m.text.isNotEmpty) {
      marker = m.text;
      markerColor = m.color;
      final directInd = _c(pPr, 'ind');
      if (directInd == null || pp.left == null) {
        left = m.left ?? left;
      }
      final hanging = m.hanging ?? 18;
      if (pp.first == null || _c(directInd, 'hanging') == null) {
        first = -hanging;
      }
      markerWidth = math.max(-first, 14);
    }
  }

  // Sarlavha darajasi
  var heading = 0;
  final styleName = (sid == null ? null : ctx.styles[sid]?.name)?.toLowerCase();
  if (styleName != null) {
    final m = RegExp(r'^heading\s*(\d)').firstMatch(styleName);
    if (m != null) heading = int.parse(m[1]!);
    if (styleName == 'title') heading = 1;
  }
  if (heading == 0 && pp.outline != null && pp.outline! < 9) {
    heading = pp.outline! + 1;
  }

  var lineMul = 0.0;
  var lineExact = 0.0;
  if (pp.line != null) {
    final rule = pp.lineRule ?? 'auto';
    if (rule == 'auto') {
      lineMul = pp.line! / 240;
    } else {
      lineExact = pp.line! / 20;
    }
  }

  var breakBefore = pp.pageBreakBefore ?? false;
  // Abzas boshidagi sahifa uzilishi
  if (runs.isNotEmpty && runs.first.pageBreak) {
    breakBefore = true;
    runs.removeAt(0);
  }
  var breakAfter = false;
  if (runs.isNotEmpty && runs.last.pageBreak) {
    breakAfter = true;
    runs.removeLast();
  }

  final defSize = baseRp.sz ?? 11;
  if (runs.isEmpty && marker == null && extra.isEmpty && !breakBefore && !breakAfter) {
    // Bo'sh abzas bo'sh qator bo'lib qoladi
    out.add(DPara(
      runs: const <DRun>[],
      before: pp.before ?? 0,
      after: pp.after ?? 0,
      lineMul: lineMul,
      lineExact: lineExact,
      size: defSize,
    ));
    return;
  }

  out.add(DPara(
    runs: runs,
    align: pp.align ?? 'left',
    left: left,
    right: pp.right ?? 0,
    firstLine: first,
    before: pp.before ?? 0,
    after: pp.after ?? 0,
    lineMul: lineMul,
    lineExact: lineExact,
    marker: marker,
    markerWidth: markerWidth,
    markerColor: markerColor,
    shade: pp.shd,
    borderTop: pp.bTop,
    borderBottom: pp.bBottom,
    heading: heading,
    pageBreakBefore: breakBefore,
    size: defSize,
  ));
  out.addAll(extra);
  if (breakAfter) {
    out.add(const DPara(runs: <DRun>[], pageBreakBefore: true, size: 1));
  }
}

void _collect(
  XmlElement parent,
  _RP base,
  List<DRun> out,
  _Ctx ctx,
  bool link,
  List<DBlock> extra, [
  String? href,
]) {
  for (final n in parent.childElements) {
    switch (n.name.local) {
      case 'r':
        _run(n, base, out, ctx, link, extra, href);
        break;
      case 'hyperlink':
        final rid = _a(n, 'id');
        _collect(n, base, out, ctx, true, extra, rid == null ? null : ctx.links[rid]);
        break;
      case 'ins':
      case 'smartTag':
      case 'fldSimple':
      case 'customXml':
      case 'dir':
      case 'bdo':
        _collect(n, base, out, ctx, link, extra, href);
        break;
      case 'sdt':
        final content = _c(n, 'sdtContent');
        if (content != null) _collect(content, base, out, ctx, link, extra, href);
        break;
      case 'AlternateContent':
        final choice = _c(n, 'Choice') ?? _c(n, 'Fallback');
        if (choice != null) _collect(choice, base, out, ctx, link, extra, href);
        break;
    }
  }
}

void _run(
  XmlElement r,
  _RP base,
  List<DRun> out,
  _Ctx ctx,
  bool link,
  List<DBlock> extra, [
  String? href,
]) {
  final rPr = _c(r, 'rPr');
  final rp = base.copy();
  final rs = _c(rPr, 'rStyle');
  if (rs != null) rp.apply(_styleRP(ctx, _a(rs, 'val')));
  rp.apply(_readRP(rPr, ctx));

  final sb = StringBuffer();

  DRun make(String text) {
    var color = rp.color;
    var underline = rp.u ?? false;
    if (link && color == null) {
      color = 0xFF0563C1;
      underline = true;
    }
    return DRun(
      text: (rp.caps ?? false) ? text.toUpperCase() : text,
      bold: rp.b ?? false,
      italic: rp.i ?? false,
      underline: underline,
      strike: rp.strike ?? false,
      color: color,
      size: rp.sz ?? 11,
      font: rp.font,
      highlight: rp.hi,
      shade: rp.shd,
      vert: rp.vert ?? 0,
      link: link,
      href: href,
    );
  }

  void flush() {
    if (sb.isEmpty) return;
    out.add(make(sb.toString()));
    sb.clear();
  }

  void content(XmlElement el) {
    for (final n in el.childElements) {
      switch (n.name.local) {
        case 't':
          sb.write(n.innerText);
          break;
        case 'tab':
          sb.write('    ');
          break;
        case 'br':
          final type = _a(n, 'type');
          if (type == 'page') {
            flush();
            out.add(const DRun(pageBreak: true));
          } else {
            sb.write('\n');
          }
          break;
        case 'cr':
          sb.write('\n');
          break;
        case 'noBreakHyphen':
          sb.write('‑');
          break;
        case 'sym':
          final code = int.tryParse(_a(n, 'char') ?? '', radix: 16);
          if (code != null) {
            sb.write(code >= 0xF000 && code <= 0xF0FF
                ? '•'
                : String.fromCharCode(code));
          }
          break;
        case 'drawing':
        case 'pict':
        case 'object':
          flush();
          _images(n, rp, out, ctx, extra);
          break;
        case 'AlternateContent':
          final choice = _c(n, 'Choice') ?? _c(n, 'Fallback');
          if (choice != null) content(choice);
          break;
      }
    }
  }

  content(r);
  flush();
}

void _images(
  XmlElement el,
  _RP rp,
  List<DRun> out,
  _Ctx ctx,
  List<DBlock> extra,
) {
  double w = 0;
  double h = 0;
  for (final e in el.descendants.whereType<XmlElement>()) {
    if (e.name.local == 'extent') {
      final cx = double.tryParse(_a(e, 'cx') ?? '');
      final cy = double.tryParse(_a(e, 'cy') ?? '');
      if (cx != null && cy != null) {
        w = cx / 12700;
        h = cy / 12700;
      }
      break;
    }
  }

  final ids = <String>[];
  for (final e in el.descendants.whereType<XmlElement>()) {
    final name = e.name.local;
    if (name == 'blip') {
      final id = _a(e, 'embed');
      if (id != null) ids.add(id);
    } else if (name == 'imagedata') {
      final id = _a(e, 'id');
      if (id != null) ids.add(id);
    }
  }
  for (final id in ids.take(ids.length > 1 ? 1 : ids.length)) {
    final entry = ctx.rels[id];
    if (entry == null) continue;
    final line = ctx.media.line(ctx.archive, entry);
    if (line == null) continue;
    final cut = line.indexOf(mediaSep);
    if (cut < 0) continue;
    out.add(DRun(image: line.substring(cut + 1), imgW: w, imgH: h));
  }

  // Matn qutilari (text box) ichidagi abzaslar
  for (final tb in el.descendants.whereType<XmlElement>()) {
    if (tb.name.local != 'txbxContent') continue;
    var nested = false;
    XmlNode? up = tb.parent;
    while (up != null && up != el) {
      if (up is XmlElement && up.name.local == 'txbxContent') {
        nested = true;
        break;
      }
      up = up.parent;
    }
    if (nested) continue;
    _blocks(tb, extra, ctx, null);
  }
}

DTable? _table(XmlElement tbl, _Ctx ctx) {
  final tblPr = _c(tbl, 'tblPr');
  final styleId = _a(_c(tblPr, 'tblStyle') ?? tbl, 'val');
  final hasStyle = _c(tblPr, 'tblStyle') != null;
  final style = hasStyle ? ctx.styles[styleId] : null;

  final tb = _styleTB(ctx, hasStyle ? styleId : null);
  final direct = _readTB(_c(tblPr, 'tblBorders'), ctx);
  final borders = direct.any ? direct : tb;

  final grid = <double>[];
  final g = _c(tbl, 'tblGrid');
  if (g != null) {
    for (final col in g.findElements('gridCol')) {
      grid.add(_twips(_a(col, 'w')) ?? 50);
    }
  }

  final look = _c(tblPr, 'tblLook');
  var firstRow = true;
  var bandRows = true;
  if (look != null) {
    final fr = _a(look, 'firstRow');
    final nh = _a(look, 'noHBand');
    if (fr != null) firstRow = fr == '1' || fr == 'true';
    if (nh != null) bandRows = !(nh == '1' || nh == 'true');
    final val = int.tryParse(_a(look, 'val') ?? '', radix: 16);
    if (val != null && fr == null) {
      firstRow = (val & 0x0020) != 0;
      bandRows = (val & 0x0200) == 0;
    }
  }

  final rowEls = tbl.findElements('tr').toList();
  final rows = <List<DCell>>[];
  for (var ri = 0; ri < rowEls.length; ri++) {
    final cells = <DCell>[];
    final cellEls = rowEls[ri].findElements('tc').toList();
    var col = 0;
    for (var ci = 0; ci < cellEls.length; ci++) {
      final tc = cellEls[ci];
      final tcPr = _c(tc, 'tcPr');
      final span = math.max(1, int.tryParse(_a(_c(tcPr, 'gridSpan') ?? tc, 'val') ?? '') ?? 1);
      final spanReal = _c(tcPr, 'gridSpan') == null ? 1 : span;
      final vm = _c(tcPr, 'vMerge');
      final vContinue = vm != null && _a(vm, 'val') != 'restart';

      var shade = _shdFill(tcPr);
      _RP? cellRp;
      if (shade == null && style != null) {
        if (ri == 0 && firstRow && style.firstRowShade != null) {
          shade = style.firstRowShade;
        } else if (bandRows && style.band1Shade != null && (ri - (firstRow ? 1 : 0)) % 2 == 0 && ri >= (firstRow ? 1 : 0)) {
          shade = style.band1Shade;
        }
      }
      if (ri == 0 && firstRow && style?.firstRowRp != null) {
        cellRp = style!.firstRowRp;
      }

      final lastCol = col + spanReal >= grid.length || ci == cellEls.length - 1;
      final lastRow = ri == rowEls.length - 1;
      final tcb = _c(tcPr, 'tcBorders');
      DSide? side(String name, DSide? fallback) {
        final el = tcb == null ? null : (_c(tcb, name) ?? (name == 'left' ? _c(tcb, 'start') : (name == 'right' ? _c(tcb, 'end') : null)));
        if (el == null) return fallback;
        return _readSide(el, ctx);
      }

      final blocks = <DBlock>[];
      _blocks(tc, blocks, ctx, cellRp);

      cells.add(DCell(
        blocks: blocks,
        span: spanReal,
        vContinue: vContinue,
        shade: shade,
        top: side('top', ri == 0 ? borders.top : borders.insideH),
        left: side('left', col == 0 ? borders.left : borders.insideV),
        bottom: side('bottom', lastRow ? borders.bottom : null),
        right: side('right', lastCol ? borders.right : null),
      ));
      col += spanReal;
    }
    rows.add(cells);
  }
  if (rows.isEmpty) return null;

  if (grid.isEmpty) {
    var maxCols = 0;
    for (final r in rows) {
      var n = 0;
      for (final c in r) {
        n += c.span;
      }
      maxCols = math.max(maxCols, n);
    }
    for (var i = 0; i < maxCols; i++) {
      grid.add(100);
    }
  }
  return DTable(rows, grid);
}
