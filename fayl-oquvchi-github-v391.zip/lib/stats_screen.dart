import 'package:flutter/material.dart' hide Text;

import 'document_parser.dart';
import 'l10n.dart';
import 'library.dart';
import 'theme.dart';
import 'user_data.dart';

/// Kutubxona va o'qish bo'yicha statistika.
class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});

  static String _label(DocKind kind) => switch (kind) {
        DocKind.pdf => 'PDF',
        DocKind.text => 'Matn',
        DocKind.html => 'HTML',
        DocKind.docx => 'Word',
        DocKind.xlsx => 'Excel',
        DocKind.pptx => 'PowerPoint',
        DocKind.epub => 'ePub',
        DocKind.archive => 'Arxiv',
        DocKind.external => 'Boshqa',
      };

  @override
  Widget build(BuildContext context) {
    return GradientBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(title: const Text('Statistika')),
        body: ContentWidth(
          child: FutureBuilder<List<LibraryItem>>(
            future: Library.list(),
            builder: (context, snap) {
              if (snap.connectionState != ConnectionState.done) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snap.hasError) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(
                      "Statistikani yuklab bo'lmadi",
                      style: TextStyle(color: Theme.of(context).colorScheme.error),
                    ),
                  ),
                );
              }
              return _content(context, snap.data ?? const <LibraryItem>[]);
            },
          ),
        ),
      ),
    );
  }

  Widget _content(BuildContext context, List<LibraryItem> items) {
    final scheme = Theme.of(context).colorScheme;
    final data = UserData.instance;

    var total = 0;
    var favorites = 0;
    var reading = 0;
    var finished = 0;
    var bookmarks = 0;
    final counts = <DocKind, int>{};
    final sizes = <DocKind, int>{};

    for (final item in items) {
      total += item.size;
      final kind = kindOf(item.file.path);
      counts[kind] = (counts[kind] ?? 0) + 1;
      sizes[kind] = (sizes[kind] ?? 0) + item.size;

      if (data.isFavorite(item.key)) favorites++;
      final progress = data.progress(item.key);
      if (progress >= 0.98) {
        finished++;
      } else if (progress > 0.005) {
        reading++;
      }
      bookmarks += data.bookmarks(item.key).length;
    }

    final kinds = counts.keys.toList()
      ..sort((a, b) => (sizes[b] ?? 0).compareTo(sizes[a] ?? 0));
    final biggest = kinds.isEmpty ? 1 : (sizes[kinds.first] ?? 1).clamp(1, 1 << 62);

    Widget stat(IconData icon, Color color, String value, String label) {
      return Expanded(
        child: Glass(
          radius: 22,
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 10),
          child: Column(
            children: [
              Icon(icon, color: color, size: 26),
              const SizedBox(height: 8),
              Text(
                value,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
              ),
              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant),
              ),
            ],
          ),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
      children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            gradient: AppPalette.current.heroGradient,
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Kutubxona',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                        color: Colors.white.withAlpha(210),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '${items.length} ta fayl',
                      style: const TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      formatSize(total),
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white.withAlpha(220),
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.insights_rounded, color: Colors.white70, size: 56),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            stat(Icons.star_rounded, Colors.amber, '$favorites', t('Sevimlilar')),
            const SizedBox(width: 10),
            stat(
              Icons.auto_stories_rounded,
              scheme.primary,
              '$reading',
              t("O'qilmoqda"),
            ),
            const SizedBox(width: 10),
            stat(
              Icons.check_circle_rounded,
              const Color(0xFF1E8E55),
              '$finished',
              t('Tugatilgan'),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Glass(
          radius: 22,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              Icon(Icons.bookmark_rounded, color: scheme.primary),
              const SizedBox(width: 12),
              Expanded(child: Text("Xatcho'plar")),
              Text(
                '$bookmarks',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const Text(
          'Fayl turlari',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 10),
        if (kinds.isEmpty)
          Glass(
            radius: 22,
            padding: const EdgeInsets.all(20),
            child: const Center(child: Text("Hali fayl yo'q")),
          )
        else
          for (final kind in kinds)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Glass(
                radius: 22,
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    KindBadge(kind: kind, icon: _icon(kind), size: 46),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  _label(kind),
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                              Text(
                                '${counts[kind]} • ${formatSize(sizes[kind] ?? 0)}',
                                style: TextStyle(
                                  fontSize: 12.5,
                                  color: scheme.onSurfaceVariant,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(
                              value: (sizes[kind] ?? 0) / biggest,
                              minHeight: 6,
                              color: AppTheme.kindColor(kind),
                              backgroundColor:
                                  AppTheme.kindColor(kind).withAlpha(36),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
      ],
    );
  }

  static IconData _icon(DocKind kind) => switch (kind) {
        DocKind.pdf => Icons.picture_as_pdf_outlined,
        DocKind.text => Icons.article_outlined,
        DocKind.html => Icons.language,
        DocKind.docx => Icons.description_outlined,
        DocKind.xlsx => Icons.table_chart_outlined,
        DocKind.pptx => Icons.slideshow_outlined,
        DocKind.epub => Icons.menu_book_outlined,
        DocKind.archive => Icons.archive_outlined,
        DocKind.external => Icons.insert_drive_file_outlined,
      };
}
