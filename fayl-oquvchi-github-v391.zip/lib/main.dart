import 'dart:async';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import 'package:share_plus/share_plus.dart';

import 'archive_reader.dart';
import 'dialogs.dart';
import 'document_parser.dart';
import 'l10n.dart';
import 'library.dart';
import 'lock.dart';
import 'opener.dart';
import 'settings.dart';
import 'settings_screen.dart';
import 'stats_screen.dart';
import 'theme.dart';
import 'user_data.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppSettings.instance.load();
  await UserData.instance.init();
  await LockService.instance.init();
  runApp(const CleanDocumentReaderApp());
}

class CleanDocumentReaderApp extends StatelessWidget {
  const CleanDocumentReaderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppSettings.instance,
      builder: (context, _) {
        return MaterialApp(
          title: "Reklamasiz Fayl O'quvchi",
          debugShowCheckedModeBanner: false,
          theme: AppTheme.build(Brightness.light),
          darkTheme: AppTheme.build(Brightness.dark),
          themeMode: AppSettings.instance.themeMode,
          builder: (context, child) =>
              LockGate(child: child ?? const SizedBox.shrink()),
          home: const HomeScreen(),
        );
      },
    );
  }
}

enum SortMode { added, opened, name, size }

/// Papka tanlash oynasining natijasi: [name] null bo'lsa "papkasiz".
class _FolderChoice {
  final String? name;
  final bool create;
  const _FolderChoice(this.name, {this.create = false});
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _data = UserData.instance;
  final _settings = AppSettings.instance;
  final _searchController = TextEditingController();
  final Set<String> _selected = <String>{};

  List<LibraryItem> _items = [];
  bool _loading = true;
  bool _busy = false;
  bool _searching = false;
  int _tab = 0;
  DocKind? _kindFilter;
  String _query = '';
  String? _folder;
  StreamSubscription<List<SharedMediaFile>>? _shareSub;

  bool get _selecting => _selected.isNotEmpty;
  bool get _favOnly => _tab == 2;

  SortMode get _sort => SortMode.values[_settings.sortMode.clamp(0, 3).toInt()];

  void _tick() {
    if (_settings.haptics) HapticFeedback.selectionClick();
  }

  void _onSettings() {
    if (!mounted) return;
    setState(() {
      if (_tab == 2 && !_settings.navFavorites) _tab = 0;
    });
  }

  @override
  void initState() {
    super.initState();
    _settings.addListener(_onSettings);
    _reload(clearCache: true);
    _initSharing();
  }

  @override
  void dispose() {
    _settings.removeListener(_onSettings);
    _shareSub?.cancel();
    _searchController.dispose();
    super.dispose();
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _reload({bool clearCache = false}) async {
    try {
      // Kesh faqat ilova ishga tushganda va ekranga qaytganda tozalanadi,
      // ochiq fayl ostidan o'chirib yubormaslik uchun
      if (clearCache) await ArchiveReader.clearCache();
      final items = await Library.list();
      if (mounted) {
        setState(() {
          _items = items;
          final keys = items.map((i) => i.key).toSet();
          _selected.removeWhere((k) => !keys.contains(k));
          if (_folder != null && !_data.folders().contains(_folder)) {
            _folder = null;
          }
        });
      }
    } catch (e) {
      _snack('Kutubxonani yuklashda xatolik: ${errorText(e)}');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // ---------- Ro'yxatni saralash va qidirish ----------

  List<LibraryItem> get _visible {
    final q = _query.trim().toLowerCase();
    final list = _items.where((item) {
      if (_favOnly && !_data.isFavorite(item.key)) return false;
      if (_kindFilter != null && kindOf(item.file.path) != _kindFilter) {
        return false;
      }
      if (_folder != null && _data.folderOf(item.key) != _folder) return false;
      if (q.isNotEmpty && !item.name.toLowerCase().contains(q)) return false;
      return true;
    }).toList();

    switch (_sort) {
      case SortMode.added:
        list.sort((a, b) => b.modified.compareTo(a.modified));
        break;
      case SortMode.opened:
        list.sort((a, b) {
          final c = _data.openedAt(b.key).compareTo(_data.openedAt(a.key));
          return c != 0 ? c : b.modified.compareTo(a.modified);
        });
        break;
      case SortMode.name:
        list.sort(
          (a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()),
        );
        break;
      case SortMode.size:
        list.sort((a, b) => b.size.compareTo(a.size));
        break;
    }
    return list;
  }

  /// Eng oxirgi ochilgan fayl ("Davom etish" kartasi uchun).
  LibraryItem? get _lastOpened {
    LibraryItem? best;
    var bestAt = 0;
    for (final item in _items) {
      final at = _data.openedAt(item.key);
      if (at > bestAt) {
        best = item;
        bestAt = at;
      }
    }
    return best;
  }

  // ---------- Boshqa ilovadan kelgan fayllar ----------

  void _initSharing() {
    final rsi = ReceiveSharingIntent.instance;
    _shareSub = rsi.getMediaStream().listen(
          _handleShared,
          onError: (_) {},
        );
    rsi.getInitialMedia().then(_handleShared);
  }

  Future<void> _handleShared(List<SharedMediaFile> files) async {
    if (files.isEmpty || !mounted) return;
    ReceiveSharingIntent.instance.reset();

    // Ulashilgan matn yoki havolada "path" qiymati matnning o'zi bo'ladi
    final paths = <String>[
      for (final f in files)
        if (f.type != SharedMediaType.text && f.type != SharedMediaType.url)
          f.path,
    ];

    if (paths.isEmpty) {
      _snack("Faqat fayllarni qabul qilish mumkin, matnni emas.");
      return;
    }
    await _importPaths(paths);
  }

  // ---------- Fayl qo'shish ----------

  Future<void> _pickFile() async {
    FilePickerResult? result;
    try {
      result = await FilePicker.platform.pickFiles(
        type: FileType.any,
        allowMultiple: true,
      );
    } catch (e) {
      _snack('Fayl tanlashda xatolik: ${errorText(e)}');
      return;
    }

    if (result == null) return;

    final paths = <String>[
      for (final f in result.files)
        if (f.path != null) f.path!,
    ];
    if (paths.isEmpty) {
      _snack(
        "Fayl yo'lini olib bo'lmadi. Faylni telefon xotirasiga ko'chirib, qayta urinib ko'ring.",
      );
      return;
    }
    await _importPaths(paths);
  }

  Future<void> _importPaths(List<String> paths) async {
    if (paths.isEmpty || !mounted) return;

    setState(() => _busy = true);
    String? last;
    var failed = 0;
    try {
      for (final path in paths) {
        try {
          final saved = await Library.importFile(path);
          last = saved.path;
          // Papka tanlangan bo'lsa, yangi fayl shu papkaga tushadi
          if (_folder != null) {
            await _data.setFolder(p.basename(saved.path), _folder);
          }
        } catch (_) {
          failed++;
        }
      }

      await _reload();
      if (failed > 0) _snack("Qo'shib bo'lmadi: $failed");

      if (last != null) {
        if (paths.length == 1) {
          await _openItem(last);
        } else {
          _snack("Qo'shildi: ${paths.length - failed}");
        }
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _openItem(String path) async {
    if (!mounted) return;
    if (Library.isInLibrary(path)) {
      await _data.markOpened(p.basename(path));
    }
    if (!mounted) return;
    await openDocument(context, path);
    await _reload(clearCache: true);
  }

  // ---------- Tanlash ----------

  void _toggleSelect(LibraryItem item) {
    _tick();
    setState(() {
      if (!_selected.remove(item.key)) _selected.add(item.key);
    });
  }

  List<LibraryItem> get _selectedItems => [
        for (final item in _items)
          if (_selected.contains(item.key)) item,
      ];

  void _selectAll() {
    setState(() {
      for (final item in _visible) {
        _selected.add(item.key);
      }
    });
  }

  Future<void> _deleteSelected() async {
    final items = _selectedItems;
    if (items.isEmpty) return;

    final ok = await confirmDialog(
      context,
      title: "Tanlangan fayllarni o'chirasizmi?",
      message: 'Fayllar soni: ${items.length}',
      confirm: "O'chirish",
    );
    if (!ok) return;

    var failed = 0;
    for (final item in items) {
      try {
        await item.file.delete();
        await _data.forget(item.key);
      } catch (_) {
        failed++;
      }
    }

    if (mounted) setState(_selected.clear);
    if (failed > 0) _snack("O'chirib bo'lmadi: $failed");
    await _reload();
  }

  Future<void> _shareSelected() async {
    final items = _selectedItems;
    if (items.isEmpty) return;
    try {
      await Share.shareXFiles([for (final i in items) XFile(i.file.path)]);
    } catch (e) {
      _snack("Ulashib bo'lmadi: ${errorText(e)}");
    }
  }

  Future<void> _favoriteSelected() async {
    final items = _selectedItems;
    if (items.isEmpty) return;

    final allFav = items.every((i) => _data.isFavorite(i.key));
    for (final item in items) {
      await _data.setFavorite(item.key, !allFav);
    }
    if (mounted) setState(_selected.clear);
  }

  Future<void> _moveSelected() async {
    final items = _selectedItems;
    if (items.isEmpty) return;
    await _moveItems(items);
    if (mounted) setState(_selected.clear);
  }

  // ---------- Papkalar ----------

  Future<_FolderChoice?> _pickFolder() async {
    final folders = _data.folders();

    final choice = await showDialog<_FolderChoice>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: const Text("Papkaga ko'chirish"),
        children: [
          SimpleDialogOption(
            onPressed: () => Navigator.pop(ctx, const _FolderChoice(null)),
            child: const Text('Papkasiz'),
          ),
          for (final f in folders)
            SimpleDialogOption(
              onPressed: () => Navigator.pop(ctx, _FolderChoice(f)),
              child: Text(f),
            ),
          SimpleDialogOption(
            onPressed: () =>
                Navigator.pop(ctx, const _FolderChoice(null, create: true)),
            child: const Row(
              children: [
                Icon(Icons.create_new_folder_outlined),
                SizedBox(width: 12),
                Text('Yangi papka...'),
              ],
            ),
          ),
        ],
      ),
    );
    if (choice == null || !mounted) return null;
    if (!choice.create) return choice;

    final name = await promptText(
      context,
      title: 'Yangi papka',
      label: 'Papka nomi',
      confirm: 'Yaratish',
    );
    if (name == null || name.trim().isEmpty) return null;

    await _data.addFolder(name);
    final clean = name.trim();
    final existing = _data.folders().firstWhere(
          (f) => f.toLowerCase() == clean.toLowerCase(),
          orElse: () => clean,
        );
    return _FolderChoice(existing);
  }

  Future<void> _moveItems(List<LibraryItem> items) async {
    final choice = await _pickFolder();
    if (choice == null) return;

    for (final item in items) {
      await _data.setFolder(item.key, choice.name);
    }
    if (mounted) setState(() {});
  }

  Future<void> _createFolder() async {
    final name = await promptText(
      context,
      title: 'Yangi papka',
      label: 'Papka nomi',
      confirm: 'Yaratish',
    );
    if (name == null || name.trim().isEmpty) return;

    final ok = await _data.addFolder(name);
    if (!ok) {
      _snack("Bunday papka allaqachon mavjud");
      return;
    }
    if (mounted) setState(() => _folder = name.trim());
  }

  Future<void> _folderMenu(String name) async {
    final action = await showDialog<String>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: Text(name),
        children: [
          SimpleDialogOption(
            onPressed: () => Navigator.pop(ctx, 'rename'),
            child: const Text("Nomini o'zgartirish"),
          ),
          SimpleDialogOption(
            onPressed: () => Navigator.pop(ctx, 'delete'),
            child: const Text("Papkani o'chirish"),
          ),
        ],
      ),
    );
    if (action == null || !mounted) return;

    if (action == 'rename') {
      final value = await promptText(
        context,
        title: "Nomini o'zgartirish",
        label: 'Papka nomi',
        initial: name,
        confirm: 'Saqlash',
      );
      if (value == null || value.trim().isEmpty) return;
      await _data.renameFolder(name, value);
      if (mounted) {
        setState(() {
          if (_folder == name) _folder = value.trim();
        });
      }
    } else {
      final ok = await confirmDialog(
        context,
        title: "Papkani o'chirasizmi?",
        message: "Papkadagi fayllar o'chirilmaydi, ular papkasiz bo'lib qoladi.",
        confirm: "O'chirish",
      );
      if (!ok) return;
      await _data.deleteFolder(name);
      if (mounted) {
        setState(() {
          if (_folder == name) _folder = null;
        });
      }
    }
  }

  // ---------- Bitta fayl amallari ----------

  Future<void> _toggleFavorite(LibraryItem item) async {
    await _data.setFavorite(item.key, !_data.isFavorite(item.key));
    if (mounted) setState(() {});
  }

  Future<void> _rename(LibraryItem item) async {
    final name = await promptText(
      context,
      title: "Nomini o'zgartirish",
      label: 'Fayl nomi',
      initial: item.name,
      confirm: 'Saqlash',
    );
    if (name == null || name.trim().isEmpty || !mounted) return;

    try {
      final renamed = await Library.rename(item.file, name);
      await _data.rename(item.key, p.basename(renamed.path));
      await _reload();
    } catch (e) {
      _snack("Nomini o'zgartirib bo'lmadi: ${errorText(e)}");
    }
  }

  Future<void> _share(LibraryItem item) async {
    try {
      await Share.shareXFiles([XFile(item.file.path)]);
    } catch (e) {
      _snack("Ulashib bo'lmadi: ${errorText(e)}");
    }
  }

  void _showInfo(LibraryItem item) {
    final kind = kindOf(item.file.path);
    final opened = _data.openedAt(item.key);
    final openedText = opened == 0
        ? t('hali ochilmagan')
        : formatDate(DateTime.fromMillisecondsSinceEpoch(opened));
    final folder = _data.folderOf(item.key);

    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(item.name),
        content: Text(
          '${t('Turi')}: ${t(_kindLabel(kind))}\n'
          '${t('Hajmi')}: ${formatSize(item.size)}\n'
          "${t("Qo'shilgan")}: ${formatDate(item.modified)}\n"
          '${t('Oxirgi ochilgan')}: $openedText'
          '${folder == null ? '' : '\n${t('Papka')}: $folder'}',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Yopish'),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmDelete(LibraryItem item) async {
    if (_settings.confirmDelete) {
      final ok = await confirmDialog(
        context,
        title: "Faylni o'chirasizmi?",
        message: item.name,
        confirm: "O'chirish",
      );
      if (!ok) return;
    }

    try {
      await item.file.delete();
      await _data.forget(item.key);
    } catch (e) {
      _snack("O'chirib bo'lmadi: ${errorText(e)}");
    }
    await _reload();
  }

  Future<void> _onItemMenu(String value, LibraryItem item) async {
    switch (value) {
      case 'rename':
        await _rename(item);
        break;
      case 'folder':
        await _moveItems([item]);
        break;
      case 'share':
        await _share(item);
        break;
      case 'info':
        _showInfo(item);
        break;
      case 'delete':
        await _confirmDelete(item);
        break;
    }
  }

  // ---------- Ko'rinish ----------

  PreferredSizeWidget? _buildAppBar() {
    if (_selecting) {
      return AppBar(
        leading: IconButton(
          tooltip: t('Bekor qilish'),
          icon: const Icon(Icons.close),
          onPressed: () => setState(_selected.clear),
        ),
        title: Text('Tanlandi: ${_selected.length}'),
        actions: [
          IconButton(
            tooltip: t('Hammasini tanlash'),
            icon: const Icon(Icons.select_all),
            onPressed: _selectAll,
          ),
          IconButton(
            tooltip: t('Sevimlilar'),
            icon: const Icon(Icons.star_border),
            onPressed: _favoriteSelected,
          ),
          IconButton(
            tooltip: t("Papkaga ko'chirish"),
            icon: const Icon(Icons.drive_file_move_outlined),
            onPressed: _moveSelected,
          ),
          IconButton(
            tooltip: t('Ulashish'),
            icon: const Icon(Icons.share_outlined),
            onPressed: _shareSelected,
          ),
          IconButton(
            tooltip: t("O'chirish"),
            icon: const Icon(Icons.delete_outline),
            onPressed: _deleteSelected,
          ),
        ],
      );
    }

    if (_searching) {
      return AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            _searchController.clear();
            setState(() {
              _searching = false;
              _query = '';
            });
          },
        ),
        title: TextField(
          controller: _searchController,
          autofocus: true,
          decoration: InputDecoration(
            hintText: t("Fayl nomi bo'yicha qidirish..."),
            border: InputBorder.none,
          ),
          onChanged: (value) => setState(() => _query = value),
        ),
      );
    }

    return null;
  }

  Widget _emptyState(String title, String message, IconData icon) {
    final colors = Theme.of(context).colorScheme;
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 132,
              height: 132,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    colors.primaryContainer,
                    colors.tertiaryContainer,
                  ],
                ),
              ),
              child: Icon(icon, size: 64, color: colors.primary),
            ),
            const SizedBox(height: 28),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.3,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: colors.onSurfaceVariant,
                height: 1.45,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _folderBar() {
    final folders = _data.folders();

    return SizedBox(
      height: 52,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        children: [
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: ChoiceChip(
              label: const Text('Hammasi'),
              selected: _folder == null,
              onSelected: (_) => setState(() => _folder = null),
            ),
          ),
          for (final name in folders)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: GestureDetector(
                onLongPress: () => _folderMenu(name),
                child: ChoiceChip(
                  avatar: const Icon(Icons.folder_outlined, size: 18),
                  label: Text(name),
                  selected: _folder == name,
                  onSelected: (_) => setState(() => _folder = name),
                ),
              ),
            ),
          ActionChip(
            avatar: const Icon(Icons.add, size: 18),
            label: const Text('Papka'),
            onPressed: _createFolder,
          ),
        ],
      ),
    );
  }

  // ---------- Yangi ko'rinish: tablar va bosh sahifa ----------

  String _greeting() {
    final h = DateTime.now().hour;
    if (h >= 5 && h < 11) return 'Xayrli tong';
    if (h >= 11 && h < 17) return 'Xayrli kun';
    if (h >= 17 && h < 22) return 'Xayrli kech';
    return 'Xayrli tun';
  }

  void _setTab(int index) {
    if (index == _tab) return;
    _tick();
    final leavingSettings = _tab == 3;
    setState(() {
      _tab = index;
      _kindFilter = null;
      _searching = false;
      _query = '';
      _searchController.clear();
      _selected.clear();
    });
    if (leavingSettings) _reload();
  }

  void _openSearch() {
    setState(() {
      if (_tab != 2) _tab = 1;
      _searching = true;
    });
  }

  void _openKind(DocKind kind) {
    setState(() {
      _tab = 1;
      _kindFilter = kind;
    });
  }

  Widget _sectionTitle(String text, {VoidCallback? onAll}) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 22, 12, 10),
      child: Row(
        children: [
          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.2,
              ),
            ),
          ),
          if (onAll != null)
            TextButton(onPressed: onAll, child: const Text('Hammasi')),
        ],
      ),
    );
  }

  Widget _dashHeader() {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: AppPalette.current.heroGradient,
              boxShadow: [
                BoxShadow(
                  color: scheme.primary.withAlpha(70),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: const Icon(
              Icons.auto_stories_rounded,
              color: Colors.white,
              size: 26,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _greeting(),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 14,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
                const Text(
                  "Fayl O'quvchi",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.5,
                  ),
                ),
              ],
            ),
          ),
          GlassIconButton(
            icon: Icons.palette_outlined,
            tooltip: "Ko'rinish",
            onPressed: () => showAppearanceSheet(context),
          ),
        ],
      ),
    );
  }

  Widget _searchPill() {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      child: Glass(
        radius: 24,
        onTap: _openSearch,
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 17),
        child: Row(
          children: [
            Icon(Icons.search_rounded, color: scheme.onSurfaceVariant),
            const SizedBox(width: 12),
            Text(
              'Qidirish...',
              style: TextStyle(fontSize: 17, color: scheme.outline),
            ),
          ],
        ),
      ),
    );
  }

  List<LibraryItem> get _recent {
    final list = [..._items];
    list.sort((a, b) {
      final c = _data.openedAt(b.key).compareTo(_data.openedAt(a.key));
      return c != 0 ? c : b.modified.compareTo(a.modified);
    });
    return list;
  }

  /// Doira ko'rinishidagi so'nggi fayllar qatori.
  Widget _stories() {
    final list = _recent.take(10).toList();
    if (list.isEmpty) return const SizedBox.shrink();
    final scheme = Theme.of(context).colorScheme;

    return SizedBox(
      height: 122,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
        itemCount: list.length,
        separatorBuilder: (_, __) => const SizedBox(width: 14),
        itemBuilder: (context, i) {
          final item = list[i];
          final kind = kindOf(item.file.path);
          final color = AppTheme.kindColor(kind);

          return GestureDetector(
            onTap: () => _openItem(item.file.path),
            child: SizedBox(
              width: 78,
              child: Column(
                children: [
                  Container(
                    width: 74,
                    height: 74,
                    padding: const EdgeInsets.all(3.5),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [color, color.withAlpha(110), scheme.primary],
                      ),
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: scheme.surface,
                        border: Border.all(color: scheme.surface, width: 2),
                      ),
                      child: Icon(_iconFor(kind), size: 30, color: color),
                    ),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    item.name,
                    maxLines: 2,
                    textAlign: TextAlign.center,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 11.5,
                      height: 1.2,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _heroShell({required Widget child, VoidCallback? onTap}) {
    final palette = AppPalette.current;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          gradient: palette.heroGradient,
          border: Border.all(color: Colors.white.withAlpha(70), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: palette.heroB.withAlpha(90),
              blurRadius: 28,
              offset: const Offset(0, 14),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: Stack(
            children: [
              Positioned(
                right: -40,
                top: -50,
                child: Container(
                  width: 190,
                  height: 190,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withAlpha(26),
                  ),
                ),
              ),
              Positioned(
                right: 40,
                bottom: -70,
                child: Container(
                  width: 150,
                  height: 150,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withAlpha(18),
                  ),
                ),
              ),
              Material(
                type: MaterialType.transparency,
                child: InkWell(
                  onTap: onTap,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(22, 20, 18, 20),
                    child: child,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _hero(LibraryItem? last) {
    if (last == null) {
      return _heroShell(
        onTap: _busy ? null : _pickFile,
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Hali fayl yo'q",
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      for (final f in const [
                        'PDF', 'DOCX', 'XLSX', 'PPTX', 'EPUB', 'TXT', 'ZIP',
                      ])
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withAlpha(40),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            f,
                            style: const TextStyle(
                              fontSize: 11.5,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Container(
              width: 54,
              height: 54,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withAlpha(50),
              ),
              child: const Icon(Icons.add_rounded, color: Colors.white, size: 32),
            ),
          ],
        ),
      );
    }

    final progress = _data.progress(last.key);
    final percent = (progress * 100).round();
    final kind = kindOf(last.file.path);

    return _heroShell(
      onTap: () => _openItem(last.file.path),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Davom etish',
                  style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.8,
                    color: Colors.white.withAlpha(210),
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  last.name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 21,
                    height: 1.2,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  '${_kindLabel(kind)} • ${formatSize(last.size)}',
                  style: TextStyle(
                    fontSize: 12.5,
                    color: Colors.white.withAlpha(200),
                  ),
                ),
                if (percent > 0) ...[
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(5),
                          child: LinearProgressIndicator(
                            value: progress,
                            minHeight: 6,
                            backgroundColor: Colors.white.withAlpha(60),
                            color: Colors.white,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        '$percent%',
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(width: 14),
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withAlpha(50),
              border: Border.all(color: Colors.white.withAlpha(90)),
            ),
            child: const Icon(
              Icons.play_arrow_rounded,
              color: Colors.white,
              size: 34,
            ),
          ),
        ],
      ),
    );
  }

  Widget _tile({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required VoidCallback? onTap,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return Glass(
      radius: 26,
      onTap: onTap,
      padding: const EdgeInsets.all(16),
      child: SizedBox(
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [color, Color.alphaBlend(Colors.black26, color)],
                ),
                boxShadow: [
                  BoxShadow(
                    color: color.withAlpha(90),
                    blurRadius: 12,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Icon(icon, color: Colors.white, size: 26),
            ),
            const SizedBox(height: 16),
            Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 3),
            Text(
              subtitle,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 13, color: scheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tiles() {
    final favCount = _items.where((i) => _data.isFavorite(i.key)).length;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 22, 16, 0),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: _tile(
                  icon: Icons.add_rounded,
                  color: const Color(0xFF2F7BE8),
                  title: "Fayl qo'shish",
                  subtitle: 'Telefondan fayl tanlang',
                  onTap: _busy ? null : _pickFile,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _settings.navFavorites
                    ? _tile(
                        icon: Icons.star_rounded,
                        color: const Color(0xFFE91E8C),
                        title: 'Sevimlilar',
                        subtitle: '$favCount ta fayl',
                        onTap: () => _setTab(2),
                      )
                    : _tile(
                        icon: Icons.insights_rounded,
                        color: const Color(0xFF8B5CF6),
                        title: 'Statistika',
                        subtitle: "Fayllar va o'qish bo'yicha",
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => const StatsScreen(),
                          ),
                        ),
                      ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _tile(
                  icon: Icons.folder_rounded,
                  color: const Color(0xFF14B8A6),
                  title: 'Kutubxona',
                  subtitle: '${_items.length} ta fayl',
                  onTap: () => _setTab(1),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _tile(
                  icon: Icons.tune_rounded,
                  color: const Color(0xFFF59E0B),
                  title: 'Sozlamalar',
                  subtitle: 'Til, mavzu, qulf',
                  onTap: () => _setTab(3),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Fayl turlari bo'yicha sanoq (bosilsa, kutubxonada shu tur ochiladi).
  Widget _kindChips() {
    final counts = <DocKind, int>{};
    for (final item in _items) {
      final k = kindOf(item.file.path);
      counts[k] = (counts[k] ?? 0) + 1;
    }
    if (counts.isEmpty) return const SizedBox.shrink();
    final scheme = Theme.of(context).colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionTitle('Fayl turlari'),
        SizedBox(
          height: 76,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            children: [
              for (final e in counts.entries)
                Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: Glass(
                    radius: 22,
                    onTap: () => _openKind(e.key),
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            color: AppTheme.kindColor(e.key).withAlpha(40),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            _iconFor(e.key),
                            size: 22,
                            color: AppTheme.kindColor(e.key),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _kindLabel(e.key),
                              style: const TextStyle(
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            Text(
                              '${e.value} ta fayl',
                              style: TextStyle(
                                fontSize: 12,
                                color: scheme.onSurfaceVariant,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _dashboard() {
    final last = _lastOpened;
    final latest = [..._items]
      ..sort((a, b) => b.modified.compareTo(a.modified));
    final recent = latest.take(4).toList();

    return ListView(
      padding: const EdgeInsets.only(bottom: 130),
      children: [
        _dashHeader(),
        _searchPill(),
        if (_settings.showStories) _stories(),
        if (_settings.showHero) _hero(last),
        if (_settings.showTiles) _tiles(),
        if (_settings.showKinds) _kindChips(),
        if (!_settings.showStories &&
            !_settings.showHero &&
            !_settings.showTiles &&
            !_settings.showKinds &&
            !_settings.showRecent)
          _emptyHome(),
        if (_settings.showRecent && recent.isNotEmpty) ...[
          _sectionTitle("So'nggi qo'shilganlar", onAll: () => _setTab(1)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(children: [for (final i in recent) _fileCard(i)]),
          ),
        ],
      ],
    );
  }

  Widget _emptyHome() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 28, 16, 0),
      child: Glass(
        radius: 24,
        onTap: () => _setTab(3),
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            const Icon(Icons.dashboard_customize_rounded, size: 34),
            const SizedBox(width: 14),
            const Expanded(
              child: Text(
                "Bosh sahifa bo'limlari o'chirilgan. Sozlamalar > Bosh sahifa orqali yoqing.",
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _listHeader(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 16, 6),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.6,
              ),
            ),
          ),
          GlassIconButton(
            icon: Icons.search_rounded,
            tooltip: 'Qidirish',
            onPressed: _openSearch,
          ),
          const SizedBox(width: 10),
          GlassIconButton(
            icon: _settings.gridView
                ? Icons.view_agenda_outlined
                : Icons.grid_view_rounded,
            tooltip: _settings.gridView ? "Ro'yxat" : 'Setka',
            onPressed: () => _settings.setFlag('gridView', !_settings.gridView),
          ),
          const SizedBox(width: 10),
          PopupMenuButton<SortMode>(
            tooltip: t('Saralash'),
            initialValue: _sort,
            onSelected: (mode) =>
                _settings.update(() => _settings.sortMode = mode.index),
            itemBuilder: (_) => const <PopupMenuEntry<SortMode>>[
              PopupMenuItem<SortMode>(
                value: SortMode.added,
                child: Text("Qo'shilgan vaqti"),
              ),
              PopupMenuItem<SortMode>(
                value: SortMode.opened,
                child: Text('Oxirgi ochilgan'),
              ),
              PopupMenuItem<SortMode>(
                value: SortMode.name,
                child: Text("Nomi bo'yicha"),
              ),
              PopupMenuItem<SortMode>(
                value: SortMode.size,
                child: Text("Hajmi bo'yicha"),
              ),
            ],
            child: const Glass(
              radius: 24,
              child: SizedBox(
                width: 46,
                height: 46,
                child: Icon(Icons.sort_rounded, size: 22),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _kindFilterChip() {
    final kind = _kindFilter;
    if (kind == null) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 6),
      child: Align(
        alignment: Alignment.centerLeft,
        child: InputChip(
          avatar: Icon(_iconFor(kind), size: 18, color: AppTheme.kindColor(kind)),
          label: Text(_kindLabel(kind)),
          onDeleted: () => setState(() => _kindFilter = null),
        ),
      ),
    );
  }

  Widget _libraryBody(List<LibraryItem> visible) {
    final title = _tab == 2 ? 'Sevimlilar' : 'Kutubxona';
    final Widget content;

    if (_items.isEmpty) {
      content = _emptyState(
        "Hali fayl yo'q",
        "PDF, Word (.docx), Excel (.xlsx), PowerPoint (.pptx), ePub, TXT, HTML "
            "va ZIP, TAR, GZ arxivlarini reklamasiz o'qing.\n\n"
            "RAR, 7z, eski .doc, .xls va .ppt fayllar tashqi ilovada ochiladi.",
        Icons.folder_open_rounded,
      );
    } else if (visible.isEmpty) {
      content = _emptyState(
        'Hech narsa topilmadi',
        _favOnly
            ? "Sevimli fayllar yo'q yoki qidiruvga mos kelmadi."
            : "Qidiruvga yoki papkaga mos fayl yo'q.",
        Icons.search_off,
      );
    } else {
      content = _fileList(visible);
    }

    return Column(
      children: [
        if (!_searching && !_selecting) _listHeader(title),
        if (_tab == 1 && _items.isNotEmpty) _folderBar(),
        _kindFilterChip(),
        Expanded(child: content),
      ],
    );
  }

  Widget _itemMenu(LibraryItem item) {
    return PopupMenuButton<String>(
      onSelected: (value) => _onItemMenu(value, item),
      itemBuilder: (_) => const <PopupMenuEntry<String>>[
        PopupMenuItem<String>(
          value: 'rename',
          child: Text("Nomini o'zgartirish"),
        ),
        PopupMenuItem<String>(
          value: 'folder',
          child: Text("Papkaga ko'chirish"),
        ),
        PopupMenuItem<String>(value: 'share', child: Text('Ulashish')),
        PopupMenuItem<String>(value: 'info', child: Text("Ma'lumot")),
        PopupMenuItem<String>(value: 'delete', child: Text("O'chirish")),
      ],
    );
  }

  Widget _gridCard(LibraryItem item) {
    final colors = Theme.of(context).colorScheme;
    final kind = kindOf(item.file.path);
    final fav = _data.isFavorite(item.key);
    final progress = _data.progress(item.key);
    final selected = _selected.contains(item.key);

    return Glass(
      radius: 22,
      tint: selected ? colors.primaryContainer.withAlpha(200) : null,
      borderColor: selected ? colors.primary : null,
      padding: const EdgeInsets.fromLTRB(12, 12, 4, 10),
      onTap: _selecting
          ? () => _toggleSelect(item)
          : () => _openItem(item.file.path),
      onLongPress: () => _toggleSelect(item),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              KindBadge(
                kind: kind,
                icon: _iconFor(kind),
                selected: selected,
                size: 46,
              ),
              const Spacer(),
              if (!_selecting) ...[
                IconButton(
                  visualDensity: VisualDensity.compact,
                  tooltip: fav
                      ? t('Sevimlilardan olib tashlash')
                      : t("Sevimlilarga qo'shish"),
                  icon: Icon(
                    fav ? Icons.star_rounded : Icons.star_border_rounded,
                    size: 22,
                    color: fav ? Colors.amber : colors.outline,
                  ),
                  onPressed: () => _toggleFavorite(item),
                ),
                _itemMenu(item),
              ],
            ],
          ),
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: Text(
              item.name,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                height: 1.25,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            formatSize(item.size),
            style: TextStyle(fontSize: 12, color: colors.onSurfaceVariant),
          ),
          if (progress > 0.005)
            Padding(
              padding: const EdgeInsets.only(top: 8, right: 8),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: progress,
                  minHeight: 4,
                  color: AppTheme.kindColor(kind),
                  backgroundColor: AppTheme.kindColor(kind).withAlpha(36),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _fileCard(LibraryItem item) {
    final colors = Theme.of(context).colorScheme;
    final kind = kindOf(item.file.path);
    final fav = _data.isFavorite(item.key);
    final progress = _data.progress(item.key);
    final selected = _selected.contains(item.key);

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Glass(
        radius: 22,
        tint: selected ? colors.primaryContainer.withAlpha(200) : null,
        borderColor: selected ? colors.primary : null,
        padding: const EdgeInsets.fromLTRB(12, 12, 4, 12),
        onTap: _selecting
            ? () => _toggleSelect(item)
            : () => _openItem(item.file.path),
        onLongPress: () => _toggleSelect(item),
        child: Row(
          children: [
            KindBadge(kind: kind, icon: _iconFor(kind), selected: selected),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      height: 1.25,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${formatSize(item.size)} • ${formatDate(item.modified)}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12.5,
                      color: colors.onSurfaceVariant,
                    ),
                  ),
                  if (progress > 0.005)
                    Padding(
                      padding: const EdgeInsets.only(top: 8, right: 12),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: LinearProgressIndicator(
                          value: progress,
                          minHeight: 4,
                          backgroundColor:
                              AppTheme.kindColor(kind).withAlpha(36),
                          color: AppTheme.kindColor(kind),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            if (!_selecting)
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    tooltip: fav
                        ? t('Sevimlilardan olib tashlash')
                        : t("Sevimlilarga qo'shish"),
                    icon: Icon(
                      fav ? Icons.star_rounded : Icons.star_border_rounded,
                      color: fav ? Colors.amber : colors.outline,
                    ),
                    onPressed: () => _toggleFavorite(item),
                  ),
                  _itemMenu(item),
                ],
              )
            else
              const SizedBox(width: 12),
          ],
        ),
      ),
    );
  }

  static const Map<int, GlassNavItem> _navItems = <int, GlassNavItem>{
    0: GlassNavItem(Icons.home_outlined, Icons.home_rounded, 'Asosiy'),
    1: GlassNavItem(Icons.folder_outlined, Icons.folder_rounded, 'Kutubxona'),
    2: GlassNavItem(
      Icons.star_border_rounded,
      Icons.star_rounded,
      'Sevimlilar',
    ),
    3: GlassNavItem(Icons.tune_rounded, Icons.tune_rounded, 'Sozlamalar'),
  };

  Widget _fileList(List<LibraryItem> visible) {
    if (_settings.gridView) {
      return GridView.builder(
        padding: const EdgeInsets.fromLTRB(16, 6, 16, 130),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 220,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          mainAxisExtent: 176,
        ),
        itemCount: visible.length,
        itemBuilder: (context, i) => _gridCard(visible[i]),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 130),
      itemCount: visible.length,
      itemBuilder: (context, i) => _fileCard(visible[i]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final visible = _visible;

    final Widget body;
    if (_tab == 3) {
      body = const SettingsScreen();
    } else if (_loading) {
      body = const Center(child: CircularProgressIndicator());
    } else if (_tab == 0) {
      body = _dashboard();
    } else {
      body = _libraryBody(visible);
    }

    final navIds = <int>[0, 1, if (_settings.navFavorites) 2, 3];
    final useAppBar = _selecting || (_searching && (_tab == 1 || _tab == 2));

    return PopScope(
      canPop: !_selecting && !_searching && _tab == 0,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        setState(() {
          if (_selecting) {
            _selected.clear();
          } else if (_searching) {
            _searchController.clear();
            _searching = false;
            _query = '';
          } else {
            _tab = 0;
            _kindFilter = null;
          }
        });
      },
      child: GradientBackground(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          extendBody: true,
          appBar: useAppBar ? _buildAppBar() : null,
          body: SafeArea(
            bottom: false,
            child: ContentWidth(child: body),
          ),
          bottomNavigationBar: GlassNavBar(
            index: navIds.indexOf(_tab).clamp(0, navIds.length - 1).toInt(),
            onTap: (i) => _setTab(navIds[i]),
            items: [for (final id in navIds) _navItems[id]!],
          ),
          floatingActionButton: (_tab == 1 || _tab == 2) && !_selecting
              ? FloatingActionButton.extended(
                  onPressed: _busy ? null : _pickFile,
                  icon: _busy
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.add_rounded),
                  label: const Text("Fayl qo'shish"),
                )
              : null,
        ),
      ),
    );
  }

  IconData _iconFor(DocKind kind) => switch (kind) {
        DocKind.pdf => Icons.picture_as_pdf_outlined,
        DocKind.text => Icons.article_outlined,
        DocKind.html => Icons.language,
        DocKind.docx => Icons.description_outlined,
        DocKind.xlsx => Icons.table_chart_outlined,
        DocKind.pptx => Icons.slideshow_outlined,
        DocKind.epub => Icons.menu_book_outlined,
        DocKind.archive => Icons.archive_outlined,
        DocKind.external => Icons.insert_drive_file_outlined,
      };

  String _kindLabel(DocKind kind) => switch (kind) {
        DocKind.pdf => 'PDF',
        DocKind.text => 'Matn',
        DocKind.html => 'HTML',
        DocKind.docx => 'Word',
        DocKind.xlsx => 'Excel',
        DocKind.pptx => 'PowerPoint',
        DocKind.epub => 'ePub',
        DocKind.archive => 'Arxiv',
        DocKind.external => 'Boshqa',
      };
}
