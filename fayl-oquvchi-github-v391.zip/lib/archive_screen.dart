import 'package:flutter/material.dart' hide Text;
import 'package:open_filex/open_filex.dart';

import 'archive_reader.dart';
import 'dialogs.dart';
import 'document_parser.dart';
import 'l10n.dart';
import 'library.dart';
import 'opener.dart';
import 'theme.dart';

class ArchiveScreen extends StatefulWidget {
  final String path;
  const ArchiveScreen({super.key, required this.path});

  @override
  State<ArchiveScreen> createState() => _ArchiveScreenState();
}

class _ArchiveScreenState extends State<ArchiveScreen> {
  late final ArchiveFormat _format;
  late final bool _supported;
  Future<List<ArchiveEntry>>? _future;
  List<ArchiveEntry> _entries = const <ArchiveEntry>[];
  String? _password;
  bool _working = false;
  bool _searching = false;
  String _filter = '';

  @override
  void initState() {
    super.initState();
    _format = archiveFormatOf(widget.path)!;
    _supported = isInAppArchive(_format);
    if (_supported) _loadList();
  }

  void _loadList() {
    _entries = const <ArchiveEntry>[];
    _future = ArchiveReader.list(
      widget.path,
      _format,
      password: _password,
    ).then((list) {
      if (mounted) setState(() => _entries = list);
      return list;
    });
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _askPassword() async {
    final value = await promptText(
      context,
      title: 'Arxiv paroli',
      label: 'Parol',
      obscure: true,
      initial: _password ?? '',
      confirm: "Qo'llash",
    );
    if (value == null || !mounted) return;

    setState(() {
      _password = value.isEmpty ? null : value;
      _loadList();
    });
  }

  Future<void> _handle(ArchiveEntry entry, {required bool save}) async {
    setState(() => _working = true);
    try {
      final file = await ArchiveReader.extractEntry(
        widget.path,
        _format,
        entry,
        password: _password,
      );
      if (!mounted) return;

      if (save) {
        await Library.importFile(file.path);
        _snack('Kutubxonaga saqlandi: ${entry.baseName}');
      } else {
        await openDocument(context, file.path);
      }
    } catch (e) {
      _snack('Xatolik: ${errorText(e)}');
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  Future<void> _saveAll() async {
    final entries = _entries;
    if (entries.isEmpty || _working) return;

    final ok = await confirmDialog(
      context,
      title: 'Hamma fayllarni kutubxonaga saqlaysizmi?',
      message: 'Fayllar soni: ${entries.length}',
      confirm: 'Saqlash',
    );
    if (!ok || !mounted) return;

    setState(() => _working = true);
    try {
      final files = await ArchiveReader.extractAll(
        widget.path,
        _format,
        entries,
        password: _password,
      );

      var saved = 0;
      for (final file in files) {
        try {
          await Library.importFile(file.path);
          saved++;
        } catch (_) {
          // Bitta faylni saqlab bo'lmasa, qolganlari davom ettiriladi
        }
      }
      _snack('Kutubxonaga saqlandi: $saved');
    } catch (e) {
      _snack('Xatolik: ${errorText(e)}');
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  PreferredSizeWidget _buildAppBar() {
    if (_searching) {
      return AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => setState(() {
            _searching = false;
            _filter = '';
          }),
        ),
        title: TextField(
          autofocus: true,
          decoration: InputDecoration(
            hintText: t("Arxiv ichidan qidirish..."),
            border: InputBorder.none,
          ),
          onChanged: (value) => setState(() => _filter = value),
        ),
      );
    }

    return AppBar(
      title: Text(
        Library.displayName(widget.path),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      actions: [
        if (_supported) ...[
          IconButton(
            tooltip: t('Qidirish'),
            icon: const Icon(Icons.search),
            onPressed: _entries.isEmpty
                ? null
                : () => setState(() => _searching = true),
          ),
          IconButton(
            tooltip: t('Hammasini kutubxonaga saqlash'),
            icon: const Icon(Icons.download_for_offline_outlined),
            onPressed: _entries.isEmpty || _working ? null : _saveAll,
          ),
        ],
        if (_format == ArchiveFormat.zip)
          IconButton(
            tooltip: t('Parol kiritish'),
            icon: Icon(_password == null ? Icons.lock_outline : Icons.lock_open),
            onPressed: _askPassword,
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return GradientBackground(
      child: Scaffold(
      backgroundColor: Colors.transparent,
      appBar: _buildAppBar(),
      body: ContentWidth(
        child: _supported ? _buildList() : _buildUnsupported(),
      ),
      ),
    );
  }

  Widget _buildUnsupported() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.archive_outlined, size: 80),
            const SizedBox(height: 16),
            const Text(
              "RAR va 7z arxivlarini ilova ichida ochib bo'lmaydi. "
              "Ularni tashqi arxivator ilovasida (masalan, RAR yoki 7-Zip) oching.",
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: () => OpenFilex.open(widget.path),
              icon: const Icon(Icons.open_in_new),
              label: const Text('Tashqi ilovada ochish'),
            ),
          ],
        ),
      ),
    );
  }

  IconData _iconFor(String name) {
    switch (kindOf(name)) {
      case DocKind.pdf:
        return Icons.picture_as_pdf_outlined;
      case DocKind.text:
        return Icons.article_outlined;
      case DocKind.html:
        return Icons.language;
      case DocKind.docx:
        return Icons.description_outlined;
      case DocKind.xlsx:
        return Icons.table_chart_outlined;
      case DocKind.pptx:
        return Icons.slideshow_outlined;
      case DocKind.epub:
        return Icons.menu_book_outlined;
      case DocKind.archive:
        return Icons.archive_outlined;
      case DocKind.external:
        return Icons.insert_drive_file_outlined;
    }
  }

  Widget _buildList() {
    return Stack(
      children: [
        FutureBuilder<List<ArchiveEntry>>(
          future: _future,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }

            if (snap.hasError) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(
                    "Arxivni ochib bo'lmadi.\n\n${errorText(snap.error!)}",
                    textAlign: TextAlign.center,
                  ),
                ),
              );
            }

            final all = snap.data ?? const <ArchiveEntry>[];
            if (all.isEmpty) {
              return const Center(child: Text("Arxiv bo'sh"));
            }

            final q = _filter.trim().toLowerCase();
            final entries = q.isEmpty
                ? all
                : all.where((e) => e.name.toLowerCase().contains(q)).toList();

            if (entries.isEmpty) {
              return const Center(child: Text('Hech narsa topilmadi'));
            }

            return ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              itemCount: entries.length,
              itemBuilder: (context, i) {
                final entry = entries[i];
                final scheme = Theme.of(context).colorScheme;
                return Card(
                  elevation: 0,
                  color: scheme.surfaceContainerLow,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18),
                    side: BorderSide(color: scheme.outlineVariant.withAlpha(140)),
                  ),
                  child: ListTile(
                    leading: KindBadge(
                      kind: kindOf(entry.baseName),
                      icon: _iconFor(entry.baseName),
                      size: 44,
                    ),
                    title: Text(
                      entry.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    subtitle: Text(formatSize(entry.size)),
                    trailing: IconButton(
                      tooltip: t('Kutubxonaga saqlash'),
                      icon: const Icon(Icons.save_alt),
                      onPressed: _working
                          ? null
                          : () => _handle(entry, save: true),
                    ),
                    onTap: _working ? null : () => _handle(entry, save: false),
                  ),
                );
              },
            );
          },
        ),
        if (_working)
          const Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: LinearProgressIndicator(),
          ),
      ],
    );
  }
}
