import 'dart:convert';
import 'dart:io';
import 'dart:isolate';
import 'dart:math' as math;

import 'package:archive/archive.dart';
import 'package:path/path.dart' as p;
import 'package:xml/xml.dart';

import 'document_parser.dart';

/// Katak kaliti: satr * kColStride + ustun.
const int kColStride = 16384;

int cellKey(int row, int col) => row * kColStride + col;

String columnName(int col) {
  var n = col + 1;
  final sb = <int>[];
  while (n > 0) {
    final r = (n - 1) % 26;
    sb.add(65 + r);
    n = (n - 1) ~/ 26;
  }
  return String.fromCharCodes(sb.reversed);
}

String cellAddress(int row, int col) => '${columnName(col)}${row + 1}';

class XFont {
  final bool bold;
  final bool italic;
  final bool underline;
  final bool strike;
  final int? color;
  final double size;
  const XFont({
    this.bold = false,
    this.italic = false,
    this.underline = false,
    this.strike = false,
    this.color,
    this.size = 11,
  });
}

class XSide {
  final int color;
  final double width;
  const XSide(this.color, this.width);
}

class XStyle {
  final XFont font;
  final int? fill;
  final XSide? left;
  final XSide? right;
  final XSide? top;
  final XSide? bottom;
  final String hAlign;
  final String vAlign;
  final bool wrap;
  final int indent;
  final String numFmt;
  const XStyle({
    this.font = const XFont(),
    this.fill,
    this.left,
    this.right,
    this.top,
    this.bottom,
    this.hAlign = 'general',
    this.vAlign = 'bottom',
    this.wrap = false,
    this.indent = 0,
    this.numFmt = 'General',
  });
}

/// kind: 0 - matn, 1 - son/sana, 2 - mantiqiy yoki xato qiymati.
class XCell {
  final String text;
  final String? formula;
  final int style;
  final int kind;
  const XCell(this.text, this.style, this.kind, [this.formula]);
}

class XMerge {
  final int r1;
  final int c1;
  final int r2;
  final int c2;
  const XMerge(this.r1, this.c1, this.r2, this.c2);
}

class XSheet {
  final String name;
  final int? tabColor;
  final Map<int, XCell> cells;
  final int rows;
  final int cols;
  final Map<int, double> colWidths;
  final Set<int> hiddenCols;
  final Map<int, double> rowHeights;
  final Set<int> hiddenRows;
  final double defaultColWidth;
  final double defaultRowHeight;
  final List<XMerge> merges;
  final int freezeRows;
  final int freezeCols;
  final bool showGrid;
  const XSheet({
    required this.name,
    required this.tabColor,
    required this.cells,
    required this.rows,
    required this.cols,
    required this.colWidths,
    required this.hiddenCols,
    required this.rowHeights,
    required this.hiddenRows,
    required this.defaultColWidth,
    required this.defaultRowHeight,
    required this.merges,
    required this.freezeRows,
    required this.freezeCols,
    required this.showGrid,
  });
}

class XWorkbook {
  final List<XSheet> sheets;
  final List<XStyle> styles;
  final List<String> media;
  const XWorkbook(this.sheets, this.styles, this.media);
}

Future<XWorkbook> loadWorkbook(String path, {String? mediaDir}) =>
    Isolate.run(() => parseWorkbook(path, mediaDir));

// =====================================================================
// Ranglar
// =====================================================================

const _defaultTheme = <int>[
  0xFFFFFFFF, // lt1
  0xFF000000, // dk1
  0xFFE7E6E6, // lt2
  0xFF44546A, // dk2
  0xFF4472C4,
  0xFFED7D31,
  0xFFA5A5A5,
  0xFFFFC000,
  0xFF5B9BD5,
  0xFF70AD47,
  0xFF0563C1,
  0xFF954F72,
];

const _indexedColors = <int>[
  0xFF000000, 0xFFFFFFFF, 0xFFFF0000, 0xFF00FF00, 0xFF0000FF, 0xFFFFFF00,
  0xFFFF00FF, 0xFF00FFFF, 0xFF000000, 0xFFFFFFFF, 0xFFFF0000, 0xFF00FF00,
  0xFF0000FF, 0xFFFFFF00, 0xFFFF00FF, 0xFF00FFFF, 0xFF800000, 0xFF008000,
  0xFF000080, 0xFF808000, 0xFF800080, 0xFF008080, 0xFFC0C0C0, 0xFF808080,
  0xFF9999FF, 0xFF993366, 0xFFFFFFCC, 0xFFCCFFFF, 0xFF660066, 0xFFFF8080,
  0xFF0066CC, 0xFFCCCCFF, 0xFF000080, 0xFFFF00FF, 0xFFFFFF00, 0xFF00FFFF,
  0xFF800080, 0xFF800000, 0xFF008080, 0xFF0000FF, 0xFF00CCFF, 0xFFCCFFFF,
  0xFFCCFFCC, 0xFFFFFF99, 0xFF99CCFF, 0xFFFF99CC, 0xFFCC99FF, 0xFFFFCC99,
  0xFF3366FF, 0xFF33CCCC, 0xFF99CC00, 0xFFFFCC00, 0xFFFF9900, 0xFFFF6600,
  0xFF666699, 0xFF969696, 0xFF003366, 0xFF339966, 0xFF003300, 0xFF333300,
  0xFF993300, 0xFF993366, 0xFF333399, 0xFF333333,
];

List<double> _rgbToHsl(int c) {
  final r = ((c >> 16) & 0xFF) / 255;
  final g = ((c >> 8) & 0xFF) / 255;
  final b = (c & 0xFF) / 255;
  final mx = math.max(r, math.max(g, b));
  final mn = math.min(r, math.min(g, b));
  final l = (mx + mn) / 2;
  var h = 0.0;
  var s = 0.0;
  if (mx != mn) {
    final d = mx - mn;
    s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
    if (mx == r) {
      h = (g - b) / d + (g < b ? 6 : 0);
    } else if (mx == g) {
      h = (b - r) / d + 2;
    } else {
      h = (r - g) / d + 4;
    }
    h /= 6;
  }
  return [h, s, l];
}

double _hue(double p0, double q, double t0) {
  var t = t0;
  if (t < 0) t += 1;
  if (t > 1) t -= 1;
  if (t < 1 / 6) return p0 + (q - p0) * 6 * t;
  if (t < 1 / 2) return q;
  if (t < 2 / 3) return p0 + (q - p0) * (2 / 3 - t) * 6;
  return p0;
}

int _hslToRgb(double h, double s, double l) {
  double r;
  double g;
  double b;
  if (s == 0) {
    r = g = b = l;
  } else {
    final q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    final pp = 2 * l - q;
    r = _hue(pp, q, h + 1 / 3);
    g = _hue(pp, q, h);
    b = _hue(pp, q, h - 1 / 3);
  }
  int to(double v) => (v * 255).round().clamp(0, 255);
  return 0xFF000000 | (to(r) << 16) | (to(g) << 8) | to(b);
}

int _applyTint(int color, double tint) {
  if (tint == 0) return color;
  final hsl = _rgbToHsl(color);
  var l = hsl[2];
  if (tint < 0) {
    l = l * (1 + tint);
  } else {
    l = l * (1 - tint) + tint;
  }
  return _hslToRgb(hsl[0], hsl[1], l.clamp(0.0, 1.0));
}

// =====================================================================
// Uslublar
// =====================================================================

class _Styles {
  final List<XStyle> xfs = <XStyle>[];
  final List<int> theme = List<int>.of(_defaultTheme);
  bool date1904 = false;
}

int? _color(XmlElement? e, List<int> theme) {
  if (e == null) return null;
  final rgb = e.getAttribute('rgb');
  int? base;
  if (rgb != null) {
    final v = int.tryParse(rgb, radix: 16);
    if (v != null) base = 0xFF000000 | (v & 0xFFFFFF);
  } else {
    final th = int.tryParse(e.getAttribute('theme') ?? '');
    final ix = int.tryParse(e.getAttribute('indexed') ?? '');
    if (th != null && th >= 0 && th < theme.length) {
      base = theme[th];
    } else if (ix != null && ix >= 0 && ix < _indexedColors.length) {
      base = _indexedColors[ix];
    }
  }
  if (base == null) return null;
  final tint = double.tryParse(e.getAttribute('tint') ?? '') ?? 0;
  return _applyTint(base, tint);
}

bool _flag(XmlElement? e) {
  if (e == null) return false;
  final v = e.getAttribute('val');
  return v == null || (v != '0' && v != 'false');
}

XmlElement? _first(XmlElement parent, String name) {
  final it = parent.findElements(name);
  return it.isEmpty ? null : it.first;
}

XSide? _side(XmlElement? e, List<int> theme) {
  if (e == null) return null;
  final style = e.getAttribute('style');
  if (style == null || style == 'none') return null;
  var width = 1.0;
  switch (style) {
    case 'hair':
      width = 0.5;
      break;
    case 'medium':
    case 'mediumDashed':
    case 'mediumDashDot':
    case 'mediumDashDotDot':
    case 'slantDashDot':
    case 'double':
      width = 2;
      break;
    case 'thick':
      width = 3;
      break;
  }
  final color = _color(_first(e, 'color'), theme) ?? 0xFF000000;
  return XSide(color, width);
}

_Styles _readStyles(Archive archive) {
  final result = _Styles();

  final themeXml = zipText(archive, 'xl/theme/theme1.xml');
  if (themeXml != null) {
    try {
      final doc = parseOfficeXml(themeXml);
      final scheme = doc.findAllElements('clrScheme');
      if (scheme.isNotEmpty) {
        const order = [
          'lt1', 'dk1', 'lt2', 'dk2', 'accent1', 'accent2', 'accent3',
          'accent4', 'accent5', 'accent6', 'hlink', 'folHlink',
        ];
        for (var i = 0; i < order.length; i++) {
          final el = _first(scheme.first, order[i]);
          if (el == null) continue;
          for (final child in el.childElements) {
            final v = child.getAttribute('val') ?? child.getAttribute('lastClr');
            final n = v == null ? null : int.tryParse(v, radix: 16);
            if (n != null && v!.length == 6) {
              result.theme[i] = 0xFF000000 | n;
            } else if (child.getAttribute('lastClr') != null) {
              final l = int.tryParse(child.getAttribute('lastClr')!, radix: 16);
              if (l != null) result.theme[i] = 0xFF000000 | l;
            }
          }
        }
      }
    } catch (_) {}
  }

  final wb = zipText(archive, 'xl/workbook.xml');
  if (wb != null) {
    try {
      final pr = parseOfficeXml(wb).findAllElements('workbookPr');
      if (pr.isNotEmpty) {
        final v = pr.first.getAttribute('date1904');
        result.date1904 = v == '1' || v == 'true';
      }
    } catch (_) {}
  }

  final xml = zipText(archive, 'xl/styles.xml');
  if (xml == null) {
    result.xfs.add(const XStyle());
    return result;
  }

  try {
    final doc = parseOfficeXml(xml);
    final theme = result.theme;

    final numFmts = <int, String>{};
    for (final nf in doc.findAllElements('numFmt')) {
      final id = int.tryParse(nf.getAttribute('numFmtId') ?? '');
      final code = nf.getAttribute('formatCode');
      if (id != null && code != null) numFmts[id] = code;
    }

    final fonts = <XFont>[];
    for (final root in doc.findAllElements('fonts')) {
      for (final f in root.findElements('font')) {
        final sz = double.tryParse(_first(f, 'sz')?.getAttribute('val') ?? '');
        final u = _first(f, 'u');
        fonts.add(
          XFont(
            bold: _flag(_first(f, 'b')),
            italic: _flag(_first(f, 'i')),
            underline: u != null && u.getAttribute('val') != 'none',
            strike: _flag(_first(f, 'strike')),
            color: _color(_first(f, 'color'), theme),
            size: sz ?? 11,
          ),
        );
      }
      break;
    }

    final fills = <int?>[];
    for (final root in doc.findAllElements('fills')) {
      for (final f in root.findElements('fill')) {
        final pat = _first(f, 'patternFill');
        int? color;
        if (pat != null) {
          final type = pat.getAttribute('patternType');
          if (type != null && type != 'none') {
            color = _color(_first(pat, 'fgColor'), theme);
            if (type == 'gray125' || type == 'gray0625') color = null;
          }
        } else {
          final grad = _first(f, 'gradientFill');
          if (grad != null) {
            final stop = grad.findAllElements('color');
            if (stop.isNotEmpty) color = _color(stop.first, theme);
          }
        }
        fills.add(color);
      }
      break;
    }

    final borders = <List<XSide?>>[];
    for (final root in doc.findAllElements('borders')) {
      for (final b in root.findElements('border')) {
        borders.add([
          _side(_first(b, 'left') ?? _first(b, 'start'), theme),
          _side(_first(b, 'right') ?? _first(b, 'end'), theme),
          _side(_first(b, 'top'), theme),
          _side(_first(b, 'bottom'), theme),
        ]);
      }
      break;
    }

    for (final root in doc.findAllElements('cellXfs')) {
      for (final xf in root.findElements('xf')) {
        final nid = int.tryParse(xf.getAttribute('numFmtId') ?? '') ?? 0;
        final fid = int.tryParse(xf.getAttribute('fontId') ?? '') ?? 0;
        final fl = int.tryParse(xf.getAttribute('fillId') ?? '') ?? 0;
        final bid = int.tryParse(xf.getAttribute('borderId') ?? '') ?? 0;
        final al = _first(xf, 'alignment');
        final b = (bid >= 0 && bid < borders.length)
            ? borders[bid]
            : const <XSide?>[null, null, null, null];
        result.xfs.add(
          XStyle(
            font: (fid >= 0 && fid < fonts.length) ? fonts[fid] : const XFont(),
            fill: (fl >= 0 && fl < fills.length) ? fills[fl] : null,
            left: b[0],
            right: b[1],
            top: b[2],
            bottom: b[3],
            hAlign: al?.getAttribute('horizontal') ?? 'general',
            vAlign: al?.getAttribute('vertical') ?? 'bottom',
            wrap: al?.getAttribute('wrapText') == '1' ||
                al?.getAttribute('wrapText') == 'true',
            indent: int.tryParse(al?.getAttribute('indent') ?? '') ?? 0,
            numFmt: numFmts[nid] ?? builtinNumberFormat(nid),
          ),
        );
      }
      break;
    }
  } catch (_) {
    // Uslublar o'qilmasa, katakchalar oddiy ko'rinishda chiqadi
  }

  if (result.xfs.isEmpty) result.xfs.add(const XStyle());
  return result;
}

// =====================================================================
// Ish kitobini o'qish
// =====================================================================

XWorkbook parseWorkbook(String path, String? mediaDir) {
  final bytes = File(path).readAsBytesSync();
  final archive = openZip(bytes);
  final styles = _readStyles(archive);
  final media = MediaSink(mediaDir);

  final shared = <String>[];
  final sst = zipText(archive, 'xl/sharedStrings.xml');
  if (sst != null) {
    for (final si in parseOfficeXml(sst).findAllElements('si')) {
      final sb = StringBuffer();
      for (final child in si.childElements) {
        if (child.name.local == 't') {
          sb.write(child.innerText);
        } else if (child.name.local == 'r') {
          for (final t in child.findElements('t')) {
            sb.write(t.innerText);
          }
        }
      }
      shared.add(sb.toString());
    }
  }

  final names = <String>[];
  final files = <ArchiveFile>[];
  final workbook = zipText(archive, 'xl/workbook.xml');
  final rels = zipText(archive, 'xl/_rels/workbook.xml.rels');
  if (workbook != null && rels != null) {
    final targets = <String, String>{};
    for (final r in parseOfficeXml(rels).findAllElements('Relationship')) {
      final id = r.getAttribute('Id');
      final target = r.getAttribute('Target');
      if (id != null && target != null) targets[id] = target;
    }
    for (final s in parseOfficeXml(workbook).findAllElements('sheet')) {
      final target = targets[s.getAttribute('r:id') ?? ''];
      if (target == null) continue;
      final entry = target.startsWith('/')
          ? target.substring(1)
          : p.posix.normalize(p.posix.join('xl', target));
      final file = archive.findFile(entry);
      if (file == null) continue;
      files.add(file);
      names.add(s.getAttribute('name') ?? '');
    }
  }
  if (files.isEmpty) {
    final list = archive.files
        .where((f) => RegExp(r'^xl/worksheets/sheet\d+\.xml$').hasMatch(f.name))
        .toList();
    list.sort((a, b) => _num(a.name).compareTo(_num(b.name)));
    files.addAll(list);
  }
  if (files.isEmpty) {
    throw const FormatException('Jadval varaqlari topilmadi');
  }

  final sheets = <XSheet>[];
  for (var i = 0; i < files.length; i++) {
    final name = i < names.length && names[i].isNotEmpty
        ? names[i]
        : 'Sheet${i + 1}';
    sheets.add(_parseSheet(name, files[i], shared, styles));
  }

  final pictures = <String>[];
  for (final f in archive.files) {
    if (!f.isFile || !f.name.startsWith('xl/media/')) continue;
    final line = media.line(archive, f.name);
    if (line == null) continue;
    final cut = line.indexOf(mediaSep);
    if (cut > 0 && line.substring(1, cut) == 'IMG') {
      pictures.add(line.substring(cut + 1));
    }
  }

  return XWorkbook(sheets, styles.xfs, pictures);
}

int _num(String name) {
  final m = RegExp(r'(\d+)\.xml$').firstMatch(name);
  return m == null ? 0 : int.parse(m.group(1)!);
}

int _colOf(String ref) {
  var n = 0;
  for (final ch in ref.codeUnits) {
    if (ch < 65 || ch > 90) break;
    n = n * 26 + (ch - 64);
  }
  return n - 1;
}

int _rowOf(String ref) {
  final m = RegExp(r'(\d+)$').firstMatch(ref);
  return m == null ? -1 : int.parse(m.group(1)!) - 1;
}

String _childValue(XmlElement c, String name) {
  final it = c.findElements(name);
  return it.isEmpty ? '' : it.first.innerText;
}

XSheet _parseSheet(
  String name,
  ArchiveFile file,
  List<String> shared,
  _Styles styles,
) {
  final xml = parseOfficeXml(
    utf8.decode(file.content as List<int>, allowMalformed: true),
  );

  var defaultCol = 64.0;
  var defaultRow = 20.0;
  final fmt = xml.findAllElements('sheetFormatPr');
  if (fmt.isNotEmpty) {
    final dc = double.tryParse(fmt.first.getAttribute('defaultColWidth') ?? '');
    if (dc != null && dc > 0) defaultCol = (dc * 7).roundToDouble();
    final dr = double.tryParse(fmt.first.getAttribute('defaultRowHeight') ?? '');
    if (dr != null && dr > 0) defaultRow = dr * 96 / 72;
  }

  int? tab;
  final tabEl = xml.findAllElements('tabColor');
  if (tabEl.isNotEmpty) tab = _color(tabEl.first, styles.theme);

  var showGrid = true;
  var freezeRows = 0;
  var freezeCols = 0;
  final views = xml.findAllElements('sheetView');
  if (views.isNotEmpty) {
    final v = views.first.getAttribute('showGridLines');
    if (v == '0' || v == 'false') showGrid = false;
    final pane = _first(views.first, 'pane');
    if (pane != null) {
      final state = pane.getAttribute('state');
      if (state == 'frozen' || state == 'frozenSplit') {
        freezeCols = int.tryParse(pane.getAttribute('xSplit') ?? '') ?? 0;
        freezeRows = int.tryParse(pane.getAttribute('ySplit') ?? '') ?? 0;
      }
    }
  }

  final colRanges = <List<Object>>[];
  for (final root in xml.findAllElements('cols')) {
    for (final c in root.findElements('col')) {
      final min = int.tryParse(c.getAttribute('min') ?? '');
      final max = int.tryParse(c.getAttribute('max') ?? '');
      final w = double.tryParse(c.getAttribute('width') ?? '');
      final hidden = c.getAttribute('hidden') == '1' ||
          c.getAttribute('hidden') == 'true';
      if (min == null || max == null) continue;
      colRanges.add([min - 1, max - 1, w == null ? -1.0 : w * 7, hidden]);
    }
  }

  final cells = <int, XCell>{};
  final rowHeights = <int, double>{};
  final hiddenRows = <int>{};
  var maxRow = -1;
  var maxCol = -1;
  var rowCursor = -1;

  for (final row in xml.findAllElements('row')) {
    var r = int.tryParse(row.getAttribute('r') ?? '');
    r = r == null ? rowCursor + 1 : r - 1;
    rowCursor = r;

    final ht = double.tryParse(row.getAttribute('ht') ?? '');
    if (ht != null && ht >= 0) rowHeights[r] = ht * 96 / 72;
    final hid = row.getAttribute('hidden');
    if (hid == '1' || hid == 'true') hiddenRows.add(r);

    var colCursor = -1;
    for (final c in row.findElements('c')) {
      final ref = c.getAttribute('r') ?? '';
      var col = ref.isEmpty ? -1 : _colOf(ref);
      if (col < 0) col = colCursor + 1;
      colCursor = col;
      if (col >= kColStride) continue;

      final style = int.tryParse(c.getAttribute('s') ?? '') ?? 0;
      final cell = _cell(c, style, shared, styles);
      if (cell == null) continue;
      cells[cellKey(r, col)] = cell;
      if (r > maxRow) maxRow = r;
      if (col > maxCol) maxCol = col;
    }
  }

  final merges = <XMerge>[];
  for (final m in xml.findAllElements('mergeCell')) {
    final ref = m.getAttribute('ref');
    if (ref == null) continue;
    final parts = ref.split(':');
    if (parts.length != 2) continue;
    final c1 = _colOf(parts[0]);
    final r1 = _rowOf(parts[0]);
    final c2 = _colOf(parts[1]);
    final r2 = _rowOf(parts[1]);
    if (c1 < 0 || r1 < 0 || c2 < c1 || r2 < r1) continue;
    if (c2 >= kColStride) continue;
    merges.add(XMerge(r1, c1, r2, c2));
    if (r2 > maxRow) maxRow = r2;
    if (c2 > maxCol) maxCol = c2;
  }

  final rows = math.min(math.max(maxRow + 1 + 30, 60), 1048576);
  final cols = math.min(math.max(maxCol + 1 + 4, 15), kColStride);

  final colWidths = <int, double>{};
  final hiddenCols = <int>{};
  for (final range in colRanges) {
    final min = range[0] as int;
    final max = math.min(range[1] as int, cols - 1);
    final w = range[2] as double;
    final hidden = range[3] as bool;
    for (var c = math.max(min, 0); c <= max; c++) {
      if (w >= 0) colWidths[c] = w;
      if (hidden) hiddenCols.add(c);
    }
  }

  return XSheet(
    name: name,
    tabColor: tab,
    cells: cells,
    rows: rows,
    cols: cols,
    colWidths: colWidths,
    hiddenCols: hiddenCols,
    rowHeights: rowHeights,
    hiddenRows: hiddenRows,
    defaultColWidth: defaultCol,
    defaultRowHeight: defaultRow,
    merges: merges,
    freezeRows: math.min(freezeRows, rows),
    freezeCols: math.min(freezeCols, cols),
    showGrid: showGrid,
  );
}

XCell? _cell(XmlElement c, int style, List<String> shared, _Styles styles) {
  final type = c.getAttribute('t');
  final f = c.findElements('f');
  String? formula;
  if (f.isNotEmpty) {
    final text = f.first.innerText.trim();
    if (text.isNotEmpty) formula = '=$text';
  }

  String text;
  int kind = 0;
  switch (type) {
    case 's':
      final i = int.tryParse(_childValue(c, 'v'));
      text = (i != null && i >= 0 && i < shared.length) ? shared[i] : '';
      break;
    case 'str':
      text = _childValue(c, 'v');
      break;
    case 'inlineStr':
      text = c.findAllElements('t').map((t) => t.innerText).join();
      break;
    case 'b':
      text = _childValue(c, 'v') == '1' ? 'TRUE' : 'FALSE';
      kind = 2;
      break;
    case 'e':
      text = _childValue(c, 'v');
      kind = 2;
      break;
    case 'd':
      text = _childValue(c, 'v');
      break;
    default:
      final raw = _childValue(c, 'v');
      if (raw.isEmpty) {
        text = '';
      } else {
        final n = double.tryParse(raw);
        if (n == null) {
          text = raw;
        } else {
          final code = (style >= 0 && style < styles.xfs.length)
              ? styles.xfs[style].numFmt
              : 'General';
          text = formatNumber(n, code, is1904: styles.date1904);
          kind = 1;
        }
      }
      break;
  }

  if (text.isEmpty && style == 0 && formula == null) return null;
  return XCell(text, style, kind, formula);
}

// =====================================================================
// Raqam va sana formatlari
// =====================================================================

String builtinNumberFormat(int id) {
  switch (id) {
    case 1:
      return '0';
    case 2:
      return '0.00';
    case 3:
      return '#,##0';
    case 4:
      return '#,##0.00';
    case 9:
      return '0%';
    case 10:
      return '0.00%';
    case 11:
      return '0.00E+00';
    case 14:
      return 'dd.mm.yyyy';
    case 15:
      return 'd-mmm-yy';
    case 16:
      return 'd-mmm';
    case 17:
      return 'mmm-yy';
    case 18:
      return 'h:mm AM/PM';
    case 19:
      return 'h:mm:ss AM/PM';
    case 20:
      return 'h:mm';
    case 21:
      return 'h:mm:ss';
    case 22:
      return 'dd.mm.yyyy h:mm';
    case 37:
    case 38:
      return '#,##0;-#,##0';
    case 39:
    case 40:
      return '#,##0.00;-#,##0.00';
    case 41:
      return '#,##0';
    case 42:
      return '"\$"#,##0';
    case 43:
      return '#,##0.00';
    case 44:
      return '"\$"#,##0.00';
    case 45:
      return 'mm:ss';
    case 46:
      return '[h]:mm:ss';
    case 47:
      return 'mm:ss.0';
    case 48:
      return '##0.0E+0';
    case 49:
      return '@';
    default:
      return 'General';
  }
}

String _general(double v) {
  if (v == v.truncateToDouble() && v.abs() < 1e11) {
    return v.toInt().toString();
  }
  final a = v.abs();
  if (a >= 1e11 || (a < 1e-9 && v != 0)) {
    var s = v.toStringAsExponential(5);
    s = s.replaceFirst(RegExp(r'\.?0+e'), 'e');
    final m = RegExp(r'^(.*)e([+-]?)(\d+)$').firstMatch(s);
    if (m == null) return s;
    final exp = m[3]!.padLeft(2, '0');
    return '${m[1]}E${m[2] == '-' ? '-' : '+'}$exp';
  }
  var s = v.toStringAsPrecision(10);
  if (s.contains('e')) return v.toString();
  if (s.contains('.')) {
    s = s.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
  }
  return s;
}

List<String> _splitSections(String code) {
  final out = <String>[];
  final sb = StringBuffer();
  var quoted = false;
  for (var i = 0; i < code.length; i++) {
    final ch = code[i];
    if (ch == '"') quoted = !quoted;
    if (ch == '\\' && !quoted && i + 1 < code.length) {
      sb.write(ch);
      sb.write(code[++i]);
      continue;
    }
    if (ch == ';' && !quoted) {
      out.add(sb.toString());
      sb.clear();
      continue;
    }
    sb.write(ch);
  }
  out.add(sb.toString());
  return out;
}

class _Tok {
  final String ch;
  final bool lit;
  const _Tok(this.ch, this.lit);
}

List<_Tok> _tokens(String sec) {
  final out = <_Tok>[];
  var i = 0;
  while (i < sec.length) {
    final ch = sec[i];
    if (ch == '"') {
      final end = sec.indexOf('"', i + 1);
      final text = end < 0 ? sec.substring(i + 1) : sec.substring(i + 1, end);
      for (final c in text.split('')) {
        out.add(_Tok(c, true));
      }
      i = end < 0 ? sec.length : end + 1;
    } else if (ch == '\\') {
      if (i + 1 < sec.length) out.add(_Tok(sec[i + 1], true));
      i += 2;
    } else if (ch == '_' || ch == '*') {
      i += 2;
    } else {
      out.add(_Tok(ch, false));
      i++;
    }
  }
  return out;
}

String _cleanSection(String sec) {
  return sec
      .replaceAll(
        RegExp(
          r'\[(red|blue|green|black|white|cyan|magenta|yellow|color\s*\d+)\]',
          caseSensitive: false,
        ),
        '',
      )
      .replaceAllMapped(
        RegExp(r'\[\$([^\]\-]*)(-[^\]]*)?\]'),
        (m) => (m[1] ?? '').isEmpty ? '' : '"${m[1]}"',
      )
      .replaceAll(RegExp(r'\[[<>=][^\]]*\]'), '');
}

bool _isDateSection(String sec) {
  final tokens = _tokens(sec);
  final sb = StringBuffer();
  var inBracket = false;
  for (final t in tokens) {
    if (t.lit) continue;
    if (t.ch == '[') {
      inBracket = true;
      continue;
    }
    if (t.ch == ']') {
      inBracket = false;
      continue;
    }
    if (inBracket) {
      sb.write(t.ch);
      continue;
    }
    sb.write(t.ch);
  }
  final s = sb.toString().toLowerCase();
  if (s.contains('general')) return false;
  if (RegExp(r'e[+-]').hasMatch(s)) return false;
  return RegExp(r'[dmyhs]').hasMatch(s);
}

String formatNumber(double v, String code, {bool is1904 = false}) {
  if (v.isNaN || v.isInfinite) return v.toString();
  final c = code.trim();
  if (c.isEmpty || c.toLowerCase() == 'general') return _general(v);

  final sections = _splitSections(c);
  var sec = sections[0];
  var value = v;
  var negative = v < 0;
  if (sections.length >= 2 && v < 0) {
    sec = sections[1];
    value = -v;
    negative = false;
  } else if (sections.length >= 3 && v == 0) {
    sec = sections[2];
  }
  if (sec.trim().isEmpty && sections.length > 1) return '';
  sec = _cleanSection(sec);
  if (sec.trim().isEmpty) return '';

  if (_isDateSection(sec)) {
    return _formatDate(v, sec, is1904);
  }

  final tokens = _tokens(sec);
  if (tokens.any((t) => !t.lit && t.ch == '@')) {
    final sb = StringBuffer();
    for (final t in tokens) {
      sb.write(t.ch == '@' && !t.lit ? _general(v) : t.ch);
    }
    return sb.toString();
  }
  return _formatNumeric(value, negative, tokens);
}

bool _isPlaceholder(_Tok t) =>
    !t.lit && (t.ch == '0' || t.ch == '#' || t.ch == '?');

String _formatNumeric(double value, bool negative, List<_Tok> tokens) {
  var first = -1;
  var last = -1;
  for (var i = 0; i < tokens.length; i++) {
    if (_isPlaceholder(tokens[i])) {
      if (first < 0) first = i;
      last = i;
    }
  }

  if (first < 0) {
    return tokens.map((t) => t.ch).join();
  }

  // Ilmiy ko'rinish
  var sciAt = -1;
  for (var i = first; i < tokens.length - 1; i++) {
    if (!tokens[i].lit &&
        (tokens[i].ch == 'E' || tokens[i].ch == 'e') &&
        !tokens[i + 1].lit &&
        (tokens[i + 1].ch == '+' || tokens[i + 1].ch == '-')) {
      sciAt = i;
      break;
    }
  }
  var coreEnd = last;
  var expDigits = 0;
  var expPlus = true;
  if (sciAt > 0) {
    coreEnd = sciAt - 1;
    expPlus = tokens[sciAt + 1].ch == '+';
    for (var i = sciAt + 2; i < tokens.length; i++) {
      if (!tokens[i].lit && tokens[i].ch == '0') expDigits++;
    }
    last = tokens.length - 1;
    for (var i = coreEnd; i >= first; i--) {
      if (_isPlaceholder(tokens[i])) {
        coreEnd = i;
        break;
      }
    }
  }

  final core = tokens.sublist(first, coreEnd + 1);
  if (core.any((t) => !t.lit && t.ch == '/')) return _general(value);

  final pre = StringBuffer();
  for (var i = 0; i < first; i++) {
    pre.write(tokens[i].ch);
  }
  final post = StringBuffer();
  var trailingCommas = 0;
  if (sciAt < 0) {
    var i = last + 1;
    while (i < tokens.length && !tokens[i].lit && tokens[i].ch == ',') {
      trailingCommas++;
      i++;
    }
    for (; i < tokens.length; i++) {
      post.write(tokens[i].ch);
    }
  } else {
    // E+00 dan keyingi ortiqcha belgilar
    var i = sciAt + 2;
    while (i < tokens.length && !tokens[i].lit && tokens[i].ch == '0') {
      i++;
    }
    for (; i < tokens.length; i++) {
      post.write(tokens[i].ch);
    }
  }

  var percent = 0;
  for (final t in tokens) {
    if (!t.lit && t.ch == '%') percent++;
  }
  var scaled = value;
  for (var i = 0; i < percent; i++) {
    scaled *= 100;
  }
  for (var i = 0; i < trailingCommas; i++) {
    scaled /= 1000;
  }

  var dot = -1;
  for (var i = 0; i < core.length; i++) {
    if (!core[i].lit && core[i].ch == '.') {
      dot = i;
      break;
    }
  }
  final intPart = dot < 0 ? core : core.sublist(0, dot);
  final fracPart = dot < 0 ? const <_Tok>[] : core.sublist(dot + 1);

  var maxDec = 0;
  var minDec = 0;
  for (final t in fracPart) {
    if (_isPlaceholder(t)) {
      maxDec++;
      if (t.ch == '0') minDec++;
    }
  }
  var minInt = 0;
  var grouping = false;
  var embedded = false;
  for (final t in intPart) {
    if (_isPlaceholder(t)) {
      if (t.ch == '0') minInt++;
    } else if (!t.lit && t.ch == ',') {
      grouping = true;
    } else {
      embedded = true;
    }
  }

  String body;
  if (sciAt >= 0) {
    var exp = 0;
    var mant = scaled;
    if (mant != 0) {
      exp = (math.log(mant) / math.ln10).floor();
      mant = mant / math.pow(10, exp);
      if (mant >= 10) {
        mant /= 10;
        exp++;
      }
    }
    var ms = mant.toStringAsFixed(maxDec);
    if (double.parse(ms) >= 10) {
      mant /= 10;
      exp++;
      ms = mant.toStringAsFixed(maxDec);
    }
    final sign = exp < 0 ? '-' : (expPlus ? '+' : '');
    body = '${ms}E$sign${exp.abs().toString().padLeft(math.max(expDigits, 1), '0')}';
  } else {
    var s = scaled.toStringAsFixed(maxDec);
    var ip = s;
    var fp = '';
    final di = s.indexOf('.');
    if (di >= 0) {
      ip = s.substring(0, di);
      fp = s.substring(di + 1);
    }
    while (fp.length > minDec && fp.endsWith('0')) {
      fp = fp.substring(0, fp.length - 1);
    }
    if (embedded && maxDec == 0) {
      body = _template(ip, intPart);
    } else {
      if (ip == '0' && minInt == 0) ip = '';
      if (ip.length < minInt) ip = ip.padLeft(minInt, '0');
      if (grouping && ip.length > 3) {
        final sb = StringBuffer();
        for (var i = 0; i < ip.length; i++) {
          if (i > 0 && (ip.length - i) % 3 == 0) sb.write(',');
          sb.write(ip[i]);
        }
        ip = sb.toString();
      }
      body = fp.isEmpty ? ip : '$ip.$fp';
    }
    if (negative && !RegExp(r'[1-9]').hasMatch(s)) negative = false;
  }

  return '${negative ? '-' : ''}$pre$body$post';
}

String _template(String digits, List<_Tok> pattern) {
  final out = <String>[];
  var di = digits.length - 1;
  for (var i = pattern.length - 1; i >= 0; i--) {
    final t = pattern[i];
    if (_isPlaceholder(t)) {
      if (di >= 0) {
        out.add(digits[di--]);
      } else if (t.ch == '0') {
        out.add('0');
      }
    } else if (!(t.ch == ',' && !t.lit)) {
      out.add(t.ch);
    }
  }
  while (di >= 0) {
    out.add(digits[di--]);
  }
  return out.reversed.join();
}

class _DT {
  final String kind; // lit, d, m, y, h, s, ap, fr, el
  final String text;
  final int n;
  bool minute = false;
  _DT(this.kind, this.text, this.n);
}

const _months = [
  'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August',
  'September', 'October', 'November', 'December',
];
const _days = [
  'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday',
];

String _formatDate(double v, String sec, bool is1904) {
  if (v < 0 || v > 2958465) return '########';

  final toks = <_DT>[];
  var i = 0;
  while (i < sec.length) {
    final ch = sec[i];
    final low = ch.toLowerCase();
    if (ch == '"') {
      final end = sec.indexOf('"', i + 1);
      toks.add(_DT('lit', end < 0 ? sec.substring(i + 1) : sec.substring(i + 1, end), 0));
      i = end < 0 ? sec.length : end + 1;
    } else if (ch == '\\') {
      if (i + 1 < sec.length) toks.add(_DT('lit', sec[i + 1], 0));
      i += 2;
    } else if (ch == '_' || ch == '*') {
      i += 2;
    } else if (ch == '[') {
      final end = sec.indexOf(']', i);
      final inner = (end < 0 ? sec.substring(i + 1) : sec.substring(i + 1, end))
          .toLowerCase();
      if (inner.isNotEmpty && 'hms'.contains(inner[0])) {
        toks.add(_DT('el', inner[0], inner.length));
      }
      i = end < 0 ? sec.length : end + 1;
    } else if ('dmyhs'.contains(low) && low.isNotEmpty) {
      var j = i;
      while (j < sec.length && sec[j].toLowerCase() == low) {
        j++;
      }
      toks.add(_DT(low, '', j - i));
      i = j;
    } else if (low == 'a' &&
        sec.substring(i).toLowerCase().startsWith('am/pm')) {
      toks.add(_DT('ap', '', 5));
      i += 5;
    } else if (low == 'a' && sec.substring(i).toLowerCase().startsWith('a/p')) {
      toks.add(_DT('ap', '', 3));
      i += 3;
    } else if (ch == '.' &&
        toks.isNotEmpty &&
        toks.last.kind == 's' &&
        i + 1 < sec.length &&
        sec[i + 1] == '0') {
      var j = i + 1;
      while (j < sec.length && sec[j] == '0') {
        j++;
      }
      toks.add(_DT('fr', '', j - i - 1));
      i = j;
    } else {
      toks.add(_DT('lit', ch, 0));
      i++;
    }
  }

  for (var k = 0; k < toks.length; k++) {
    if (toks[k].kind != 'm') continue;
    var prev = k - 1;
    while (prev >= 0 && toks[prev].kind == 'lit') {
      prev--;
    }
    var next = k + 1;
    while (next < toks.length && toks[next].kind == 'lit') {
      next++;
    }
    final afterHour = prev >= 0 &&
        (toks[prev].kind == 'h' ||
            (toks[prev].kind == 'el' && toks[prev].text == 'h'));
    final beforeSec = next < toks.length &&
        (toks[next].kind == 's' ||
            (toks[next].kind == 'el' && toks[next].text == 's'));
    toks[k].minute = afterHour || beforeSec;
  }

  final hasAp = toks.any((t) => t.kind == 'ap');
  var fracDigits = 0;
  for (final t in toks) {
    if (t.kind == 'fr') fracDigits = t.n;
  }

  final epoch = is1904 ? DateTime.utc(1904, 1, 1) : DateTime.utc(1899, 12, 30);
  var wholeDays = v.floor();
  final dayFrac = v - wholeDays;
  var millis = (dayFrac * 86400000).round();
  if (fracDigits == 0) millis = ((millis + 500) ~/ 1000) * 1000;
  if (millis >= 86400000) {
    millis -= 86400000;
    wholeDays++;
  }
  final date = epoch.add(Duration(days: wholeDays));
  final secsTotal = millis ~/ 1000;
  final hour = secsTotal ~/ 3600;
  final minute = (secsTotal % 3600) ~/ 60;
  final second = secsTotal % 60;
  final ms = millis % 1000;

  String pad(int n, int w) => n.toString().padLeft(w, '0');

  final sb = StringBuffer();
  for (final t in toks) {
    switch (t.kind) {
      case 'lit':
        sb.write(t.text);
        break;
      case 'd':
        if (t.n <= 1) {
          sb.write(date.day);
        } else if (t.n == 2) {
          sb.write(pad(date.day, 2));
        } else if (t.n == 3) {
          sb.write(_days[date.weekday - 1].substring(0, 3));
        } else {
          sb.write(_days[date.weekday - 1]);
        }
        break;
      case 'm':
        if (t.minute) {
          sb.write(t.n >= 2 ? pad(minute, 2) : minute.toString());
        } else if (t.n <= 1) {
          sb.write(date.month);
        } else if (t.n == 2) {
          sb.write(pad(date.month, 2));
        } else if (t.n == 3) {
          sb.write(_months[date.month - 1].substring(0, 3));
        } else if (t.n == 4) {
          sb.write(_months[date.month - 1]);
        } else {
          sb.write(_months[date.month - 1][0]);
        }
        break;
      case 'y':
        sb.write(t.n <= 2 ? pad(date.year % 100, 2) : pad(date.year, 4));
        break;
      case 'h':
        var h = hour;
        if (hasAp) h = h % 12 == 0 ? 12 : h % 12;
        sb.write(t.n >= 2 ? pad(h, 2) : h.toString());
        break;
      case 's':
        sb.write(t.n >= 2 ? pad(second, 2) : second.toString());
        break;
      case 'fr':
        sb.write('.');
        sb.write(pad(ms, 3).substring(0, math.min(t.n, 3)));
        break;
      case 'ap':
        final pm = hour >= 12;
        sb.write(t.n == 5 ? (pm ? 'PM' : 'AM') : (pm ? 'P' : 'A'));
        break;
      case 'el':
        final total = t.text == 'h'
            ? (v * 24).floor()
            : t.text == 'm'
                ? (v * 1440).floor()
                : (v * 86400).floor();
        sb.write(pad(total, t.n));
        break;
    }
  }
  return sb.toString();
}
