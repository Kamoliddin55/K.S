import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart' as fw show Text;
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import 'package:share_plus/share_plus.dart';

import 'archive_reader.dart';
import 'dialogs.dart';
import 'l10n.dart';
import 'library.dart';
import 'text_screen.dart';
import 'xlsx_model.dart';

// Excel ish stoli ranglari
const _excelGreen = Color(0xFF217346);
const _gridLine = Color(0xFFD4D4D4);
const _headerBg = Color(0xFFF1F1F1);
const _headerLine = Color(0xFFC8C8C8);
const _headerText = Color(0xFF444444);
const _fontScale = 0.94;

// =====================================================================
// Geometriya
// =====================================================================

List<double> _prefix(int n, double Function(int) size) {
  final out = List<double>.filled(n + 1, 0);
  for (var i = 0; i < n; i++) {
    out[i + 1] = out[i] + size(i);
  }
  return out;
}

int _find(List<double> pos, double x) {
  final last = pos.length - 2;
  if (last <= 0 || x <= 0) return 0;
  if (x >= pos[pos.length - 1]) return last;
  var lo = 0;
  var hi = last;
  while (lo < hi) {
    final mid = (lo + hi + 1) >> 1;
    if (pos[mid] <= x) {
      lo = mid;
    } else {
      hi = mid - 1;
    }
  }
  return lo;
}

class _Geom {
  final XSheet sheet;
  final List<double> colX;
  final List<double> rowY;
  final Set<int> covered = <int>{};
  final Map<int, XMerge> mergeAt = <int, XMerge>{};
  final double hw;
  static const double hh = 22;

  _Geom(this.sheet)
      : colX = _prefix(
          sheet.cols,
          (c) => sheet.hiddenCols.contains(c)
              ? 0.0
              : (sheet.colWidths[c] ?? sheet.defaultColWidth),
        ),
        rowY = _prefix(
          sheet.rows,
          (r) => sheet.hiddenRows.contains(r)
              ? 0.0
              : (sheet.rowHeights[r] ?? sheet.defaultRowHeight),
        ),
        hw = sheet.rows > 99999 ? 56 : (sheet.rows > 9999 ? 48 : 40) {
    for (final m in sheet.merges) {
      final area = (m.r2 - m.r1 + 1) * (m.c2 - m.c1 + 1);
      if (area > 200000 || m.r2 >= sheet.rows || m.c2 >= sheet.cols) continue;
      mergeAt[cellKey(m.r1, m.c1)] = m;
      for (var r = m.r1; r <= m.r2; r++) {
        for (var c = m.c1; c <= m.c2; c++) {
          if (r != m.r1 || c != m.c1) covered.add(cellKey(r, c));
        }
      }
    }
  }

  double get totalW => colX.last;
  double get totalH => rowY.last;

  XMerge? mergeContaining(int r, int c) {
    if (covered.contains(cellKey(r, c))) {
      for (final m in mergeAt.values) {
        if (r >= m.r1 && r <= m.r2 && c >= m.c1 && c <= m.c2) return m;
      }
    }
    return mergeAt[cellKey(r, c)];
  }
}

class _PaintCache {
  final Map<int, TextPainter> text = <int, TextPainter>{};
  final Map<int, TextPainter> hash = <int, TextPainter>{};
  void clear() {
    text.clear();
    hash.clear();
  }
}

// =====================================================================
// Chizuvchi
// =====================================================================

class _GridPainter extends CustomPainter {
  final _Geom geom;
  final List<XStyle> styles;
  final double zoom;
  final ValueNotifier<Offset> scroll;
  final int selR;
  final int selC;
  final Set<int> matches;
  final int current;
  final _PaintCache cache;

  _GridPainter({
    required this.geom,
    required this.styles,
    required this.zoom,
    required this.scroll,
    required this.selR,
    required this.selC,
    required this.matches,
    required this.current,
    required this.cache,
  }) : super(repaint: scroll);

  XSheet get sheet => geom.sheet;
  double get hw => geom.hw;
  static const double hh = _Geom.hh;

  @override
  bool shouldRepaint(_GridPainter old) =>
      old.geom != geom ||
      old.zoom != zoom ||
      old.selR != selR ||
      old.selC != selC ||
      old.current != current ||
      old.matches != matches;

  XStyle _style(int i) =>
      (i >= 0 && i < styles.length) ? styles[i] : const XStyle();

  @override
  void paint(Canvas canvas, Size size) {
    final z = zoom;
    final vw = size.width / z;
    final vh = size.height / z;
    final maxX = math.max(0.0, (hw + geom.totalW) * z - size.width);
    final maxY = math.max(0.0, (hh + geom.totalH) * z - size.height);
    final off = scroll.value;
    final ho = off.dx.clamp(0.0, maxX).roundToDouble() / z;
    final vo = off.dy.clamp(0.0, maxY).roundToDouble() / z;

    canvas.save();
    canvas.clipRect(Offset.zero & size);
    canvas.scale(z);
    canvas.drawRect(Rect.fromLTWH(0, 0, vw, vh), Paint()..color = Colors.white);

    final fc = sheet.freezeCols;
    final fr = sheet.freezeRows;
    final fw = geom.colX[fc];
    final fh = geom.rowY[fr];
    final bx = hw + fw;
    final by = hh + fh;

    final c0 = math.max(_find(geom.colX, fw + ho), fc);
    final c1 = math.max(_find(geom.colX, vw - hw + ho), c0);
    final r0 = math.max(_find(geom.rowY, fh + vo), fr);
    final r1 = math.max(_find(geom.rowY, vh - hh + vo), r0);

    final colEnd = math.min(c1, sheet.cols - 1);
    final rowEnd = math.min(r1, sheet.rows - 1);

    if (c0 <= colEnd && r0 <= rowEnd) {
      _region(canvas, r0, rowEnd, c0, colEnd, hw - ho, hh - vo,
          Rect.fromLTRB(bx, by, vw, vh));
    }
    if (fr > 0 && c0 <= colEnd) {
      _region(canvas, 0, fr - 1, c0, colEnd, hw - ho, hh,
          Rect.fromLTRB(bx, hh, vw, by));
    }
    if (fc > 0 && r0 <= rowEnd) {
      _region(canvas, r0, rowEnd, 0, fc - 1, hw, hh - vo,
          Rect.fromLTRB(hw, by, bx, vh));
    }
    if (fr > 0 && fc > 0) {
      _region(canvas, 0, fr - 1, 0, fc - 1, hw, hh,
          Rect.fromLTRB(hw, hh, bx, by));
    }

    // Qotirilgan chiziqlar
    final freeze = Paint()
      ..color = const Color(0xFF7A7A7A)
      ..strokeWidth = 1.5;
    if (fc > 0) canvas.drawLine(Offset(bx, hh), Offset(bx, vh), freeze);
    if (fr > 0) canvas.drawLine(Offset(hw, by), Offset(vw, by), freeze);

    _selection(canvas, vw, vh, ho, vo, fw, fh);

    // Sarlavhalar
    _colHeaders(canvas, c0, colEnd, hw - ho, Rect.fromLTRB(bx, 0, vw, hh));
    if (fc > 0) {
      _colHeaders(canvas, 0, fc - 1, hw, Rect.fromLTRB(hw, 0, bx, hh));
    }
    _rowHeaders(canvas, r0, rowEnd, hh - vo, Rect.fromLTRB(0, by, hw, vh));
    if (fr > 0) {
      _rowHeaders(canvas, 0, fr - 1, hh, Rect.fromLTRB(0, hh, hw, by));
    }
    final corner = Rect.fromLTWH(0, 0, hw, hh);
    canvas.drawRect(corner, Paint()..color = _headerBg);
    final tri = Path()
      ..moveTo(hw - 4, hh - 4)
      ..lineTo(hw - 4, hh - 14)
      ..lineTo(hw - 14, hh - 4)
      ..close();
    canvas.drawPath(tri, Paint()..color = const Color(0xFFB5B5B5));
    final line = Paint()
      ..color = _headerLine
      ..strokeWidth = 1;
    canvas.drawLine(Offset(0, hh), Offset(vw, hh), line);
    canvas.drawLine(Offset(hw, 0), Offset(hw, vh), line);

    canvas.restore();

    // Aylantirish ko'rsatkichlari (haqiqiy piksellarda)
    final thumb = Paint()..color = const Color(0x55000000);
    if (maxY > 0) {
      final track = size.height - hh * z;
      final h = math.max(24.0, track * size.height / (size.height + maxY));
      final y = hh * z + (track - h) * (off.dy.clamp(0.0, maxY) / maxY);
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(size.width - 5, y, 3, h),
          const Radius.circular(2),
        ),
        thumb,
      );
    }
    if (maxX > 0) {
      final track = size.width - hw * z;
      final w = math.max(24.0, track * size.width / (size.width + maxX));
      final x = hw * z + (track - w) * (off.dx.clamp(0.0, maxX) / maxX);
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, size.height - 5, w, 3),
          const Radius.circular(2),
        ),
        thumb,
      );
    }
  }

  // ---------- Sarlavhalar ----------

  void _text(Canvas canvas, String s, Rect rect, {bool bold = false}) {
    final tp = TextPainter(
      text: TextSpan(
        text: s,
        style: TextStyle(
          fontSize: 11.5,
          color: _headerText,
          fontWeight: bold ? FontWeight.w700 : FontWeight.w400,
        ),
      ),
      textDirection: TextDirection.ltr,
      maxLines: 1,
    )..layout();
    tp.paint(
      canvas,
      Offset(
        rect.left + (rect.width - tp.width) / 2,
        rect.top + (rect.height - tp.height) / 2,
      ),
    );
  }

  void _colHeaders(Canvas canvas, int c0, int c1, double dx, Rect clip) {
    if (clip.width <= 0 || c0 > c1) return;
    canvas.save();
    canvas.clipRect(clip);
    final line = Paint()
      ..color = _headerLine
      ..strokeWidth = 1;
    for (var c = c0; c <= c1; c++) {
      final w = geom.colX[c + 1] - geom.colX[c];
      if (w <= 0) continue;
      final rect = Rect.fromLTWH(geom.colX[c] + dx, 0, w, hh);
      final selected = c == selC;
      canvas.drawRect(
        rect,
        Paint()..color = selected ? const Color(0xFFCFE8D8) : _headerBg,
      );
      if (selected) {
        canvas.drawRect(
          Rect.fromLTWH(rect.left, hh - 2, rect.width, 2),
          Paint()..color = _excelGreen,
        );
      }
      canvas.drawLine(
        Offset(rect.right, 0),
        Offset(rect.right, hh),
        line,
      );
      _text(canvas, columnName(c), rect, bold: selected);
    }
    canvas.restore();
  }

  void _rowHeaders(Canvas canvas, int r0, int r1, double dy, Rect clip) {
    if (clip.height <= 0 || r0 > r1) return;
    canvas.save();
    canvas.clipRect(clip);
    final line = Paint()
      ..color = _headerLine
      ..strokeWidth = 1;
    for (var r = r0; r <= r1; r++) {
      final h = geom.rowY[r + 1] - geom.rowY[r];
      if (h <= 0) continue;
      final rect = Rect.fromLTWH(0, geom.rowY[r] + dy, hw, h);
      final selected = r == selR;
      canvas.drawRect(
        rect,
        Paint()..color = selected ? const Color(0xFFCFE8D8) : _headerBg,
      );
      if (selected) {
        canvas.drawRect(
          Rect.fromLTWH(hw - 2, rect.top, 2, rect.height),
          Paint()..color = _excelGreen,
        );
      }
      canvas.drawLine(
        Offset(0, rect.bottom),
        Offset(hw, rect.bottom),
        line,
      );
      _text(canvas, '${r + 1}', rect, bold: selected);
    }
    canvas.restore();
  }

  // ---------- Hudud ----------

  void _region(
    Canvas canvas,
    int r0,
    int r1,
    int c0,
    int c1,
    double dx,
    double dy,
    Rect clip,
  ) {
    if (clip.width <= 0 || clip.height <= 0) return;
    canvas.save();
    canvas.clipRect(clip);

    final colX = geom.colX;
    final rowY = geom.rowY;
    final left = colX[c0] + dx;
    final right = colX[c1 + 1] + dx;
    final top = rowY[r0] + dy;
    final bottom = rowY[r1 + 1] + dy;

    // 1) katak chiziqlari
    if (sheet.showGrid) {
      final gp = Paint()
        ..color = _gridLine
        ..strokeWidth = 1;
      for (var c = c0; c <= c1 + 1; c++) {
        final x = (colX[c] + dx).floorToDouble() + 0.5;
        canvas.drawLine(Offset(x, top), Offset(x, bottom), gp);
      }
      for (var r = r0; r <= r1 + 1; r++) {
        final y = (rowY[r] + dy).floorToDouble() + 0.5;
        canvas.drawLine(Offset(left, y), Offset(right, y), gp);
      }
    }

    // 2) fon ranglari va qidiruv belgilari
    for (var r = r0; r <= r1; r++) {
      final h = rowY[r + 1] - rowY[r];
      if (h <= 0) continue;
      for (var c = c0; c <= c1; c++) {
        final w = colX[c + 1] - colX[c];
        if (w <= 0) continue;
        final key = cellKey(r, c);
        if (geom.covered.contains(key) || geom.mergeAt.containsKey(key)) {
          continue;
        }
        final cell = sheet.cells[key];
        final rect = Rect.fromLTWH(colX[c] + dx, rowY[r] + dy, w, h);
        if (cell != null) {
          final fill = _style(cell.style).fill;
          if (fill != null) {
            canvas.drawRect(rect, Paint()..color = Color(fill));
          }
        }
        if (matches.contains(key)) {
          canvas.drawRect(
            rect,
            Paint()
              ..color = key == current
                  ? const Color(0xAAFFA726)
                  : const Color(0x88FFEB3B),
          );
        }
      }
    }

    // 3) birlashtirilgan kataklar
    final merged = <XMerge>[];
    for (final m in geom.mergeAt.values) {
      if (m.r2 < r0 || m.r1 > r1 || m.c2 < c0 || m.c1 > c1) continue;
      merged.add(m);
      final rect = Rect.fromLTRB(
        colX[m.c1] + dx,
        rowY[m.r1] + dy,
        colX[m.c2 + 1] + dx,
        rowY[m.r2 + 1] + dy,
      );
      final cell = sheet.cells[cellKey(m.r1, m.c1)];
      final fill = cell == null ? null : _style(cell.style).fill;
      canvas.drawRect(rect, Paint()..color = fill == null ? Colors.white : Color(fill));
      final key = cellKey(m.r1, m.c1);
      if (matches.contains(key)) {
        canvas.drawRect(
          rect,
          Paint()
            ..color = key == current
                ? const Color(0xAAFFA726)
                : const Color(0x88FFEB3B),
        );
      }
    }

    // 4) chegaralar
    for (var r = r0; r <= r1; r++) {
      final h = rowY[r + 1] - rowY[r];
      if (h <= 0) continue;
      for (var c = c0; c <= c1; c++) {
        final w = colX[c + 1] - colX[c];
        if (w <= 0) continue;
        final key = cellKey(r, c);
        if (geom.covered.contains(key) || geom.mergeAt.containsKey(key)) {
          continue;
        }
        final cell = sheet.cells[key];
        if (cell == null) continue;
        _borders(
          canvas,
          Rect.fromLTWH(colX[c] + dx, rowY[r] + dy, w, h),
          _style(cell.style),
          _style(cell.style),
        );
      }
    }
    for (final m in merged) {
      final rect = Rect.fromLTRB(
        colX[m.c1] + dx,
        rowY[m.r1] + dy,
        colX[m.c2 + 1] + dx,
        rowY[m.r2 + 1] + dy,
      );
      final tl = sheet.cells[cellKey(m.r1, m.c1)];
      final tr = sheet.cells[cellKey(m.r1, m.c2)];
      final bl = sheet.cells[cellKey(m.r2, m.c1)];
      final br = sheet.cells[cellKey(m.r2, m.c2)];
      final a = _style(tl?.style ?? 0);
      final b = _style((br ?? tr ?? tl)?.style ?? 0);
      final cStyle = _style((bl ?? tl)?.style ?? 0);
      final dStyle = _style((tr ?? tl)?.style ?? 0);
      _side(canvas, a.left, rect.topLeft, rect.bottomLeft);
      _side(canvas, a.top, rect.topLeft, rect.topRight);
      _side(canvas, dStyle.right, rect.topRight, rect.bottomRight);
      _side(canvas, cStyle.bottom, rect.bottomLeft, rect.bottomRight);
      if (b.right != null && br != null) {
        _side(canvas, b.right, rect.topRight, rect.bottomRight);
      }
    }

    // 5) matnlar
    for (var r = r0; r <= r1; r++) {
      final h = rowY[r + 1] - rowY[r];
      if (h <= 0) continue;
      for (var c = c0; c <= c1; c++) {
        final w = colX[c + 1] - colX[c];
        if (w <= 0) continue;
        final key = cellKey(r, c);
        if (geom.covered.contains(key) || geom.mergeAt.containsKey(key)) {
          continue;
        }
        final cell = sheet.cells[key];
        if (cell == null || cell.text.isEmpty) continue;
        final rect = Rect.fromLTWH(colX[c] + dx, rowY[r] + dy, w, h);
        _cellText(canvas, key, cell, rect, r, c, dx, true);
      }
    }
    for (final m in merged) {
      final key = cellKey(m.r1, m.c1);
      final cell = sheet.cells[key];
      if (cell == null || cell.text.isEmpty) continue;
      final rect = Rect.fromLTRB(
        colX[m.c1] + dx,
        rowY[m.r1] + dy,
        colX[m.c2 + 1] + dx,
        rowY[m.r2 + 1] + dy,
      );
      _cellText(canvas, key, cell, rect, m.r1, m.c1, dx, false);
    }

    canvas.restore();
  }

  void _side(Canvas canvas, XSide? side, Offset a, Offset b) {
    if (side == null) return;
    final paint = Paint()
      ..color = Color(side.color)
      ..strokeWidth = side.width.clamp(0.5, 3.0);
    canvas.drawLine(a, b, paint);
  }

  void _borders(Canvas canvas, Rect rect, XStyle s, XStyle _) {
    _side(canvas, s.left, rect.topLeft, rect.bottomLeft);
    _side(canvas, s.right, rect.topRight, rect.bottomRight);
    _side(canvas, s.top, rect.topLeft, rect.topRight);
    _side(canvas, s.bottom, rect.bottomLeft, rect.bottomRight);
  }

  // ---------- Matn ----------

  TextStyle _textStyle(XStyle st) {
    final f = st.font;
    return TextStyle(
      fontSize: f.size * 96 / 72 * _fontScale,
      color: Color(f.color ?? 0xFF000000),
      fontWeight: f.bold ? FontWeight.w700 : FontWeight.w400,
      fontStyle: f.italic ? FontStyle.italic : FontStyle.normal,
      decoration: f.underline
          ? TextDecoration.underline
          : (f.strike ? TextDecoration.lineThrough : TextDecoration.none),
      decorationColor: Color(f.color ?? 0xFF000000),
      height: 1.15,
    );
  }

  void _cellText(
    Canvas canvas,
    int key,
    XCell cell,
    Rect rect,
    int r,
    int c,
    double dx,
    bool overflow,
  ) {
    final st = _style(cell.style);
    final pad = 3.0 + st.indent * 9.0;
    final avail = math.max(rect.width - pad - 3, 1.0);

    var tp = cache.text[key];
    if (tp == null) {
      final text = st.wrap ? cell.text : cell.text.replaceAll(RegExp(r'\s*[\r\n]+\s*'), ' ');
      tp = TextPainter(
        text: TextSpan(text: text, style: _textStyle(st)),
        textDirection: TextDirection.ltr,
        maxLines: st.wrap ? null : 1,
      )..layout(maxWidth: st.wrap ? avail : double.infinity);
      if (cache.text.length > 4000) cache.clear();
      cache.text[key] = tp;
    }

    var align = st.hAlign;
    if (align == 'general') {
      align = cell.kind == 1 ? 'right' : (cell.kind == 2 ? 'center' : 'left');
    }

    // Raqam sig'masa, Excel kabi ##### ko'rsatiladi
    var painter = tp;
    if (cell.kind == 1 && !st.wrap && tp.width > rect.width - 2) {
      var hp = cache.hash[key];
      if (hp == null) {
        final one = TextPainter(
          text: TextSpan(text: '#', style: _textStyle(st)),
          textDirection: TextDirection.ltr,
        )..layout();
        final n = math.max(1, ((rect.width - 4) / math.max(one.width, 1)).floor());
        hp = TextPainter(
          text: TextSpan(text: '#' * n, style: _textStyle(st)),
          textDirection: TextDirection.ltr,
          maxLines: 1,
        )..layout();
        cache.hash[key] = hp;
      }
      painter = hp;
    }

    var clip = rect;
    if (overflow && !st.wrap && cell.kind == 0 && painter.width > avail) {
      if (align == 'left') {
        var extra = 0.0;
        var cc = c + 1;
        while (cc < sheet.cols && cc - c < 80 && extra + rect.width < painter.width + pad + 3) {
          final k = cellKey(r, cc);
          final other = sheet.cells[k];
          if ((other != null && other.text.isNotEmpty) || geom.covered.contains(k)) break;
          extra += geom.colX[cc + 1] - geom.colX[cc];
          cc++;
        }
        clip = Rect.fromLTRB(rect.left, rect.top, rect.right + extra, rect.bottom);
      } else if (align == 'right') {
        var extra = 0.0;
        var cc = c - 1;
        while (cc >= 0 && c - cc < 80 && extra + rect.width < painter.width + pad + 3) {
          final k = cellKey(r, cc);
          final other = sheet.cells[k];
          if ((other != null && other.text.isNotEmpty) || geom.covered.contains(k)) break;
          extra += geom.colX[cc + 1] - geom.colX[cc];
          cc--;
        }
        clip = Rect.fromLTRB(rect.left - extra, rect.top, rect.right, rect.bottom);
      }
    }

    double x;
    switch (align) {
      case 'right':
        x = rect.right - 3 - painter.width;
        break;
      case 'center':
      case 'centerContinuous':
        x = rect.left + (rect.width - painter.width) / 2;
        break;
      default:
        x = rect.left + pad;
    }

    double y;
    switch (st.vAlign) {
      case 'top':
        y = rect.top + 1;
        break;
      case 'center':
        y = rect.top + (rect.height - painter.height) / 2;
        break;
      default:
        y = rect.bottom - painter.height - 1;
    }
    if (y < rect.top) y = rect.top;

    canvas.save();
    canvas.clipRect(clip);
    painter.paint(canvas, Offset(x, y));
    canvas.restore();
  }

  // ---------- Tanlov ----------

  void _selection(
    Canvas canvas,
    double vw,
    double vh,
    double ho,
    double vo,
    double fw,
    double fh,
  ) {
    if (selR < 0 || selC < 0 || selR >= sheet.rows || selC >= sheet.cols) return;
    var r1 = selR;
    var c1 = selC;
    var r2 = selR;
    var c2 = selC;
    final m = geom.mergeContaining(selR, selC);
    if (m != null) {
      r1 = m.r1;
      c1 = m.c1;
      r2 = m.r2;
      c2 = m.c2;
    }
    final dx = c1 < sheet.freezeCols ? hw : hw - ho;
    final dy = r1 < sheet.freezeRows ? hh : hh - vo;
    final rect = Rect.fromLTRB(
      geom.colX[c1] + dx,
      geom.rowY[r1] + dy,
      geom.colX[c2 + 1] + dx,
      geom.rowY[r2 + 1] + dy,
    );
    final clip = Rect.fromLTRB(
      c1 < sheet.freezeCols ? hw : hw + fw,
      r1 < sheet.freezeRows ? hh : hh + fh,
      vw,
      vh,
    );
    canvas.save();
    canvas.clipRect(clip);
    canvas.drawRect(
      rect.deflate(1),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..color = _excelGreen,
    );
    canvas.drawRect(
      Rect.fromCenter(center: rect.bottomRight, width: 7, height: 7),
      Paint()..color = _excelGreen,
    );
    canvas.restore();
  }
}

// =====================================================================
// Ko'rinish oynasi (aylantirish, tegish, masshtab)
// =====================================================================

class _GridViewport extends StatefulWidget {
  final _Geom geom;
  final List<XStyle> styles;
  final double zoom;
  final ValueNotifier<Offset> scroll;
  final int selR;
  final int selC;
  final Set<int> matches;
  final int current;
  final _PaintCache cache;
  final void Function(int row, int col) onTap;
  final void Function(double zoom) onZoom;

  const _GridViewport({
    super.key,
    required this.geom,
    required this.styles,
    required this.zoom,
    required this.scroll,
    required this.selR,
    required this.selC,
    required this.matches,
    required this.current,
    required this.cache,
    required this.onTap,
    required this.onZoom,
  });

  @override
  State<_GridViewport> createState() => _GridViewportState();
}

class _GridViewportState extends State<_GridViewport>
    with SingleTickerProviderStateMixin {
  late final AnimationController _fling = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 650),
  );
  Size _size = Size.zero;
  Offset _from = Offset.zero;
  Offset _to = Offset.zero;

  final Map<int, Offset> _pointers = <int, Offset>{};
  double? _pinchStart;
  double _pinchBase = 1;

  @override
  void initState() {
    super.initState();
    _fling.addListener(_tick);
  }

  @override
  void dispose() {
    _fling.removeListener(_tick);
    _fling.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(_GridViewport old) {
    super.didUpdateWidget(old);
    if (old.zoom != widget.zoom && old.zoom > 0) {
      final k = widget.zoom / old.zoom;
      widget.scroll.value = _clamp(widget.scroll.value * k);
    }
  }

  Offset _max() {
    final g = widget.geom;
    final z = widget.zoom;
    return Offset(
      math.max(0.0, (g.hw + g.totalW) * z - _size.width),
      math.max(0.0, (_Geom.hh + g.totalH) * z - _size.height),
    );
  }

  Offset _clamp(Offset o) {
    final m = _max();
    return Offset(o.dx.clamp(0.0, m.dx), o.dy.clamp(0.0, m.dy));
  }

  void _tick() {
    final v = Curves.easeOutCubic.transform(_fling.value);
    widget.scroll.value = _clamp(Offset.lerp(_from, _to, v)!);
  }

  void reveal(int r, int c) {
    final g = widget.geom;
    final z = widget.zoom;
    final s = g.sheet;
    final fw = g.colX[s.freezeCols];
    final fh = g.rowY[s.freezeRows];
    final o = widget.scroll.value;
    var dx = o.dx;
    var dy = o.dy;
    if (c >= s.freezeCols) {
      final left = (g.colX[c] - fw) * z;
      final right = (g.colX[c + 1] - fw) * z;
      final view = _size.width - (g.hw + fw) * z;
      if (left < dx) {
        dx = left;
      } else if (right > dx + view) {
        dx = right - view;
      }
    }
    if (r >= s.freezeRows) {
      final top = (g.rowY[r] - fh) * z;
      final bottom = (g.rowY[r + 1] - fh) * z;
      final view = _size.height - (_Geom.hh + fh) * z;
      if (top < dy) {
        dy = top;
      } else if (bottom > dy + view) {
        dy = bottom - view;
      }
    }
    widget.scroll.value = _clamp(Offset(dx, dy));
  }

  void _handleTap(Offset p) {
    final z = widget.zoom;
    final g = widget.geom;
    final s = g.sheet;
    final off = widget.scroll.value;
    final bx = p.dx / z;
    final by = p.dy / z;
    if (bx < g.hw || by < _Geom.hh) return;
    final ho = off.dx.roundToDouble() / z;
    final vo = off.dy.roundToDouble() / z;
    final fw = g.colX[s.freezeCols];
    final fh = g.rowY[s.freezeRows];
    final sx = bx < g.hw + fw ? bx - g.hw : bx - g.hw + ho;
    final sy = by < _Geom.hh + fh ? by - _Geom.hh : by - _Geom.hh + vo;
    if (sx < 0 || sy < 0 || sx >= g.totalW || sy >= g.totalH) return;
    var c = _find(g.colX, sx);
    var r = _find(g.rowY, sy);
    final m = g.mergeContaining(r, c);
    if (m != null) {
      r = m.r1;
      c = m.c1;
    }
    widget.onTap(r, c);
  }

  double _distance() {
    final pts = _pointers.values.toList();
    if (pts.length < 2) return 0;
    return (pts[0] - pts[1]).distance;
  }

  void _pointerEnd(PointerEvent e) {
    _pointers.remove(e.pointer);
    if (_pointers.length < 2) _pinchStart = null;
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, cons) {
        _size = Size(cons.maxWidth, cons.maxHeight);
        return Listener(
          onPointerDown: (e) {
            _pointers[e.pointer] = e.position;
            if (_pointers.length == 2) {
              _pinchStart = _distance();
              _pinchBase = widget.zoom;
            }
          },
          onPointerMove: (e) {
            if (!_pointers.containsKey(e.pointer)) return;
            _pointers[e.pointer] = e.position;
            final start = _pinchStart;
            if (_pointers.length == 2 && start != null && start > 0) {
              final next = (_pinchBase * _distance() / start)
                  .clamp(0.4, 3.0)
                  .toDouble();
              if ((next - widget.zoom).abs() > 0.01) widget.onZoom(next);
            }
          },
          onPointerUp: _pointerEnd,
          onPointerCancel: _pointerEnd,
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapUp: (d) => _handleTap(d.localPosition),
            onPanStart: (_) => _fling.stop(),
            onPanUpdate: (d) {
              if (_pointers.length >= 2) return;
              widget.scroll.value = _clamp(widget.scroll.value - d.delta);
            },
            onPanEnd: (d) {
              final v = d.velocity.pixelsPerSecond;
              if (v.distance < 120 || _pointers.length >= 2) return;
              _from = widget.scroll.value;
              _to = _clamp(_from - v * 0.38);
              _fling.forward(from: 0);
            },
            child: ClipRect(
              child: CustomPaint(
                size: Size.infinite,
                painter: _GridPainter(
                  geom: widget.geom,
                  styles: widget.styles,
                  zoom: widget.zoom,
                  scroll: widget.scroll,
                  selR: widget.selR,
                  selC: widget.selC,
                  matches: widget.matches,
                  current: widget.current,
                  cache: widget.cache,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

// =====================================================================
// Ekran
// =====================================================================

class SheetScreen extends StatefulWidget {
  final String path;
  const SheetScreen({super.key, required this.path});

  @override
  State<SheetScreen> createState() => _SheetScreenState();
}

class _SheetScreenState extends State<SheetScreen> {
  final _scroll = ValueNotifier<Offset>(Offset.zero);
  final _viewKey = GlobalKey<_GridViewportState>();
  final _tabs = ScrollController();
  final _searchController = TextEditingController();
  final _searchFocus = FocusNode();

  XWorkbook? _wb;
  String? _error;
  bool _loading = true;

  int _sheet = 0;
  int _selR = -1;
  int _selC = -1;
  double _zoom = 1;
  final Map<int, _Geom> _geoms = <int, _Geom>{};
  final Map<int, _PaintCache> _caches = <int, _PaintCache>{};

  bool _searching = false;
  Set<int> _matchSet = const <int>{};
  List<int> _matches = const <int>[];
  int _matchPos = -1;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _scroll.dispose();
    _tabs.dispose();
    _searchController.dispose();
    _searchFocus.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      String? mediaDir;
      try {
        final cache = await ArchiveReader.cacheDirectory();
        final id = sha1
            .convert(utf8.encode(widget.path))
            .toString()
            .substring(0, 16);
        mediaDir = p.join(cache.path, 'media', id);
      } catch (_) {
        mediaDir = null;
      }
      final wb = await loadWorkbook(widget.path, mediaDir: mediaDir);
      if (!mounted) return;
      setState(() {
        _wb = wb;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = errorText(e);
        _loading = false;
      });
    }
  }

  _Geom get _geom =>
      _geoms.putIfAbsent(_sheet, () => _Geom(_wb!.sheets[_sheet]));
  _PaintCache get _cache => _caches.putIfAbsent(_sheet, () => _PaintCache());

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  void _select(int r, int c) {
    setState(() {
      _selR = r;
      _selC = c;
    });
    HapticFeedback.selectionClick();
  }

  void _switchSheet(int i) {
    if (i == _sheet) return;
    setState(() {
      _sheet = i;
      _selR = -1;
      _selC = -1;
      _matches = const <int>[];
      _matchSet = const <int>{};
      _matchPos = -1;
    });
    _scroll.value = Offset.zero;
    if (_searching && _searchController.text.isNotEmpty) {
      _runSearch(_searchController.text);
    }
  }

  void _setZoom(double z) {
    final next = z.clamp(0.4, 3.0).toDouble();
    if (next == _zoom) return;
    setState(() => _zoom = next);
  }

  // ---------- Qidiruv ----------

  void _startSearch() {
    setState(() => _searching = true);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _searchFocus.requestFocus();
    });
  }

  void _closeSearch() {
    _searchController.clear();
    setState(() {
      _searching = false;
      _matches = const <int>[];
      _matchSet = const <int>{};
      _matchPos = -1;
    });
  }

  void _runSearch(String value) {
    final q = value.trim().toLowerCase();
    if (q.isEmpty) {
      setState(() {
        _matches = const <int>[];
        _matchSet = const <int>{};
        _matchPos = -1;
      });
      return;
    }
    final found = <int>[];
    for (final e in _wb!.sheets[_sheet].cells.entries) {
      if (e.value.text.toLowerCase().contains(q)) found.add(e.key);
      if (found.length >= 5000) break;
    }
    found.sort();
    setState(() {
      _matches = found;
      _matchSet = found.toSet();
      _matchPos = found.isEmpty ? -1 : 0;
    });
    if (found.isNotEmpty) _goToMatch();
  }

  void _stepMatch(int delta) {
    if (_matches.isEmpty) return;
    setState(() {
      _matchPos = (_matchPos + delta) % _matches.length;
      if (_matchPos < 0) _matchPos += _matches.length;
    });
    _goToMatch();
  }

  void _goToMatch() {
    final key = _matches[_matchPos];
    final r = key ~/ kColStride;
    final c = key % kColStride;
    setState(() {
      _selR = r;
      _selC = c;
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _viewKey.currentState?.reveal(r, c);
    });
  }

  // ---------- Amallar ----------

  XCell? get _selectedCell {
    if (_selR < 0 || _selC < 0) return null;
    return _wb!.sheets[_sheet].cells[cellKey(_selR, _selC)];
  }

  Future<void> _copySelected() async {
    final cell = _selectedCell;
    if (cell == null || cell.text.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: cell.text));
    _snack(t('Nusxalandi'));
  }

  void _showCellDialog() {
    final cell = _selectedCell;
    if (cell == null) return;
    final address = cellAddress(_selR, _selC);
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: fw.Text(address),
        content: SingleChildScrollView(
          child: SelectableText(
            [
              if (cell.formula != null) cell.formula!,
              if (cell.text.isNotEmpty) cell.text,
            ].join('\n\n'),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: cell.text));
              Navigator.pop(ctx);
              _snack(t('Nusxalandi'));
            },
            child: Text('Nusxalash'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text('Yopish'),
          ),
        ],
      ),
    );
  }

  void _showZoom() {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Text('Masshtab'),
                  const Spacer(),
                  Text('${(_zoom * 100).round()}%'),
                  TextButton(
                    onPressed: () {
                      _setZoom(1);
                      setSheet(() {});
                    },
                    child: Text('Asl holat'),
                  ),
                ],
              ),
              Slider(
                min: 0.4,
                max: 3.0,
                value: _zoom.clamp(0.4, 3.0).toDouble(),
                onChanged: (v) {
                  _setZoom(v);
                  setSheet(() {});
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showPictures() {
    final list = _wb?.media ?? const <String>[];
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => _PicturesScreen(paths: list)),
    );
  }

  Future<void> _share() async {
    try {
      await Share.shareXFiles([XFile(widget.path)]);
    } catch (e) {
      _snack("Ulashib bo'lmadi: ${errorText(e)}");
    }
  }

  Future<void> _onMenu(String value) async {
    switch (value) {
      case 'zoom':
        _showZoom();
        break;
      case 'images':
        _showPictures();
        break;
      case 'text':
        await Navigator.of(context).pushReplacement(
          MaterialPageRoute<void>(
            builder: (_) => TextScreen(path: widget.path),
          ),
        );
        break;
      case 'share':
        await _share();
        break;
      case 'external':
        await OpenFilex.open(widget.path);
        break;
    }
  }

  // ---------- Ko'rinish ----------

  PreferredSizeWidget _appBar() {
    if (_searching) {
      return AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: _closeSearch,
        ),
        title: TextField(
          controller: _searchController,
          focusNode: _searchFocus,
          onChanged: _runSearch,
          onSubmitted: (_) => _stepMatch(1),
          textInputAction: TextInputAction.search,
          decoration: InputDecoration(
            hintText: t('Qidirish...'),
            border: InputBorder.none,
          ),
        ),
        actions: [
          if (_searchController.text.isNotEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text(
                  _matches.isEmpty ? '0' : '${_matchPos + 1}/${_matches.length}',
                ),
              ),
            ),
          IconButton(
            tooltip: t('Oldingi'),
            icon: const Icon(Icons.keyboard_arrow_up),
            onPressed: _matches.isEmpty ? null : () => _stepMatch(-1),
          ),
          IconButton(
            tooltip: t('Keyingi'),
            icon: const Icon(Icons.keyboard_arrow_down),
            onPressed: _matches.isEmpty ? null : () => _stepMatch(1),
          ),
        ],
      );
    }

    return AppBar(
      title: Text(
        Library.displayName(widget.path),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      actions: [
        if (_wb != null)
          IconButton(
            tooltip: t('Qidirish'),
            icon: const Icon(Icons.search),
            onPressed: _startSearch,
          ),
        PopupMenuButton<String>(
          onSelected: _onMenu,
          itemBuilder: (_) => [
            PopupMenuItem(value: 'zoom', child: Text('Masshtab')),
            if ((_wb?.media ?? const <String>[]).isNotEmpty)
              PopupMenuItem(value: 'images', child: Text('Rasmlar')),
            PopupMenuItem(value: 'text', child: Text('Matn sifatida ochish')),
            PopupMenuItem(value: 'share', child: Text('Ulashish')),
            PopupMenuItem(value: 'external', child: Text('Boshqa ilovada ochish')),
          ],
        ),
      ],
    );
  }

  Widget _formulaBar() {
    final scheme = Theme.of(context).colorScheme;
    final cell = _selectedCell;
    final hasSel = _selR >= 0 && _selC >= 0;
    final content = cell == null ? '' : (cell.formula ?? cell.text);
    return Material(
      color: scheme.surfaceContainerHighest.withAlpha(150),
      child: SizedBox(
        height: 38,
        child: Row(
          children: [
            Container(
              width: 74,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                border: Border(
                  right: BorderSide(color: scheme.outlineVariant),
                ),
              ),
              child: fw.Text(
                hasSel ? cellAddress(_selR, _selC) : '—',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 8),
              child: Text(
                'fx',
                style: TextStyle(
                  fontStyle: FontStyle.italic,
                  color: _excelGreen,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: cell == null ? null : _showCellDialog,
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: fw.Text(
                    content,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
            ),
            if (cell != null && cell.text.isNotEmpty)
              IconButton(
                tooltip: t('Nusxalash'),
                visualDensity: VisualDensity.compact,
                icon: const Icon(Icons.copy_rounded, size: 18),
                onPressed: _copySelected,
              ),
          ],
        ),
      ),
    );
  }

  Widget _tabBar() {
    final scheme = Theme.of(context).colorScheme;
    final sheets = _wb!.sheets;
    return Material(
      color: scheme.surfaceContainerHighest,
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 42,
          child: ListView.builder(
            controller: _tabs,
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 6),
            itemCount: sheets.length,
            itemBuilder: (context, i) {
              final active = i == _sheet;
              final tab = sheets[i].tabColor;
              return InkWell(
                onTap: () => _switchSheet(i),
                child: Container(
                  alignment: Alignment.center,
                  margin: const EdgeInsets.symmetric(horizontal: 2, vertical: 4),
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    color: active ? scheme.surface : Colors.transparent,
                    borderRadius: const BorderRadius.vertical(
                      bottom: Radius.circular(8),
                    ),
                    border: Border(
                      bottom: BorderSide(
                        color: tab != null
                            ? Color(tab)
                            : (active ? _excelGreen : Colors.transparent),
                        width: 3,
                      ),
                    ),
                  ),
                  child: fw.Text(
                    sheets[i].name,
                    style: TextStyle(
                      fontWeight: active ? FontWeight.w700 : FontWeight.w400,
                      color: active ? _excelGreen : null,
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _body() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, size: 48),
              const SizedBox(height: 12),
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () => _onMenu('text'),
                child: Text('Matn sifatida ochish'),
              ),
            ],
          ),
        ),
      );
    }

    final wb = _wb!;
    return Column(
      children: [
        _formulaBar(),
        Expanded(
          child: _GridViewport(
            key: _viewKey,
            geom: _geom,
            styles: wb.styles,
            zoom: _zoom,
            scroll: _scroll,
            selR: _selR,
            selC: _selC,
            matches: _matchSet,
            current: _matches.isEmpty || _matchPos < 0 ? -1 : _matches[_matchPos],
            cache: _cache,
            onTap: _select,
            onZoom: _setZoom,
          ),
        ),
        _tabBar(),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: _appBar(), body: _body());
  }
}

// =====================================================================
// Rasmlar
// =====================================================================

class _PicturesScreen extends StatelessWidget {
  final List<String> paths;
  const _PicturesScreen({required this.paths});

  void _open(BuildContext context, String path) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.black,
            foregroundColor: Colors.white,
            title: Text(p.basename(path).replaceFirst(RegExp(r'^\d+_'), '')),
          ),
          body: Center(
            child: InteractiveViewer(
              maxScale: 8,
              child: Image.file(
                File(path),
                errorBuilder: (_, __, ___) => const Icon(
                  Icons.broken_image_outlined,
                  color: Colors.white54,
                  size: 64,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Rasmlar')),
      body: GridView.builder(
        padding: const EdgeInsets.all(12),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 180,
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
        ),
        itemCount: paths.length,
        itemBuilder: (context, i) => InkWell(
          onTap: () => _open(context, paths[i]),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.file(
              File(paths[i]),
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_outlined),
            ),
          ),
        ),
      ),
    );
  }
}
