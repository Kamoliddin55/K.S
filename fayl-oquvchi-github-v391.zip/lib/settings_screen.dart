import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart' hide Text;
import 'package:share_plus/share_plus.dart';

import 'archive_reader.dart';
import 'backup.dart';
import 'dialogs.dart';
import 'l10n.dart';
import 'library.dart';
import 'lock.dart';
import 'settings.dart';
import 'stats_screen.dart';
import 'theme.dart';
import 'user_data.dart';

enum SettingsPage { menu, look, home, reading, general, security, data, about }

class SettingsScreen extends StatefulWidget {
  final SettingsPage page;
  const SettingsScreen({super.key, this.page = SettingsPage.menu});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late Future<int> _size = Library.totalSize();

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  void _refreshSize() {
    if (!mounted) return;
    setState(() => _size = Library.totalSize());
  }

  Future<void> _clearCache() async {
    try {
      await ArchiveReader.clearCache();
      _snack('Vaqtinchalik fayllar tozalandi');
    } catch (e) {
      _snack('Xatolik: ${errorText(e)}');
    }
  }

  Future<void> _deleteAll() async {
    final ok = await confirmDialog(
      context,
      title: "Barcha fayllarni o'chirasizmi?",
      message:
          "Kutubxonadagi barcha fayllar, xatcho'plar va o'qish joylari o'chiriladi.",
      confirm: "O'chirish",
    );
    if (!ok) return;

    try {
      final items = await Library.list();
      for (final item in items) {
        await item.file.delete();
        await UserData.instance.forget(item.key);
      }
      _snack("Barcha fayllar o'chirildi");
    } catch (e) {
      _snack("O'chirib bo'lmadi: ${errorText(e)}");
    }
    _refreshSize();
  }

  bool _working = false;

  static final RegExp _pinPattern = RegExp(r'^\d{4,8}$');

  Future<String?> _askPin(String title, String label) {
    return promptText(
      context,
      title: title,
      label: label,
      obscure: true,
      keyboardType: TextInputType.number,
      confirm: 'Davom etish',
    );
  }

  Future<bool> _createPin() async {
    final first = await _askPin('Yangi PIN kod', 'PIN (4-8 raqam)');
    if (first == null || !mounted) return false;
    if (!_pinPattern.hasMatch(first)) {
      _snack("PIN 4 dan 8 gacha raqamdan iborat bo'lishi kerak");
      return false;
    }

    final second = await _askPin('PIN kodni takrorlang', 'PIN');
    if (second == null || !mounted) return false;
    if (second != first) {
      _snack('PIN kodlar mos kelmadi');
      return false;
    }

    final ok = await LockService.instance.setPin(first);
    if (!ok) _snack("PIN kodni saqlab bo'lmadi");
    return ok;
  }

  Future<bool> _checkPin() async {
    final pin = await _askPin('Joriy PIN kod', 'PIN');
    if (pin == null || !mounted) return false;
    if (!LockService.instance.verify(pin)) {
      _snack("PIN noto'g'ri");
      return false;
    }
    return true;
  }

  Future<void> _toggleLock(bool on) async {
    if (on) {
      final ok = await _createPin();
      if (ok) {
        _snack(
          "Ilova qulfi yoqildi. PIN kodni unutsangiz, ilova ma'lumotlarini tozalashga to'g'ri keladi.",
        );
      }
    } else if (await _checkPin()) {
      await LockService.instance.disable();
      _snack("Ilova qulfi o'chirildi");
    }
  }

  Future<void> _toggleBio(bool on) async {
    final lock = LockService.instance;
    if (!on) {
      await lock.setBio(false);
      return;
    }
    if (!await lock.bioAvailable()) {
      _snack("Qurilmada barmoq izi yoki yuz bilan ochish sozlanmagan");
      return;
    }
    final ok = await lock.authenticateBio(t('Barmoq izi bilan ochish'));
    if (ok) {
      await lock.setBio(true);
    } else {
      _snack("Tekshiruv bajarilmadi");
    }
  }

  Future<void> _changePin() async {
    if (await _checkPin()) await _createPin();
  }

  Future<void> _backup() async {
    setState(() => _working = true);
    try {
      final file = await Backup.create();
      if (!mounted) return;
      await Share.shareXFiles([XFile(file.path)]);
    } catch (e) {
      _snack('Xatolik: ${errorText(e)}');
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  Future<void> _restore() async {
    FilePickerResult? result;
    try {
      result = await FilePicker.platform.pickFiles(type: FileType.any);
    } catch (e) {
      _snack('Xatolik: ${errorText(e)}');
      return;
    }

    final path = result?.files.single.path;
    if (path == null || !mounted) return;
    if (!path.toLowerCase().endsWith('.zip')) {
      _snack("Zaxira fayli .zip bo'lishi kerak");
      return;
    }

    final ok = await confirmDialog(
      context,
      title: 'Zaxiradan tiklaysizmi?',
      message:
          "Fayllar kutubxonaga qo'shiladi, xatcho'plar va sozlamalar zaxiradagi qiymatlar bilan almashtiriladi.",
      confirm: 'Tiklash',
    );
    if (!ok || !mounted) return;

    setState(() => _working = true);
    try {
      final count = await Backup.restore(path);
      await AppSettings.instance.reload();
      await UserData.instance.init();
      _snack("Tiklandi. Qo'shilgan fayllar: $count");
      _refreshSize();
    } catch (e) {
      _snack('Xatolik: ${errorText(e)}');
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  // ---------- Menyu va sahifalar ----------

  static String _title(SettingsPage page) => switch (page) {
        SettingsPage.menu => 'Sozlamalar',
        SettingsPage.look => "Ko'rinish",
        SettingsPage.home => 'Bosh sahifa',
        SettingsPage.reading => "O'qish",
        SettingsPage.general => 'Umumiy',
        SettingsPage.security => 'Xavfsizlik',
        SettingsPage.data => 'Zaxira va xotira',
        SettingsPage.about => 'Ilova haqida',
      };

  void _open(SettingsPage page) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => SettingsScreen(page: page)),
    );
  }

  Widget _menuTile(
    IconData icon,
    Color color,
    String title,
    String subtitle,
    VoidCallback onTap,
  ) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Glass(
        radius: 24,
        onTap: onTap,
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [color, Color.alphaBlend(Colors.black26, color)],
                ),
              ),
              child: Icon(icon, color: Colors.white, size: 26),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 16.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 13,
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right_rounded, color: scheme.outline),
          ],
        ),
      ),
    );
  }

  List<Widget> _menu() {
    return [
      _menuTile(
        Icons.palette_rounded,
        const Color(0xFF6366F1),
        "Ko'rinish",
        'Til, mavzu, rang uslubi',
        () => _open(SettingsPage.look),
      ),
      _menuTile(
        Icons.dashboard_customize_rounded,
        const Color(0xFF2F7BE8),
        'Bosh sahifa',
        "Bo'limlarni yoqish va o'chirish",
        () => _open(SettingsPage.home),
      ),
      _menuTile(
        Icons.menu_book_rounded,
        const Color(0xFF14B8A6),
        "O'qish",
        "Shrift, o'lcham, ovoz, ekran",
        () => _open(SettingsPage.reading),
      ),
      _menuTile(
        Icons.tune_rounded,
        const Color(0xFFF59E0B),
        'Umumiy',
        'Saralash, tebranish, tasdiqlash',
        () => _open(SettingsPage.general),
      ),
      _menuTile(
        Icons.lock_rounded,
        const Color(0xFFE91E8C),
        'Xavfsizlik',
        'PIN kod va barmoq izi',
        () => _open(SettingsPage.security),
      ),
      _menuTile(
        Icons.storage_rounded,
        const Color(0xFF0EA5E9),
        'Zaxira va xotira',
        'Zaxira nusxa, tozalash',
        () => _open(SettingsPage.data),
      ),
      _menuTile(
        Icons.insights_rounded,
        const Color(0xFF8B5CF6),
        'Statistika',
        "Fayllar va o'qish bo'yicha",
        () => Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (_) => const StatsScreen()),
        ),
      ),
      _menuTile(
        Icons.info_rounded,
        const Color(0xFF64748B),
        'Ilova haqida',
        'Versiya va maxfiylik',
        () => _open(SettingsPage.about),
      ),
    ];
  }

  Widget _group(List<Widget> children) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Glass(
        radius: 24,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        child: Column(mainAxisSize: MainAxisSize.min, children: children),
      ),
    );
  }

  Widget _switch(
    String title,
    String? subtitle,
    bool value,
    ValueChanged<bool> onChanged,
  ) {
    return SwitchListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(title),
      subtitle: subtitle == null ? null : Text(subtitle),
      value: value,
      onChanged: onChanged,
    );
  }

  Widget _flagSwitch(String title, String? subtitle, String key) {
    final settings = AppSettings.instance;
    return _switch(
      title,
      subtitle,
      settings.flag(key),
      (v) => settings.setFlag(key, v),
    );
  }

  Widget _card(Widget child) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: Glass(
        radius: 24,
        padding: const EdgeInsets.all(16),
        child: SizedBox(width: double.infinity, child: child),
      ),
    );
  }

  List<Widget> _look(AppSettings settings) {
    return [
      const _SectionTitle('Til'),
      _card(
        SegmentedButton<String>(
          showSelectedIcon: false,
          segments: const <ButtonSegment<String>>[
            ButtonSegment(value: 'uz', label: Text("O'zbekcha")),
            ButtonSegment(value: 'en', label: Text('English')),
            ButtonSegment(value: 'ru', label: Text('Русский')),
          ],
          selected: {settings.language},
          onSelectionChanged: (value) =>
              settings.update(() => settings.language = value.first),
        ),
      ),
      const _SectionTitle('Mavzu'),
      _card(
        SegmentedButton<ThemeMode>(
          showSelectedIcon: false,
          segments: const <ButtonSegment<ThemeMode>>[
            ButtonSegment(value: ThemeMode.system, label: Text('Tizim')),
            ButtonSegment(value: ThemeMode.light, label: Text("Yorug'")),
            ButtonSegment(value: ThemeMode.dark, label: Text("Qorong'i")),
          ],
          selected: {settings.themeMode},
          onSelectionChanged: (value) =>
              settings.update(() => settings.themeMode = value.first),
        ),
      ),
      const _SectionTitle('Rang uslubi'),
      _card(const PalettePicker()),
      const _SectionTitle('Effektlar'),
      _group([
        _switch(
          'Shisha effekti',
          "Shaffof kartalar va xira fon. Sekin telefonda o'chiring",
          settings.glass,
          (v) => settings.update(() => settings.glass = v),
        ),
        _flagSwitch(
          "O'qish ekranida gradient fon",
          "Matn o'qish ekranida yumshoq rangli fon",
          'readerGradient',
        ),
      ]),
      const _SectionTitle("Fayllar ro'yxati"),
      _card(
        SegmentedButton<bool>(
          showSelectedIcon: false,
          segments: const <ButtonSegment<bool>>[
            ButtonSegment(
              value: false,
              icon: Icon(Icons.view_agenda_outlined),
              label: Text("Ro'yxat"),
            ),
            ButtonSegment(
              value: true,
              icon: Icon(Icons.grid_view_rounded),
              label: Text('Setka'),
            ),
          ],
          selected: {settings.gridView},
          onSelectionChanged: (v) => settings.setFlag('gridView', v.first),
        ),
      ),
    ];
  }

  List<Widget> _homePage(AppSettings settings) {
    return [
      const _SectionTitle("Bosh sahifa bo'limlari"),
      _group([
        _flagSwitch(
          "So'nggi fayllar doiralari",
          "Tepada yumaloq belgilar qatori",
          'showStories',
        ),
        _flagSwitch(
          "'Davom etish' kartasi",
          "Oxirgi ochilgan faylni davom ettirish",
          'showHero',
        ),
        _flagSwitch(
          'Tezkor plitkalar',
          "Fayl qo'shish, sevimlilar va boshqalar",
          'showTiles',
        ),
        _flagSwitch(
          'Fayl turlari qatori',
          'PDF, Word va boshqa turlar bo\'yicha sanoq',
          'showKinds',
        ),
        _flagSwitch(
          "So'nggi qo'shilganlar",
          "Bosh sahifada oxirgi fayllar ro'yxati",
          'showRecent',
        ),
      ]),
      const _SectionTitle('Pastki menyu'),
      _group([
        _flagSwitch(
          "'Sevimlilar' bo'limi",
          "Pastki menyuda alohida bo'lim sifatida",
          'navFavorites',
        ),
      ]),
      Row(
        children: [
          Expanded(
            child: FilledButton.tonalIcon(
              onPressed: () => settings.setHomeSections(true),
              icon: const Icon(Icons.visibility_rounded),
              label: const Text('Hammasini yoqish'),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: OutlinedButton.icon(
              onPressed: () => settings.setHomeSections(false),
              icon: const Icon(Icons.visibility_off_rounded),
              label: const Text("Hammasini o'chirish"),
            ),
          ),
        ],
      ),
    ];
  }

  List<Widget> _general(AppSettings settings) {
    const names = <String>[
      "Qo'shilgan vaqti",
      'Oxirgi ochilgan',
      "Nomi bo'yicha",
      "Hajmi bo'yicha",
    ];
    return [
      const _SectionTitle('Standart saralash'),
      _card(
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (var i = 0; i < names.length; i++)
              ChoiceChip(
                label: Text(names[i]),
                selected: settings.sortMode == i,
                onSelected: (_) => settings.update(() => settings.sortMode = i),
              ),
          ],
        ),
      ),
      const _SectionTitle('Xatti-harakatlar'),
      _group([
        _flagSwitch(
          'Tebranish javobi',
          'Tanlash va menyuda yengil tebranish',
          'haptics',
        ),
        _flagSwitch(
          "O'chirishdan oldin so'rash",
          "Faylni o'chirishda tasdiq oynasi chiqadi",
          'confirmDelete',
        ),
      ]),
      const _SectionTitle('Qayta tiklash'),
      _group([
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.settings_backup_restore_rounded),
          title: const Text('Sozlamalarni standart holatga qaytarish'),
          subtitle: const Text("Fayllar, til va PIN kod o'zgarmaydi"),
          onTap: _resetDefaults,
        ),
      ]),
    ];
  }

  Future<void> _resetDefaults() async {
    final ok = await confirmDialog(
      context,
      title: 'Sozlamalarni qaytarasizmi?',
      message: "Rang, mavzu, o'qish va bosh sahifa sozlamalari standart holatga qaytadi.",
      confirm: 'Qaytarish',
    );
    if (!ok) return;
    AppSettings.instance.resetDefaults();
    _snack('Sozlamalar standart holatga qaytdi');
  }

  List<Widget> _security(LockService lock) {
    return [
      _group([
        _switch(
          'Ilova qulfi (PIN)',
          "Ilova ochilganda PIN kod so'raladi",
          lock.enabled,
          _toggleLock,
        ),
        if (lock.enabled)
          _switch(
            'Barmoq izi bilan ochish',
            "PIN o'rniga biometrik tekshiruv",
            lock.bioEnabled,
            _toggleBio,
          ),
        if (lock.enabled)
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.pin_outlined),
            title: const Text("PIN kodni o'zgartirish"),
            onTap: _changePin,
          ),
      ]),
    ];
  }

  List<Widget> _data() {
    return [
      const _SectionTitle('Zaxira nusxa'),
      _group([
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.backup_outlined),
          title: const Text('Zaxira nusxa yaratish'),
          subtitle: const Text(
            "Fayllar, xatcho'plar, sevimlilar va sozlamalar bitta ZIP faylga yig'iladi",
          ),
          onTap: _working ? null : _backup,
        ),
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.restore_outlined),
          title: const Text('Zaxiradan tiklash'),
          onTap: _working ? null : _restore,
        ),
      ]),
      const _SectionTitle('Xotira'),
      _group([
        FutureBuilder<int>(
          future: _size,
          builder: (context, snap) {
            final text = snap.hasData
                ? 'Kutubxona hajmi: ${formatSize(snap.data!)}'
                : 'Kutubxona hajmi hisoblanmoqda...';
            return ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.storage_outlined),
              title: Text(text),
            );
          },
        ),
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.cleaning_services_outlined),
          title: const Text('Vaqtinchalik fayllarni tozalash'),
          subtitle: const Text('Arxivdan chiqarilgan vaqtinchalik fayllar'),
          onTap: _clearCache,
        ),
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.delete_forever_outlined),
          title: const Text("Barcha fayllarni o'chirish"),
          onTap: _deleteAll,
        ),
      ]),
    ];
  }

  List<Widget> _about() {
    return [
      _group([
        const ListTile(
          contentPadding: EdgeInsets.zero,
          leading: Icon(Icons.auto_stories_rounded),
          title: Text("Reklamasiz Fayl O'quvchi 3.9"),
          subtitle: Text("PDF, Office, ePub, TXT va arxivlarni o'qish"),
        ),
        const ListTile(
          contentPadding: EdgeInsets.zero,
          leading: Icon(Icons.wifi_off_rounded),
          title: Text('Internetga ulanmaydi'),
          subtitle: Text("Ilova hech qanday ma'lumotni tarmoqqa yubormaydi"),
        ),
        const ListTile(
          contentPadding: EdgeInsets.zero,
          leading: Icon(Icons.block_rounded),
          title: Text("Reklama va kuzatuv yo'q"),
          subtitle: Text('Fayllar faqat telefoningizda saqlanadi'),
        ),
      ]),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final settings = AppSettings.instance;
    final lock = LockService.instance;
    final menu = widget.page == SettingsPage.menu;

    final scaffold = Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(title: Text(_title(widget.page))),
      body: ContentWidth(
        child: AnimatedBuilder(
          animation: Listenable.merge(<Listenable>[settings, lock]),
          builder: (context, _) {
            final List<Widget> children = switch (widget.page) {
              SettingsPage.menu => _menu(),
              SettingsPage.look => _look(settings),
              SettingsPage.home => _homePage(settings),
              SettingsPage.reading => [_card(const ReaderControls())],
              SettingsPage.general => _general(settings),
              SettingsPage.security => _security(lock),
              SettingsPage.data => _data(),
              SettingsPage.about => _about(),
            };

            return ListView(
              padding: EdgeInsets.fromLTRB(16, 8, 16, menu ? 130 : 40),
              children: [
                if (_working) const LinearProgressIndicator(),
                ...children,
              ],
            );
          },
        ),
      ),
    );

    return menu ? scaffold : GradientBackground(child: scaffold);
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        text,
        style: Theme.of(context).textTheme.labelLarge?.copyWith(
              fontWeight: FontWeight.w800,
              letterSpacing: 0.8,
              color: Theme.of(context).colorScheme.primary,
            ),
      ),
    );
  }
}

/// O'qish sozlamalari: rang, shrift, o'lcham, qator oralig'i, ekran o'chmasligi.
/// Sozlamalar ekranida ham, o'qish paytidagi pastki oynada ham ishlatiladi.
class ReaderControls extends StatelessWidget {
  const ReaderControls({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = AppSettings.instance;

    return AnimatedBuilder(
      animation: settings,
      builder: (context, _) {
        final theme = Theme.of(context);
        final previewStyle = TextStyle(
          fontSize: settings.fontSize,
          height: settings.lineHeight,
          fontFamily: settings.fontFamily,
          color: settings.foreground ?? theme.colorScheme.onSurface,
        );

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Sahifa rangi'),
            const SizedBox(height: 8),
            SegmentedButton<ReaderTheme>(
              showSelectedIcon: false,
              segments: const <ButtonSegment<ReaderTheme>>[
                ButtonSegment(value: ReaderTheme.auto, label: Text('Oddiy')),
                ButtonSegment(value: ReaderTheme.sepia, label: Text('Sepiya')),
              ],
              selected: {settings.readerTheme},
              onSelectionChanged: (value) =>
                  settings.update(() => settings.readerTheme = value.first),
            ),
            const SizedBox(height: 16),
            const Text('Shrift'),
            const SizedBox(height: 8),
            SegmentedButton<ReaderFont>(
              showSelectedIcon: false,
              segments: const <ButtonSegment<ReaderFont>>[
                ButtonSegment(value: ReaderFont.sans, label: Text('Oddiy')),
                ButtonSegment(value: ReaderFont.serif, label: Text('Serif')),
                ButtonSegment(value: ReaderFont.mono, label: Text('Mono')),
              ],
              selected: {settings.readerFont},
              onSelectionChanged: (value) =>
                  settings.update(() => settings.readerFont = value.first),
            ),
            const SizedBox(height: 16),
            Text("Shrift o'lchami: ${settings.fontSize.round()}"),
            Slider(
              value: settings.fontSize.clamp(12.0, 40.0).toDouble(),
              min: 12,
              max: 40,
              divisions: 14,
              onChanged: (v) =>
                  settings.update(() => settings.fontSize = v.roundToDouble()),
            ),
            Text(
              "Qator oralig'i: ${settings.lineHeight.toStringAsFixed(2)}",
            ),
            Slider(
              value: settings.lineHeight.clamp(1.2, 2.2).toDouble(),
              min: 1.2,
              max: 2.2,
              divisions: 10,
              onChanged: (v) => settings.update(
                () => settings.lineHeight = double.parse(v.toStringAsFixed(2)),
              ),
            ),
            Text("Ovoz tezligi: ${settings.ttsRate.toStringAsFixed(2)}"),
            Slider(
              value: settings.ttsRate.clamp(0.2, 1.0).toDouble(),
              min: 0.2,
              max: 1.0,
              divisions: 8,
              onChanged: (v) => settings.update(
                () => settings.ttsRate = double.parse(v.toStringAsFixed(2)),
              ),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text("Ekran o'chmasin"),
              subtitle: const Text("O'qiyotganda ekran avtomatik o'chmaydi"),
              value: settings.keepScreenOn,
              onChanged: (v) => settings.update(() => settings.keepScreenOn = v),
            ),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: settings.background ?? theme.colorScheme.secondaryContainer,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                "Namuna matn: Salom, dunyo! The quick brown fox 0123456789.",
                style: previewStyle,
              ),
            ),
          ],
        );
      },
    );
  }
}
