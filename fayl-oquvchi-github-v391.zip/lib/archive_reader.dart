import 'dart:io';
import 'dart:isolate';

import 'package:archive/archive.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

enum ArchiveFormat { zip, tar, tarGz, tarBz2, gzip, bzip2, rar, sevenZip }

ArchiveFormat? archiveFormatOf(String path) {
  final n = path.toLowerCase();
  if (n.endsWith('.tar.gz') || n.endsWith('.tgz')) return ArchiveFormat.tarGz;
  if (n.endsWith('.tar.bz2') || n.endsWith('.tbz2')) return ArchiveFormat.tarBz2;

  switch (p.extension(n)) {
    case '.zip':
      return ArchiveFormat.zip;
    case '.tar':
      return ArchiveFormat.tar;
    case '.gz':
      return ArchiveFormat.gzip;
    case '.bz2':
      return ArchiveFormat.bzip2;
    case '.rar':
      return ArchiveFormat.rar;
    case '.7z':
      return ArchiveFormat.sevenZip;
    default:
      return null;
  }
}

bool isInAppArchive(ArchiveFormat f) =>
    f != ArchiveFormat.rar && f != ArchiveFormat.sevenZip;

class ArchiveEntry {
  final String name;
  final int size;

  const ArchiveEntry(this.name, this.size);

  String get baseName => p.posix.basename(name);
}

const _maxArchiveBytes = 300 * 1024 * 1024;

class ArchiveReader {
  ArchiveReader._();

  static Archive _open(String path, ArchiveFormat format, String? password) {
    final file = File(path);
    if (file.lengthSync() > _maxArchiveBytes) {
      throw const FormatException(
        "Arxiv juda katta (300 MB dan oshmasligi kerak)",
      );
    }

    final bytes = file.readAsBytesSync();

    try {
      switch (format) {
        case ArchiveFormat.zip:
          return ZipDecoder().decodeBytes(bytes, password: password);
        case ArchiveFormat.tar:
          return TarDecoder().decodeBytes(bytes);
        case ArchiveFormat.tarGz:
          return TarDecoder().decodeBytes(GZipDecoder().decodeBytes(bytes));
        case ArchiveFormat.tarBz2:
          return TarDecoder().decodeBytes(BZip2Decoder().decodeBytes(bytes));
        case ArchiveFormat.gzip:
          return _single(path, GZipDecoder().decodeBytes(bytes));
        case ArchiveFormat.bzip2:
          return _single(path, BZip2Decoder().decodeBytes(bytes));
        case ArchiveFormat.rar:
        case ArchiveFormat.sevenZip:
          throw UnsupportedError('RAR va 7z ilova ichida ochilmaydi');
      }
    } catch (e) {
      if (e is UnsupportedError) rethrow;
      final msg = e.toString().toLowerCase();
      if (msg.contains('aes') || msg.contains('encrypt')) {
        throw const FormatException(
          "Arxiv AES bilan shifrlangan. Bunday arxivni tashqi ilovada oching.",
        );
      }
      throw FormatException('Arxiv buzilgan yoki parol bilan himoyalangan: $e');
    }
  }

  static Archive _single(String path, List<int> data) {
    final name = p.basenameWithoutExtension(path);
    return Archive()..addFile(ArchiveFile(name, data.length, data));
  }

  static Future<List<ArchiveEntry>> list(
    String path,
    ArchiveFormat format, {
    String? password,
  }) async {
    // Og'ir ish alohida isolate'da bajariladi, shuning uchun ekran qotmaydi
    return Isolate.run(() => _listSync(path, format, password));
  }

  static List<ArchiveEntry> _listSync(
    String path,
    ArchiveFormat format,
    String? password,
  ) {
    final archive = _open(path, format, password);
    return [
      for (final f in archive.files)
        if (f.isFile) ArchiveEntry(f.name, f.size),
    ]..sort((a, b) => a.name.compareTo(b.name));
  }

  static List<int> _extractSync(
    String path,
    ArchiveFormat format,
    String name,
    String? password,
  ) {
    final archive = _open(path, format, password);
    final found = archive.findFile(name);
    if (found == null) {
      throw const FormatException("Fayl arxivda topilmadi");
    }
    try {
      return found.content as List<int>;
    } catch (_) {
      throw const FormatException(
        "Faylni chiqarib bo'lmadi. Parol noto'g'ri yoki arxiv buzilgan.",
      );
    }
  }

  static Future<File> extractEntry(
    String archivePath,
    ArchiveFormat format,
    ArchiveEntry entry, {
    String? password,
  }) async {
    final name = entry.name;
    final content = await Isolate.run(
      () => _extractSync(archivePath, format, name, password),
    );
    final dir = await _cacheDir();
    final stamp = DateTime.now().microsecondsSinceEpoch;

    // Alohida papkada toza nom bilan saqlanadi, shunda kutubxonaga qo'shilganda
    // fayl nomiga ortiqcha raqamlar qo'shilib qolmaydi
    final sub = Directory(p.join(dir.path, '$stamp'));
    await sub.create(recursive: true);
    final dest = File(p.join(sub.path, _safeName(entry.baseName)));
    await dest.writeAsBytes(content);
    return dest;
  }

  /// Bir nechta faylni arxivni bir marta ochib chiqaradi.
  static Future<List<File>> extractAll(
    String archivePath,
    ArchiveFormat format,
    List<ArchiveEntry> entries, {
    String? password,
  }) async {
    final dir = await _cacheDir();
    final batch = p.join(dir.path, '${DateTime.now().microsecondsSinceEpoch}');
    final names = [for (final e in entries) e.name];

    final paths = await Isolate.run(
      () => _extractAllSync(archivePath, format, names, password, batch),
    );
    return [for (final path in paths) File(path)];
  }

  static List<String> _extractAllSync(
    String archivePath,
    ArchiveFormat format,
    List<String> names,
    String? password,
    String batchDir,
  ) {
    final archive = _open(archivePath, format, password);
    Directory(batchDir).createSync(recursive: true);

    final result = <String>[];
    final used = <String>{};

    for (final name in names) {
      final found = archive.findFile(name);
      if (found == null) continue;

      try {
        final content = found.content as List<int>;
        final clean = _safeName(p.posix.basename(name));

        var unique = clean;
        var n = 1;
        while (!used.add(unique.toLowerCase())) {
          unique = '${p.basenameWithoutExtension(clean)} ($n)${p.extension(clean)}';
          n++;
        }

        final dest = File(p.join(batchDir, unique));
        dest.writeAsBytesSync(content);
        result.add(dest.path);
      } catch (_) {
        // Bitta faylni chiqarib bo'lmasa, qolganlari davom ettiriladi
      }
    }
    return result;
  }

  static Future<Directory> _cacheDir() async {
    final base = await getTemporaryDirectory();
    final dir = Directory(p.join(base.path, 'archive_cache'));
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir;
  }

  /// Vaqtinchalik fayllar papkasi (hujjat ichidagi rasm/video/audio ham shu yerda).
  static Future<Directory> cacheDirectory() => _cacheDir();

  static Future<void> clearCache() async {
    final dir = await _cacheDir();
    await for (final entity in dir.list()) {
      await entity.delete(recursive: true);
    }
  }

  static String _safeName(String name) {
    final cleaned = name.replaceAll(RegExp(r'[\\/:*?"<>|\x00-\x1F]'), '_').trim();
    return cleaned.isEmpty ? 'file' : cleaned;
  }
}
