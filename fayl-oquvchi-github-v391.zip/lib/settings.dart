import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum ReaderTheme { auto, sepia }

enum ReaderFont { sans, serif, mono }

/// Ilova sozlamalari. O'zgarganda tinglovchilarga xabar beradi va xotiraga saqlaydi.
class AppSettings extends ChangeNotifier {
  AppSettings._();
  static final AppSettings instance = AppSettings._();

  SharedPreferences? _prefs;

  ThemeMode themeMode = ThemeMode.system;
  double fontSize = 16.0;
  double lineHeight = 1.55;
  bool keepScreenOn = false;
  ReaderTheme readerTheme = ReaderTheme.auto;
  ReaderFont readerFont = ReaderFont.sans;
  bool pdfNightMode = false;
  bool pdfHorizontal = false;
  double ttsRate = 0.5;
  String language = 'uz';
  int palette = 0;
  bool glass = true;
  int sortMode = 0;

  /// Yoqish/o'chirish kalitlari va ularning standart qiymatlari.
  static const Map<String, bool> flagDefaults = <String, bool>{
    'showStories': true,
    'showHero': true,
    'showTiles': true,
    'showKinds': true,
    'showRecent': true,
    'navFavorites': true,
    'gridView': false,
    'haptics': true,
    'confirmDelete': true,
    'readerGradient': true,
  };

  final Map<String, bool> _flags = Map<String, bool>.of(flagDefaults);

  bool flag(String key) => _flags[key] ?? flagDefaults[key] ?? false;

  void setFlag(String key, bool value) => update(() => _flags[key] = value);

  static int _index(int? value, int length) =>
      (value != null && value >= 0 && value < length) ? value : 0;

  Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _prefs = prefs;
      themeMode = ThemeMode
          .values[_index(prefs.getInt('themeMode'), ThemeMode.values.length)];
      fontSize = (prefs.getDouble('fontSize') ?? 16.0).clamp(12.0, 40.0).toDouble();
      lineHeight =
          (prefs.getDouble('lineHeight') ?? 1.55).clamp(1.2, 2.2).toDouble();
      keepScreenOn = prefs.getBool('keepScreenOn') ?? false;
      readerTheme = ReaderTheme.values[
          _index(prefs.getInt('readerTheme'), ReaderTheme.values.length)];
      readerFont = ReaderFont
          .values[_index(prefs.getInt('readerFont'), ReaderFont.values.length)];
      pdfNightMode = prefs.getBool('pdfNightMode') ?? false;
      pdfHorizontal = prefs.getBool('pdfHorizontal') ?? false;
      ttsRate = (prefs.getDouble('ttsRate') ?? 0.5).clamp(0.2, 1.0).toDouble();
      palette = _index(prefs.getInt('palette'), 6);
      glass = prefs.getBool('glass') ?? true;
      sortMode = _index(prefs.getInt('sortMode'), 4);
      for (final key in flagDefaults.keys) {
        _flags[key] = prefs.getBool(key) ?? flagDefaults[key]!;
      }
      final lang = prefs.getString('language');
      language = (lang == 'en' || lang == 'ru') ? lang! : 'uz';
    } catch (_) {
      // Sozlamalar o'qilmasa, standart qiymatlar ishlatiladi
    }
  }

  Future<void> _save() async {
    final prefs = _prefs;
    if (prefs == null) return;
    try {
      await prefs.setInt('themeMode', themeMode.index);
      await prefs.setDouble('fontSize', fontSize);
      await prefs.setDouble('lineHeight', lineHeight);
      await prefs.setBool('keepScreenOn', keepScreenOn);
      await prefs.setInt('readerTheme', readerTheme.index);
      await prefs.setInt('readerFont', readerFont.index);
      await prefs.setBool('pdfNightMode', pdfNightMode);
      await prefs.setBool('pdfHorizontal', pdfHorizontal);
      await prefs.setDouble('ttsRate', ttsRate);
      await prefs.setString('language', language);
      await prefs.setInt('palette', palette);
      await prefs.setBool('glass', glass);
      await prefs.setInt('sortMode', sortMode);
      for (final entry in _flags.entries) {
        await prefs.setBool(entry.key, entry.value);
      }
    } catch (_) {
      // Saqlab bo'lmasa, sozlama faqat joriy sessiyada ishlaydi
    }
  }

  /// Saqlangan sozlamalarni qayta o'qiydi (zaxiradan tiklagandan keyin).
  Future<void> reload() async {
    await load();
    notifyListeners();
  }

  /// Bosh sahifa bo'limlarini birdan yoqadi yoki o'chiradi.
  void setHomeSections(bool on) => update(() {
        for (final key in const [
          'showStories', 'showHero', 'showTiles', 'showKinds', 'showRecent',
        ]) {
          _flags[key] = on;
        }
      });

  /// Barcha sozlamalarni standart holatga qaytaradi (til va PIN saqlanadi).
  void resetDefaults() => update(() {
        themeMode = ThemeMode.system;
        fontSize = 16.0;
        lineHeight = 1.55;
        keepScreenOn = false;
        readerTheme = ReaderTheme.auto;
        readerFont = ReaderFont.sans;
        pdfNightMode = false;
        pdfHorizontal = false;
        ttsRate = 0.5;
        palette = 0;
        glass = true;
        sortMode = 0;
        _flags
          ..clear()
          ..addAll(flagDefaults);
      });

  /// Sozlamani o'zgartiradi, ekranlarni yangilaydi va saqlaydi.
  void update(VoidCallback change) {
    change();
    notifyListeners();
    _save();
  }
}

extension HomeFlags on AppSettings {
  bool get showStories => flag('showStories');
  bool get showHero => flag('showHero');
  bool get showTiles => flag('showTiles');
  bool get showKinds => flag('showKinds');
  bool get showRecent => flag('showRecent');
  bool get navFavorites => flag('navFavorites');
  bool get gridView => flag('gridView');
  bool get haptics => flag('haptics');
  bool get confirmDelete => flag('confirmDelete');
  bool get readerGradient => flag('readerGradient');
}

extension ReaderLook on AppSettings {
  String? get fontFamily {
    switch (readerFont) {
      case ReaderFont.sans:
        return null;
      case ReaderFont.serif:
        return 'serif';
      case ReaderFont.mono:
        return 'monospace';
    }
  }

  Color? get background =>
      readerTheme == ReaderTheme.sepia ? const Color(0xFFF4ECD8) : null;

  Color? get foreground =>
      readerTheme == ReaderTheme.sepia ? const Color(0xFF3B2F20) : null;
}
