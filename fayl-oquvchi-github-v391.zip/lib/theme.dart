import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart' hide Text;

import 'document_parser.dart';
import 'l10n.dart';
import 'settings.dart';

/// Rang uslubi: asosiy rang, fon gradienti va bosh karta ranglari.
class AppPalette {
  final String name;
  final Color seed;
  final List<Color> light;
  final List<Color> dark;
  final Color heroA;
  final Color heroB;

  const AppPalette(
    this.name,
    this.seed,
    this.light,
    this.dark,
    this.heroA,
    this.heroB,
  );

  static const List<AppPalette> all = <AppPalette>[
    AppPalette(
      'Okean',
      Color(0xFF1E6FE0),
      [Color(0xFFDCE8FF), Color(0xFFEAEBFF), Color(0xFFD8F4EC)],
      [Color(0xFF0A1630), Color(0xFF101A3C), Color(0xFF09272C)],
      Color(0xFF2F82EA),
      Color(0xFF1553B8),
    ),
    AppPalette(
      'Indigo',
      Color(0xFF4F46E5),
      [Color(0xFFE8E6FF), Color(0xFFF1E9FF), Color(0xFFDFEFFF)],
      [Color(0xFF110F2D), Color(0xFF1A1240), Color(0xFF0D1B33)],
      Color(0xFF6D6CF3),
      Color(0xFF4338CA),
    ),
    AppPalette(
      'Zumrad',
      Color(0xFF0F9D6B),
      [Color(0xFFDDF6EA), Color(0xFFE6F6F6), Color(0xFFF0F8E2)],
      [Color(0xFF06231A), Color(0xFF0A2B2B), Color(0xFF12261A)],
      Color(0xFF1BB784),
      Color(0xFF0B7A5A),
    ),
    AppPalette(
      'Shafaq',
      Color(0xFFF4602E),
      [Color(0xFFFFE6DA), Color(0xFFFFE0EB), Color(0xFFFFF2D8)],
      [Color(0xFF2B1209), Color(0xFF301220), Color(0xFF2A2008)],
      Color(0xFFFF7A45),
      Color(0xFFE8423F),
    ),
    AppPalette(
      'Atirgul',
      Color(0xFFD6336C),
      [Color(0xFFFFE0EC), Color(0xFFF5E3FF), Color(0xFFFFE9F1)],
      [Color(0xFF2D0F1C), Color(0xFF261030), Color(0xFF2A1024)],
      Color(0xFFEC4899),
      Color(0xFFBE185D),
    ),
    AppPalette(
      'Grafit',
      Color(0xFF475569),
      [Color(0xFFE7EBF0), Color(0xFFF1F3F6), Color(0xFFE5E9ED)],
      [Color(0xFF0F1115), Color(0xFF15181D), Color(0xFF101216)],
      Color(0xFF516070),
      Color(0xFF1F2937),
    ),
  ];

  static AppPalette get current {
    final i = AppSettings.instance.palette;
    return all[(i >= 0 && i < all.length) ? i : 0];
  }

  LinearGradient get heroGradient => LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [heroA, heroB],
      );
}

/// Ilovaning yagona ko'rinishi: ranglar, shakllar va fayl turlari ranglari.
class AppTheme {
  AppTheme._();

  static ThemeData build(Brightness brightness) {
    final dark = brightness == Brightness.dark;
    final palette = AppPalette.current;
    final scheme = ColorScheme.fromSeed(
      seedColor: palette.seed,
      brightness: brightness,
    );

    final fieldBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: BorderSide(color: scheme.outlineVariant),
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor:
          dark ? scheme.surface : scheme.surfaceContainerLowest,
      splashFactory: InkSparkle.splashFactory,
      appBarTheme: AppBarTheme(
        centerTitle: false,
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        foregroundColor: scheme.onSurface,
        titleTextStyle: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.2,
          color: scheme.onSurface,
        ),
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        elevation: 3,
        highlightElevation: 5,
        backgroundColor: scheme.primary,
        foregroundColor: scheme.onPrimary,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size(64, 48),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      chipTheme: ChipThemeData(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        side: BorderSide(color: scheme.outlineVariant.withAlpha(140)),
        showCheckmark: false,
        labelStyle: const TextStyle(fontWeight: FontWeight.w600),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: scheme.surfaceContainerHighest.withAlpha(dark ? 90 : 120),
        border: fieldBorder,
        enabledBorder: fieldBorder,
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: scheme.primary, width: 1.6),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      popupMenuTheme: PopupMenuThemeData(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        color: scheme.surfaceContainerHigh,
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        showDragHandle: true,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
      ),
      listTileTheme: ListTileThemeData(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        linearMinHeight: 4,
      ),
      dividerTheme: DividerThemeData(
        color: scheme.outlineVariant.withAlpha(120),
        space: 1,
      ),
    );
  }

  /// Fayl turining asosiy rangi.
  static Color kindColor(DocKind kind) => switch (kind) {
        DocKind.pdf => const Color(0xFFE53935),
        DocKind.text => const Color(0xFF546E7A),
        DocKind.html => const Color(0xFFF57C00),
        DocKind.docx => const Color(0xFF2B6CD4),
        DocKind.xlsx => const Color(0xFF1E8E55),
        DocKind.pptx => const Color(0xFFD9542B),
        DocKind.epub => const Color(0xFF8E44AD),
        DocKind.archive => const Color(0xFFB8860B),
        DocKind.external => const Color(0xFF78909C),
      };

  /// Fayl turining qisqa belgisi (ikonka tagidagi yozuv).
  static String kindTag(DocKind kind) => switch (kind) {
        DocKind.pdf => 'PDF',
        DocKind.text => 'TXT',
        DocKind.html => 'HTML',
        DocKind.docx => 'DOC',
        DocKind.xlsx => 'XLS',
        DocKind.pptx => 'PPT',
        DocKind.epub => 'EPUB',
        DocKind.archive => 'ZIP',
        DocKind.external => 'FILE',
      };
}


// ====================== Shisha (glass) uslubi ======================

/// Yumshoq gradient fon va ikkita xira "yorug'lik" dog'i.
class GradientBackground extends StatelessWidget {
  final Widget child;
  const GradientBackground({super.key, required this.child});

  Widget _glow(Color color, double size) => IgnorePointer(
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(
              colors: [color.withAlpha(80), color.withAlpha(0)],
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppSettings.instance,
      builder: (context, _) {
        final dark = Theme.of(context).brightness == Brightness.dark;
        final palette = AppPalette.current;
        final colors = dark ? palette.dark : palette.light;

        return DecoratedBox(
          position: DecorationPosition.background,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: colors,
            ),
          ),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Positioned(top: -140, right: -100, child: _glow(palette.heroA, 340)),
              Positioned(bottom: -160, left: -120, child: _glow(palette.heroB, 360)),
              child,
            ],
          ),
        );
      },
    );
  }
}

/// Shaffof "shisha" karta. [blur] faqat ustidan kontent o'tadigan joylarda
/// (pastki menyu) yoqiladi, ro'yxatlarda tezlik uchun o'chiq turadi.
class Glass extends StatelessWidget {
  final Widget child;
  final double radius;
  final EdgeInsetsGeometry padding;
  final Color? tint;
  final Color? borderColor;
  final bool blur;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;

  const Glass({
    super.key,
    required this.child,
    this.radius = 24,
    this.padding = EdgeInsets.zero,
    this.tint,
    this.borderColor,
    this.blur = false,
    this.onTap,
    this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppSettings.instance,
      builder: (context, _) {
        final scheme = Theme.of(context).colorScheme;
        final dark = Theme.of(context).brightness == Brightness.dark;
        final glass = AppSettings.instance.glass;
        final shape = BorderRadius.circular(radius);

        final fill = tint ??
            (glass
                ? (dark ? Colors.white.withAlpha(20) : Colors.white.withAlpha(150))
                : (dark ? scheme.surfaceContainerHigh : Colors.white));
        final border = borderColor ??
            (glass
                ? (dark ? Colors.white.withAlpha(36) : Colors.white.withAlpha(200))
                : scheme.outlineVariant.withAlpha(120));

        Widget content = Material(
          type: MaterialType.transparency,
          child: InkWell(
            borderRadius: shape,
            onTap: onTap,
            onLongPress: onLongPress,
            child: Padding(padding: padding, child: child),
          ),
        );

        Widget body = DecoratedBox(
          decoration: BoxDecoration(
            color: fill,
            borderRadius: shape,
            border: Border.all(color: border, width: 1.2),
          ),
          child: content,
        );

        if (blur && glass) {
          body = ClipRRect(
            borderRadius: shape,
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
              child: body,
            ),
          );
        }

        return DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: shape,
            boxShadow: [
              BoxShadow(
                color: (dark ? Colors.black : scheme.primary).withAlpha(dark ? 70 : 28),
                blurRadius: 24,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: body,
        );
      },
    );
  }
}

/// Yumaloq shisha tugma (sarlavhadagi amallar uchun).
class GlassIconButton extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback onPressed;
  final Color? iconColor;

  const GlassIconButton({
    super.key,
    required this.icon,
    required this.tooltip,
    required this.onPressed,
    this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: t(tooltip),
      child: Glass(
        radius: 24,
        onTap: onPressed,
        child: SizedBox(
          width: 46,
          height: 46,
          child: Icon(icon, size: 22, color: iconColor),
        ),
      ),
    );
  }
}

class GlassNavItem {
  final IconData icon;
  final IconData selectedIcon;
  final String label;
  const GlassNavItem(this.icon, this.selectedIcon, this.label);
}

/// Pastdagi suzuvchi, yumaloq shisha menyu.
class GlassNavBar extends StatelessWidget {
  final List<GlassNavItem> items;
  final int index;
  final ValueChanged<int> onTap;

  const GlassNavBar({
    super.key,
    required this.items,
    required this.index,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        child: Glass(
          radius: 32,
          blur: true,
          padding: const EdgeInsets.all(6),
          child: Row(
            children: [
              for (var i = 0; i < items.length; i++)
                Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => onTap(i),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 220),
                      curve: Curves.easeOut,
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(26),
                        color: i == index
                            ? scheme.primary.withAlpha(36)
                            : Colors.transparent,
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            i == index ? items[i].selectedIcon : items[i].icon,
                            size: 26,
                            color: i == index
                                ? scheme.primary
                                : scheme.onSurfaceVariant,
                          ),
                          const SizedBox(height: 2),
                          Text(
                            items[i].label,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 11.5,
                              fontWeight:
                                  i == index ? FontWeight.w800 : FontWeight.w500,
                              color: i == index
                                  ? scheme.primary
                                  : scheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Rang uslubini tanlash (doiralar).
class PalettePicker extends StatelessWidget {
  const PalettePicker({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = AppSettings.instance;
    final scheme = Theme.of(context).colorScheme;

    return ListenableBuilder(
      listenable: settings,
      builder: (context, _) {
        return Wrap(
          spacing: 14,
          runSpacing: 14,
          children: [
            for (var i = 0; i < AppPalette.all.length; i++)
              GestureDetector(
                onTap: () => settings.update(() => settings.palette = i),
                child: SizedBox(
                  width: 64,
                  child: Column(
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: AppPalette.all[i].heroGradient,
                          border: Border.all(
                            color: settings.palette == i
                                ? scheme.onSurface
                                : Colors.transparent,
                            width: 2.5,
                          ),
                        ),
                        child: settings.palette == i
                            ? const Icon(Icons.check_rounded, color: Colors.white)
                            : null,
                      ),
                      const SizedBox(height: 6),
                      Text(
                        AppPalette.all[i].name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 12),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

/// "Ko'rinish" oynasi: mavzu rejimi, rang uslubi va shisha effekti.
void showAppearanceSheet(BuildContext context) {
  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (_) => const _AppearanceSheet(),
  );
}

class _AppearanceSheet extends StatelessWidget {
  const _AppearanceSheet();

  @override
  Widget build(BuildContext context) {
    final settings = AppSettings.instance;

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
        child: ListenableBuilder(
          listenable: settings,
          builder: (context, _) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  "Ko'rinish",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 16),
                SegmentedButton<ThemeMode>(
                  showSelectedIcon: false,
                  segments: const <ButtonSegment<ThemeMode>>[
                    ButtonSegment(value: ThemeMode.system, label: Text('Tizim')),
                    ButtonSegment(value: ThemeMode.light, label: Text("Yorug'")),
                    ButtonSegment(value: ThemeMode.dark, label: Text("Qorong'i")),
                  ],
                  selected: {settings.themeMode},
                  onSelectionChanged: (v) =>
                      settings.update(() => settings.themeMode = v.first),
                ),
                const SizedBox(height: 20),
                const Text(
                  'Rang uslubi',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 12),
                const PalettePicker(),
                const SizedBox(height: 8),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Shisha effekti'),
                  subtitle: const Text("Shaffof kartalar va xira fon. Sekin telefonda o'chiring"),
                  value: settings.glass,
                  onChanged: (v) => settings.update(() => settings.glass = v),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

/// Fayl turi uchun yumaloq, rangli ikonka belgisi.
class KindBadge extends StatelessWidget {
  final DocKind kind;
  final IconData icon;
  final bool selected;
  final double size;

  const KindBadge({
    super.key,
    required this.kind,
    required this.icon,
    this.selected = false,
    this.size = 52,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final color = AppTheme.kindColor(kind);

    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: selected ? scheme.primary : color.withAlpha(34),
        borderRadius: BorderRadius.circular(size * 0.3),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            selected ? Icons.check_rounded : icon,
            size: size * 0.42,
            color: selected ? scheme.onPrimary : color,
          ),
          if (!selected)
            Text(
              AppTheme.kindTag(kind),
              style: TextStyle(
                fontSize: 9,
                height: 1.1,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.4,
                color: color,
              ),
            ),
        ],
      ),
    );
  }
}

/// Keng ekranlarda (planshet) tarkibni o'rtada, qulay kenglikda ushlab turadi.
class ContentWidth extends StatelessWidget {
  final Widget child;
  final double maxWidth;
  const ContentWidth({super.key, required this.child, this.maxWidth = 760});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxWidth),
        child: child,
      ),
    );
  }
}
