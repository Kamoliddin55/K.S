import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/gestures.dart';
import 'package:flutter/services.dart';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/widgets.dart' as fw show Text;
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import 'package:share_plus/share_plus.dart';

import 'archive_reader.dart';
import 'dialogs.dart';
import 'docx_model.dart';
import 'l10n.dart';
import 'library.dart';
import 'text_screen.dart';
import 'user_data.dart';

/// Ro'yxatdagi bitta element: abzas, jadval qatori yoki sahifa uzilishi.
class _Item {
  final DPara? para;
  final DTable? table;
  final int row;
  final bool pageBreak;
  const _Item({this.para, this.table, this.row = 0, this.pageBreak = false});

  String get plain {
    final pr = para;
    if (pr != null) return pr.plain;
    final t = table;
    if (t == null || row >= t.rows.length) return '';
    final sb = StringBuffer();
    for (final c in t.rows[row]) {
      sb.write(_blocksPlain(c.blocks));
      sb.write('\t');
    }
    return sb.toString();
  }
}

String _blocksPlain(List<DBlock> blocks) {
  final sb = StringBuffer();
  for (final b in blocks) {
    if (b is DPara) {
      sb.write(b.plain);
      sb.write(' ');
    } else if (b is DTable) {
      for (final r in b.rows) {
        for (final c in r) {
          sb.write(_blocksPlain(c.blocks));
          sb.write(' ');
        }
      }
    }
  }
  return sb.toString();
}

class WordScreen extends StatefulWidget {
  final String path;
  const WordScreen({super.key, required this.path});

  @override
  State<WordScreen> createState() => _WordScreenState();
}

class _WordScreenState extends State<WordScreen> {
  final _data = UserData.instance;
  final _itemScroll = ItemScrollController();
  final _positions = ItemPositionsListener.create();
  final _searchController = TextEditingController();
  final _searchFocus = FocusNode();

  late final String _key;
  late final bool _persist;

  DDoc? _doc;
  List<_Item> _items = const <_Item>[];
  List<int> _headings = const <int>[];
  String? _error;
  bool _loading = true;
  int _start = 0;
  Timer? _saveTimer;
  int _top = 0;

  bool _print = true;
  double _zoom = 1;

  bool _searching = false;
  String _query = '';
  RegExp? _regex;
  List<int> _matches = const <int>[];
  int _matchPos = -1;

  final Map<int, Offset> _pointers = <int, Offset>{};
  double? _pinchStart;
  double _pinchBase = 1;

  @override
  void initState() {
    super.initState();
    _key = p.basename(widget.path);
    _persist = Library.isInLibrary(widget.path);
    _start = _persist ? (_data.position(_key) ?? 0) : 0;
    _top = _start;
    _positions.itemPositions.addListener(_onPositions);
    _load();
  }

  @override
  void dispose() {
    _saveTimer?.cancel();
    _save();
    _positions.itemPositions.removeListener(_onPositions);
    _searchController.dispose();
    _searchFocus.dispose();
    super.dispose();
  }

  // ---------- Yuklash ----------

  Future<void> _load() async {
    try {
      String? mediaDir;
      try {
        final cache = await ArchiveReader.cacheDirectory();
        final id = sha1
            .convert(utf8.encode(widget.path))
            .toString()
            .substring(0, 16);
        mediaDir = p.join(cache.path, 'media', id);
      } catch (_) {
        mediaDir = null;
      }
      final doc = await loadDocx(widget.path, mediaDir: mediaDir);

      final items = <_Item>[];
      final headings = <int>[];
      for (final b in doc.blocks) {
        if (b is DPara) {
          if (b.pageBreakBefore) items.add(const _Item(pageBreak: true));
          if (b.runs.isEmpty && b.pageBreakBefore && b.size <= 1) continue;
          if (b.heading > 0 && b.plain.trim().isNotEmpty) {
            headings.add(items.length);
          }
          items.add(_Item(para: b));
        } else if (b is DTable) {
          for (var i = 0; i < b.rows.length; i++) {
            items.add(_Item(table: b, row: i));
          }
        }
      }
      if (items.isEmpty) {
        items.add(const _Item(para: DPara(runs: <DRun>[])));
      }
      if (!mounted) return;
      setState(() {
        _doc = doc;
        _items = items;
        _headings = headings;
        _start = _start.clamp(0, items.length - 1);
        _top = _start;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = errorText(e);
        _loading = false;
      });
    }
  }

  // ---------- Holat ----------

  void _onPositions() {
    final pos = _positions.itemPositions.value;
    if (pos.isEmpty) return;
    var first = pos.first;
    for (final x in pos) {
      if (x.itemLeadingEdge < first.itemLeadingEdge &&
          x.itemTrailingEdge > 0) {
        first = x;
      }
    }
    final visible = pos.where((x) => x.itemTrailingEdge > 0).toList();
    if (visible.isNotEmpty) {
      visible.sort((a, b) => a.itemLeadingEdge.compareTo(b.itemLeadingEdge));
      first = visible.first;
    }
    if (first.index != _top) {
      _top = first.index;
      _saveTimer?.cancel();
      _saveTimer = Timer(const Duration(seconds: 1), _save);
    }
  }

  void _save() {
    if (!_persist) return;
    _data.setPosition(_key, _top);
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  void _jump(int index) {
    if (!_itemScroll.isAttached) return;
    _itemScroll.jumpTo(index: index.clamp(0, _items.length - 1));
  }

  void _scrollTo(int index) {
    if (!_itemScroll.isAttached) return;
    _itemScroll.scrollTo(
      index: index.clamp(0, _items.length - 1),
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOut,
    );
  }

  // ---------- Qidiruv ----------

  void _startSearch() {
    setState(() => _searching = true);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _searchFocus.requestFocus();
    });
  }

  void _closeSearch() {
    _searchController.clear();
    setState(() {
      _searching = false;
      _query = '';
      _regex = null;
      _matches = const <int>[];
      _matchPos = -1;
    });
  }

  void _onQuery(String value) {
    final q = value.trim();
    if (q.isEmpty) {
      setState(() {
        _query = '';
        _regex = null;
        _matches = const <int>[];
        _matchPos = -1;
      });
      return;
    }
    final regex = RegExp(RegExp.escape(q), caseSensitive: false);
    final found = <int>[];
    for (var i = 0; i < _items.length; i++) {
      if (regex.hasMatch(_items[i].plain)) found.add(i);
      if (found.length >= 5000) break;
    }
    setState(() {
      _query = q;
      _regex = regex;
      _matches = found;
      _matchPos = found.isEmpty ? -1 : 0;
    });
    if (found.isNotEmpty) _scrollTo(found.first);
  }

  void _step(int delta) {
    if (_matches.isEmpty) return;
    setState(() {
      _matchPos = (_matchPos + delta) % _matches.length;
      if (_matchPos < 0) _matchPos += _matches.length;
    });
    _scrollTo(_matches[_matchPos]);
  }

  // ---------- Amallar ----------

  void _showContents() {
    if (_headings.isEmpty) {
      _snack(t("Mundarija topilmadi"));
      return;
    }
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.6,
        maxChildSize: 0.92,
        builder: (ctx, controller) => ListView.builder(
          controller: controller,
          itemCount: _headings.length,
          itemBuilder: (ctx, i) {
            final item = _items[_headings[i]];
            final para = item.para!;
            return ListTile(
              dense: true,
              contentPadding: EdgeInsets.only(
                left: 16.0 + (math.min(para.heading, 5) - 1) * 16,
                right: 16,
              ),
              title: fw.Text(
                para.plain.trim(),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              onTap: () {
                Navigator.pop(ctx);
                _jump(_headings[i]);
              },
            );
          },
        ),
      ),
    );
  }

  Future<void> _share() async {
    try {
      await Share.shareXFiles([XFile(widget.path)]);
    } catch (e) {
      _snack("Ulashib bo'lmadi: ${errorText(e)}");
    }
  }

  Future<void> _onMenu(String value) async {
    switch (value) {
      case 'layout':
        final top = _top;
        setState(() => _print = !_print);
        WidgetsBinding.instance.addPostFrameCallback((_) => _jump(top));
        break;
      case 'contents':
        _showContents();
        break;
      case 'zoom':
        setState(() => _zoom = 1);
        break;
      case 'text':
        await Navigator.of(context).pushReplacement(
          MaterialPageRoute<void>(
            builder: (_) => TextScreen(path: widget.path),
          ),
        );
        break;
      case 'share':
        await _share();
        break;
      case 'external':
        await OpenFilex.open(widget.path);
        break;
    }
  }

  // ---------- Masshtab ----------

  double _distance() {
    final pts = _pointers.values.toList();
    if (pts.length < 2) return 0;
    return (pts[0] - pts[1]).distance;
  }

  void _pointerEnd(PointerEvent e) {
    _pointers.remove(e.pointer);
    if (_pointers.length < 2) _pinchStart = null;
  }

  // ---------- Chizish ----------

  void _viewImage(String path) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.black,
            foregroundColor: Colors.white,
            title: Text(p.basename(path).replaceFirst(RegExp(r'^\d+_'), '')),
          ),
          body: Center(
            child: InteractiveViewer(
              maxScale: 8,
              child: Image.file(
                File(path),
                errorBuilder: (_, __, ___) => const Icon(
                  Icons.broken_image_outlined,
                  color: Colors.white54,
                  size: 64,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  String? _family(String? font) {
    if (font == null) return null;
    final f = font.toLowerCase();
    if (f.contains('courier') ||
        f.contains('consolas') ||
        f.contains('mono') ||
        f.contains('lucida console')) {
      return 'monospace';
    }
    if (f.contains('times') ||
        f.contains('cambria') ||
        f.contains('georgia') ||
        f.contains('garamond') ||
        f.contains('book antiqua') ||
        f.contains('palatino') ||
        f.contains('serif') && !f.contains('sans')) {
      return 'serif';
    }
    return null;
  }

  TextSpan _highlighted(String text, TextStyle style, bool current) {
    final regex = _regex;
    if (regex == null || text.isEmpty) return TextSpan(text: text, style: style);
    final bg = current ? const Color(0xFFFFB74D) : const Color(0x99FFEB3B);
    final children = <InlineSpan>[];
    var last = 0;
    for (final m in regex.allMatches(text)) {
      if (m.end == m.start) continue;
      if (m.start > last) {
        children.add(TextSpan(text: text.substring(last, m.start)));
      }
      children.add(
        TextSpan(
          text: text.substring(m.start, m.end),
          style: TextStyle(backgroundColor: bg, color: Colors.black),
        ),
      );
      last = m.end;
    }
    if (children.isEmpty) return TextSpan(text: text, style: style);
    if (last < text.length) children.add(TextSpan(text: text.substring(last)));
    return TextSpan(style: style, children: children);
  }

  Future<void> _openLink(String href) async {
    await Clipboard.setData(ClipboardData(text: href));
    _snack(t('Havola nusxalandi'));
  }

  Widget _image(DRun r, double s, double avail) {
    var w = r.imgW * s;
    var h = r.imgH * s;
    if (w > avail && w > 0) {
      h = h * avail / w;
      w = avail;
    }
    return GestureDetector(
      onTap: () => _viewImage(r.image!),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: avail),
          child: Image.file(
            File(r.image!),
            width: w > 0 ? w : null,
            height: h > 0 ? h : null,
            fit: BoxFit.contain,
            errorBuilder: (_, __, ___) => const SizedBox.shrink(),
          ),
        ),
      ),
    );
  }

  Widget _paragraph(DPara para, double s, double avail, bool current) {
    final lineHeight = para.lineExact > 0
        ? null
        : 1.2 * (para.lineMul > 0 ? para.lineMul : 1.0);

    final spans = <InlineSpan>[];
    if (para.marker == null && para.firstLine > 0) {
      spans.add(WidgetSpan(child: SizedBox(width: para.firstLine * s)));
    }
    var imagesOnly = true;
    for (final r in para.runs) {
      if (r.pageBreak) continue;
      if (r.image != null) {
        spans.add(
          WidgetSpan(
            alignment: PlaceholderAlignment.middle,
            child: _image(r, s, math.max(avail - (para.left + para.right) * s, 40)),
          ),
        );
        continue;
      }
      if (r.text.isEmpty) continue;
      imagesOnly = false;
      final decorations = <TextDecoration>[
        if (r.underline) TextDecoration.underline,
        if (r.strike) TextDecoration.lineThrough,
      ];
      final size = r.size * s * (r.vert != 0 ? 0.65 : 1.0);
      final style = TextStyle(
        fontSize: size,
        fontWeight: r.bold ? FontWeight.w700 : FontWeight.w400,
        fontStyle: r.italic ? FontStyle.italic : FontStyle.normal,
        color: Color(r.color ?? 0xFF000000),
        backgroundColor: r.highlight != null
            ? Color(r.highlight!)
            : (r.shade != null ? Color(r.shade!) : null),
        decoration: decorations.isEmpty
            ? TextDecoration.none
            : TextDecoration.combine(decorations),
        fontFamily: _family(r.font),
        height: lineHeight,
      );
      final span = _highlighted(r.text, style, current);
      final href = r.href;
      if (href != null && href.isNotEmpty) {
        spans.add(
          TextSpan(
            style: style,
            children: [span],
            recognizer: (TapGestureRecognizer()..onTap = () => _openLink(href)),
          ),
        );
      } else {
        spans.add(span);
      }
    }

    final align = switch (para.align) {
      'center' => TextAlign.center,
      'right' => TextAlign.right,
      'both' => TextAlign.justify,
      _ => TextAlign.left,
    };

    final strut = para.lineExact > 0
        ? StrutStyle(
            fontSize: para.size * s,
            height: para.lineExact / math.max(para.size, 1),
            forceStrutHeight: true,
          )
        : null;

    Widget body;
    if (spans.isEmpty && !imagesOnly) {
      body = SizedBox(height: para.size * s * 1.2);
    } else if (spans.isEmpty) {
      body = SizedBox(height: para.size * s * 1.2);
    } else {
      body = fw.Text.rich(
        TextSpan(children: spans),
        textAlign: align,
        strutStyle: strut,
      );
    }

    var left = para.left * s;
    if (para.marker != null) {
      final hang = math.max(para.markerWidth, 14.0) * s;
      final markerStyle = TextStyle(
        fontSize: para.size * s,
        color: Color(para.markerColor ?? 0xFF000000),
        height: lineHeight,
      );
      left = math.max(0.0, left - hang);
      body = Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: hang,
            child: fw.Text(para.marker!, style: markerStyle),
          ),
          Expanded(child: body),
        ],
      );
    }

    Widget out = Padding(
      padding: EdgeInsets.only(left: left, right: para.right * s),
      child: body,
    );

    if (para.shade != null ||
        para.borderTop != null ||
        para.borderBottom != null) {
      out = DecoratedBox(
        decoration: BoxDecoration(
          color: para.shade == null ? null : Color(para.shade!),
          border: Border(
            top: para.borderTop == null
                ? BorderSide.none
                : BorderSide(
                    color: Color(para.borderTop!.color),
                    width: para.borderTop!.width,
                  ),
            bottom: para.borderBottom == null
                ? BorderSide.none
                : BorderSide(
                    color: Color(para.borderBottom!.color),
                    width: para.borderBottom!.width,
                  ),
          ),
        ),
        child: out,
      );
    }

    return Padding(
      padding: EdgeInsets.only(top: para.before * s, bottom: para.after * s),
      child: out,
    );
  }

  BorderSide _side(DSide? side, double s) {
    if (side == null) return BorderSide.none;
    return BorderSide(
      color: Color(side.color),
      width: math.max(0.6, side.width * s.clamp(0.6, 1.5)),
    );
  }

  Widget _blockWidget(DBlock b, double s, double avail, bool current) {
    if (b is DPara) return _paragraph(b, s, avail, current);
    if (b is DTable) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (var i = 0; i < b.rows.length; i++)
            _tableRow(b, i, s, avail, current),
        ],
      );
    }
    return const SizedBox.shrink();
  }

  Widget _tableRow(DTable t, int ri, double s, double avail, bool current) {
    final row = t.rows[ri];
    var total = 0.0;
    for (final g in t.grid) {
      total += g;
    }
    if (total <= 0) total = 1;
    final width = math.min(avail, total * s);

    final cells = <Widget>[];
    var col = 0;
    var used = 0.0;
    for (final cell in row) {
      var w = 0.0;
      for (var i = col; i < col + cell.span && i < t.grid.length; i++) {
        w += t.grid[i];
      }
      col += cell.span;
      final cw = w / total * width;
      used += cw;
      final inner = math.max(cw - 10 * s, 20.0);
      cells.add(
        Container(
          width: cw,
          padding: EdgeInsets.symmetric(horizontal: 5 * s, vertical: 2 * s),
          decoration: BoxDecoration(
            color: cell.shade == null ? null : Color(cell.shade!),
            border: Border(
              top: cell.vContinue ? BorderSide.none : _side(cell.top, s),
              left: _side(cell.left, s),
              bottom: _side(cell.bottom, s),
              right: _side(cell.right, s),
            ),
          ),
          child: cell.vContinue
              ? const SizedBox.shrink()
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    for (final b in cell.blocks)
                      _blockWidget(b, s, inner, current),
                  ],
                ),
        ),
      );
    }
    if (used < width - 1) cells.add(SizedBox(width: width - used));

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: cells,
      ),
    );
  }

  Widget _item(int index, double paperW, double s, double ml, double mr) {
    final doc = _doc!;
    final item = _items[index];
    final current = _matchPos >= 0 &&
        _matchPos < _matches.length &&
        _matches[_matchPos] == index;
    final avail = paperW - (ml + mr);

    Widget content;
    if (item.pageBreak) {
      content = Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(
          children: [
            const Expanded(child: Divider()),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Text(
                t('Sahifa oxiri'),
                style: const TextStyle(fontSize: 11, color: Colors.grey),
              ),
            ),
            const Expanded(child: Divider()),
          ],
        ),
      );
    } else if (item.para != null) {
      content = _paragraph(item.para!, s, avail, current);
    } else {
      content = _tableRow(item.table!, item.row, s, avail, current);
    }

    final topPad = index == 0 ? (_print ? doc.marginT * s : 20.0) : 0.0;
    final bottomPad =
        index == _items.length - 1 ? (_print ? doc.marginB * s : 40.0) : 0.0;

    return Container(
      width: paperW,
      color: Colors.white,
      padding: EdgeInsets.fromLTRB(ml, topPad, mr, bottomPad),
      child: content,
    );
  }

  Widget _list(double screenW, double screenH) {
    final doc = _doc!;
    double paperW;
    double s;
    double ml;
    double mr;
    if (_print) {
      paperW = (screenW - 12) * _zoom;
      s = paperW / doc.pageW;
      ml = doc.marginL * s;
      mr = doc.marginR * s;
    } else {
      paperW = screenW;
      s = 1.25 * _zoom;
      ml = 16;
      mr = 16;
    }

    final list = ScrollablePositionedList.builder(
      itemCount: _items.length,
      itemScrollController: _itemScroll,
      itemPositionsListener: _positions,
      initialScrollIndex: _start,
      padding: EdgeInsets.symmetric(vertical: _print ? 6 : 0),
      itemBuilder: (context, i) => _item(i, paperW, s, ml, mr),
    );

    final framed = ColoredBox(
      color: _print
          ? Theme.of(context).colorScheme.surfaceContainerHighest
          : Colors.white,
      child: Center(
        child: SizedBox(
          width: paperW,
          child: SelectionArea(child: list),
        ),
      ),
    );

    if (_print && paperW > screenW) {
      return SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: SizedBox(
          width: paperW + 12,
          height: screenH,
          child: framed,
        ),
      );
    }
    return framed;
  }

  Widget _body() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, size: 48),
              const SizedBox(height: 12),
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () => _onMenu('text'),
                child: Text('Matn sifatida ochish'),
              ),
            ],
          ),
        ),
      );
    }

    return LayoutBuilder(
      builder: (context, cons) => Listener(
        onPointerDown: (e) {
          _pointers[e.pointer] = e.position;
          if (_pointers.length == 2) {
            _pinchStart = _distance();
            _pinchBase = _zoom;
          }
        },
        onPointerMove: (e) {
          if (!_pointers.containsKey(e.pointer)) return;
          _pointers[e.pointer] = e.position;
          final start = _pinchStart;
          if (_pointers.length == 2 && start != null && start > 0) {
            final next = (_pinchBase * _distance() / start)
                .clamp(0.6, 3.0)
                .toDouble();
            if ((next - _zoom).abs() > 0.02) setState(() => _zoom = next);
          }
        },
        onPointerUp: _pointerEnd,
        onPointerCancel: _pointerEnd,
        child: _list(cons.maxWidth, cons.maxHeight),
      ),
    );
  }

  PreferredSizeWidget _appBar() {
    if (_searching) {
      return AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: _closeSearch,
        ),
        title: TextField(
          controller: _searchController,
          focusNode: _searchFocus,
          onChanged: _onQuery,
          onSubmitted: (_) => _step(1),
          textInputAction: TextInputAction.search,
          decoration: InputDecoration(
            hintText: t('Qidirish...'),
            border: InputBorder.none,
          ),
        ),
        actions: [
          if (_query.isNotEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text(
                  _matches.isEmpty ? '0' : '${_matchPos + 1}/${_matches.length}',
                ),
              ),
            ),
          IconButton(
            tooltip: t('Oldingi'),
            icon: const Icon(Icons.keyboard_arrow_up),
            onPressed: _matches.isEmpty ? null : () => _step(-1),
          ),
          IconButton(
            tooltip: t('Keyingi'),
            icon: const Icon(Icons.keyboard_arrow_down),
            onPressed: _matches.isEmpty ? null : () => _step(1),
          ),
        ],
      );
    }

    return AppBar(
      title: Text(
        Library.displayName(widget.path),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      actions: [
        if (_doc != null)
          IconButton(
            tooltip: t('Qidirish'),
            icon: const Icon(Icons.search),
            onPressed: _startSearch,
          ),
        PopupMenuButton<String>(
          onSelected: _onMenu,
          itemBuilder: (_) => [
            PopupMenuItem(
              value: 'layout',
              child: Text(_print ? 'Mobil ko\'rinish' : 'Sahifa ko\'rinishi'),
            ),
            PopupMenuItem(value: 'contents', child: Text('Mundarija')),
            PopupMenuItem(value: 'zoom', child: Text('Asl holat')),
            PopupMenuItem(value: 'text', child: Text('Matn sifatida ochish')),
            PopupMenuItem(value: 'share', child: Text('Ulashish')),
            PopupMenuItem(value: 'external', child: Text('Boshqa ilovada ochish')),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: _appBar(), body: _body());
  }
}
