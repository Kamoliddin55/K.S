import 'package:shared_preferences/shared_preferences.dart';

class Bookmark {
  final int index;
  final String label;
  const Bookmark(this.index, this.label);
}

/// Foydalanuvchi ma'lumotlari: o'qish joyi, sevimlilar, xatcho'plar, oxirgi ochilgan vaqt.
/// Kalit sifatida kutubxonadagi fayl nomi (vaqt belgisi bilan) ishlatiladi.
class UserData {
  UserData._();
  static final UserData instance = UserData._();

  SharedPreferences? _prefs;
  final Set<String> _favorites = <String>{};

  Future<void> init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _prefs = prefs;
      _favorites
        ..clear()
        ..addAll(prefs.getStringList('favorites') ?? const <String>[]);
    } catch (_) {
      // Xotira o'qilmasa, ma'lumotlar saqlanmaydi, lekin ilova ishlayveradi
    }
  }

  // ---------- O'qish joyi ----------

  int? position(String key) => _prefs?.getInt('pos:$key');

  Future<void> setPosition(String key, int value) async {
    try {
      await _prefs?.setInt('pos:$key', value);
    } catch (_) {}
  }

  // ---------- O'qish foizi ----------

  double progress(String key) => _prefs?.getDouble('prog:$key') ?? 0.0;

  Future<void> setProgress(String key, double value) async {
    try {
      await _prefs?.setDouble('prog:$key', value.clamp(0.0, 1.0).toDouble());
    } catch (_) {}
  }

  // ---------- Matn kodlashi ----------

  String? encoding(String key) => _prefs?.getString('enc:$key');

  Future<void> setEncoding(String key, String? value) async {
    try {
      if (value == null) {
        await _prefs?.remove('enc:$key');
      } else {
        await _prefs?.setString('enc:$key', value);
      }
    } catch (_) {}
  }

  // ---------- Papkalar ----------

  List<String> folders() =>
      List<String>.of(_prefs?.getStringList('folders') ?? const <String>[]);

  String? folderOf(String key) => _prefs?.getString('folder:$key');

  Future<bool> addFolder(String name) async {
    final clean = name.trim();
    if (clean.isEmpty) return false;

    final list = folders();
    if (list.any((f) => f.toLowerCase() == clean.toLowerCase())) return false;
    list.add(clean);
    try {
      await _prefs?.setStringList('folders', list);
    } catch (_) {
      return false;
    }
    return true;
  }

  Iterable<String> _folderKeys(String folder) {
    final prefs = _prefs;
    if (prefs == null) return const <String>[];
    return prefs
        .getKeys()
        .where((k) => k.startsWith('folder:') && prefs.getString(k) == folder)
        .toList();
  }

  Future<void> renameFolder(String oldName, String newName) async {
    final clean = newName.trim();
    if (clean.isEmpty || clean == oldName) return;

    final list = folders();
    final index = list.indexOf(oldName);
    if (index < 0) return;
    if (list.any((f) => f.toLowerCase() == clean.toLowerCase() && f != oldName)) {
      return;
    }
    list[index] = clean;

    try {
      final keys = _folderKeys(oldName).toList();
      await _prefs?.setStringList('folders', list);
      for (final k in keys) {
        await _prefs?.setString(k, clean);
      }
    } catch (_) {}
  }

  Future<void> deleteFolder(String name) async {
    final list = folders()..remove(name);
    try {
      final keys = _folderKeys(name).toList();
      await _prefs?.setStringList('folders', list);
      for (final k in keys) {
        await _prefs?.remove(k);
      }
    } catch (_) {}
  }

  Future<void> setFolder(String key, String? folder) async {
    try {
      if (folder == null) {
        await _prefs?.remove('folder:$key');
      } else {
        await _prefs?.setString('folder:$key', folder);
      }
    } catch (_) {}
  }

  // ---------- Oxirgi ochilgan vaqt ----------

  int openedAt(String key) => _prefs?.getInt('open:$key') ?? 0;

  Future<void> markOpened(String key) async {
    try {
      await _prefs?.setInt('open:$key', DateTime.now().millisecondsSinceEpoch);
    } catch (_) {}
  }

  // ---------- Sevimlilar ----------

  bool isFavorite(String key) => _favorites.contains(key);

  Future<void> setFavorite(String key, bool value) async {
    if (value) {
      _favorites.add(key);
    } else {
      _favorites.remove(key);
    }
    try {
      await _prefs?.setStringList('favorites', _favorites.toList());
    } catch (_) {}
  }

  // ---------- Xatcho'plar ----------

  List<Bookmark> bookmarks(String key) {
    final raw = _prefs?.getStringList('bm:$key') ?? const <String>[];
    final result = <Bookmark>[];
    for (final item in raw) {
      final i = item.indexOf('|');
      if (i <= 0) continue;
      final index = int.tryParse(item.substring(0, i));
      if (index == null) continue;
      result.add(Bookmark(index, item.substring(i + 1)));
    }
    result.sort((a, b) => a.index.compareTo(b.index));
    return result;
  }

  bool hasBookmark(String key, int index) =>
      bookmarks(key).any((b) => b.index == index);

  Future<void> _saveBookmarks(String key, List<Bookmark> list) async {
    try {
      if (list.isEmpty) {
        await _prefs?.remove('bm:$key');
      } else {
        await _prefs?.setStringList(
          'bm:$key',
          [for (final b in list) '${b.index}|${b.label}'],
        );
      }
    } catch (_) {}
  }

  Future<void> addBookmark(String key, int index, String label) async {
    var clean = label.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (clean.length > 60) clean = clean.substring(0, 60);
    final list = bookmarks(key).where((b) => b.index != index).toList()
      ..add(Bookmark(index, clean));
    await _saveBookmarks(key, list);
  }

  Future<void> removeBookmark(String key, int index) async {
    final list = bookmarks(key).where((b) => b.index != index).toList();
    await _saveBookmarks(key, list);
  }

  // ---------- Fayl o'chirilganda yoki nomi o'zgarganda ----------

  Future<void> forget(String key) async {
    _favorites.remove(key);
    try {
      await _prefs?.remove('pos:$key');
      await _prefs?.remove('open:$key');
      await _prefs?.remove('bm:$key');
      await _prefs?.remove('prog:$key');
      await _prefs?.remove('enc:$key');
      await _prefs?.remove('folder:$key');
      await _prefs?.setStringList('favorites', _favorites.toList());
    } catch (_) {}
  }

  Future<void> rename(String oldKey, String newKey) async {
    if (oldKey == newKey) return;
    try {
      final prefs = _prefs;
      if (prefs == null) return;

      final pos = prefs.getInt('pos:$oldKey');
      if (pos != null) await prefs.setInt('pos:$newKey', pos);

      final opened = prefs.getInt('open:$oldKey');
      if (opened != null) await prefs.setInt('open:$newKey', opened);

      final bm = prefs.getStringList('bm:$oldKey');
      if (bm != null) await prefs.setStringList('bm:$newKey', bm);

      final prog = prefs.getDouble('prog:$oldKey');
      if (prog != null) await prefs.setDouble('prog:$newKey', prog);

      final enc = prefs.getString('enc:$oldKey');
      if (enc != null) await prefs.setString('enc:$newKey', enc);

      final folder = prefs.getString('folder:$oldKey');
      if (folder != null) await prefs.setString('folder:$newKey', folder);

      final wasFavorite = _favorites.contains(oldKey);
      await forget(oldKey);
      if (wasFavorite) await setFavorite(newKey, true);
    } catch (_) {}
  }
}
