import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart' hide Text;
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'l10n.dart';
import 'theme.dart';

/// PIN kod bilan ilova qulfi. PIN ochiq holda saqlanmaydi: tasodifiy tuz bilan
/// SHA-256 xeshi saqlanadi.
class LockService extends ChangeNotifier {
  LockService._();
  static final LockService instance = LockService._();

  SharedPreferences? _prefs;

  /// Hozir ilova qulflanganmi.
  bool locked = false;

  bool get enabled => (_prefs?.getString('lockHash') ?? '').isNotEmpty;

  Future<void> init() async {
    try {
      _prefs = await SharedPreferences.getInstance();
    } catch (_) {
      // Xotira o'qilmasa, qulf o'chiq hisoblanadi
    }
    locked = enabled;
  }

  String _hash(String pin, String salt) =>
      sha256.convert(utf8.encode('$salt:$pin')).toString();

  Future<bool> setPin(String pin) async {
    final prefs = _prefs;
    if (prefs == null) return false;

    final random = Random.secure();
    final salt = base64UrlEncode(
      List<int>.generate(16, (_) => random.nextInt(256)),
    );
    try {
      await prefs.setString('lockSalt', salt);
      await prefs.setString('lockHash', _hash(pin, salt));
    } catch (_) {
      return false;
    }
    notifyListeners();
    return true;
  }

  bool verify(String pin) {
    final prefs = _prefs;
    if (prefs == null) return true;

    final hash = prefs.getString('lockHash') ?? '';
    final salt = prefs.getString('lockSalt') ?? '';
    return hash.isNotEmpty && _hash(pin, salt) == hash;
  }

  // ---------- Barmoq izi / yuz bilan ochish ----------

  bool get bioEnabled => enabled && (_prefs?.getBool('lockBio') ?? false);

  /// Qurilmada biometrik usul mavjud va sozlanganmi.
  Future<bool> bioAvailable() async {
    try {
      final auth = LocalAuthentication();
      return await auth.isDeviceSupported() && await auth.canCheckBiometrics;
    } catch (_) {
      return false;
    }
  }

  Future<void> setBio(bool on) async {
    try {
      await _prefs?.setBool('lockBio', on);
    } catch (_) {}
    notifyListeners();
  }

  /// Biometrik tekshiruv. Xato bo'lsa false qaytaradi (PIN bilan ochish mumkin).
  Future<bool> authenticateBio(String reason) async {
    try {
      return await LocalAuthentication().authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(
          biometricOnly: true,
          stickyAuth: true,
        ),
      );
    } catch (_) {
      return false;
    }
  }

  Future<void> disable() async {
    try {
      await _prefs?.remove('lockBio');
      await _prefs?.remove('lockHash');
      await _prefs?.remove('lockSalt');
    } catch (_) {}
    locked = false;
    notifyListeners();
  }

  void lock() {
    if (enabled && !locked) {
      locked = true;
      notifyListeners();
    }
  }

  void unlock() {
    if (locked) {
      locked = false;
      notifyListeners();
    }
  }
}

/// Butun ilova ustidan qulf ekranini ko'rsatadi. Ilova 30 soniyadan ko'proq
/// orqa fonda turib qaytsa, qayta qulflanadi.
class LockGate extends StatefulWidget {
  final Widget child;
  const LockGate({super.key, required this.child});

  @override
  State<LockGate> createState() => _LockGateState();
}

class _LockGateState extends State<LockGate> with WidgetsBindingObserver {
  static const _grace = Duration(seconds: 30);

  final _lock = LockService.instance;
  DateTime? _pausedAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _lock.addListener(_changed);
  }

  @override
  void dispose() {
    _lock.removeListener(_changed);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  void _changed() {
    if (mounted) setState(() {});
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      final since = _pausedAt;
      _pausedAt = null;
      if (since != null && DateTime.now().difference(since) > _grace) {
        _lock.lock();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        widget.child,
        if (_lock.locked) const Positioned.fill(child: LockScreen()),
      ],
    );
  }
}

class LockScreen extends StatefulWidget {
  const LockScreen({super.key});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  static const _maxLength = 8;

  String _pin = '';
  bool _error = false;
  int _fails = 0;
  DateTime? _blockedUntil;
  bool _bioBusy = false;

  @override
  void initState() {
    super.initState();
    if (LockService.instance.bioEnabled) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _bio());
    }
  }

  Future<void> _bio() async {
    if (_bioBusy || _blocked) return;
    _bioBusy = true;
    final ok = await LockService.instance.authenticateBio(t('PIN kodni kiriting'));
    _bioBusy = false;
    if (ok) LockService.instance.unlock();
  }

  bool get _blocked {
    final until = _blockedUntil;
    return until != null && DateTime.now().isBefore(until);
  }

  void _tap(String digit) {
    if (_blocked) {
      setState(() {});
      return;
    }
    if (_pin.length >= _maxLength) return;
    setState(() {
      _pin += digit;
      _error = false;
    });
  }

  void _erase() {
    if (_pin.isEmpty) return;
    setState(() => _pin = _pin.substring(0, _pin.length - 1));
  }

  void _submit() {
    if (_blocked || _pin.length < 4) return;

    if (LockService.instance.verify(_pin)) {
      LockService.instance.unlock();
      return;
    }

    setState(() {
      _pin = '';
      _error = true;
      _fails++;
      if (_fails >= 5) {
        _fails = 0;
        _blockedUntil = DateTime.now().add(const Duration(seconds: 30));
      }
    });
  }

  Widget _key(String digit) {
    return SizedBox(
      width: 76,
      height: 76,
      child: FilledButton.tonal(
        style: FilledButton.styleFrom(
          shape: const CircleBorder(),
          padding: EdgeInsets.zero,
        ),
        onPressed: () => _tap(digit),
        child: Text(digit, style: const TextStyle(fontSize: 26)),
      ),
    );
  }

  Widget _row(List<Widget> children) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          for (final child in children)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: child,
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final blocked = _blocked;

    return GradientBackground(
      child: Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.lock_outline, size: 56, color: colors.primary),
                const SizedBox(height: 16),
                const Text(
                  'PIN kodni kiriting',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  height: 20,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      for (var i = 0; i < (_pin.length < 4 ? 4 : _pin.length); i++)
                        Container(
                          width: 14,
                          height: 14,
                          margin: const EdgeInsets.symmetric(horizontal: 5),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: i < _pin.length
                                ? colors.primary
                                : colors.outlineVariant,
                          ),
                        ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 40,
                  child: Center(
                    child: blocked
                        ? Text(
                            "Juda ko'p urinish. 30 soniya kuting.",
                            style: TextStyle(color: colors.error),
                          )
                        : _error
                            ? Text(
                                "PIN noto'g'ri",
                                style: TextStyle(color: colors.error),
                              )
                            : const SizedBox.shrink(),
                  ),
                ),
                _row([_key('1'), _key('2'), _key('3')]),
                _row([_key('4'), _key('5'), _key('6')]),
                _row([_key('7'), _key('8'), _key('9')]),
                _row([
                  SizedBox(
                    width: 76,
                    height: 76,
                    child: LockService.instance.bioEnabled && _pin.isEmpty
                        ? IconButton(
                            tooltip: t('Barmoq izi bilan ochish'),
                            onPressed: _bio,
                            icon: const Icon(Icons.fingerprint, size: 34),
                          )
                        : IconButton(
                            onPressed: _erase,
                            icon: const Icon(Icons.backspace_outlined),
                          ),
                  ),
                  _key('0'),
                  SizedBox(
                    width: 76,
                    height: 76,
                    child: IconButton.filled(
                      onPressed: _pin.length >= 4 ? _submit : null,
                      icon: const Icon(Icons.check),
                    ),
                  ),
                ]),
              ],
            ),
          ),
        ),
      ),
      ),
    );
  }
}
