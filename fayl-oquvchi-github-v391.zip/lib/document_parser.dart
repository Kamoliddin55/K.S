import 'dart:convert';
import 'dart:io';
import 'dart:isolate';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:path/path.dart' as p;
import 'package:xml/xml.dart';

enum DocKind { pdf, text, html, docx, xlsx, pptx, epub, archive, external }

class Section {
  final String title;
  final List<String> lines;
  const Section(this.title, this.lines);
}

DocKind kindOf(String path) {
  switch (p.extension(path).toLowerCase()) {
    case '.pdf':
      return DocKind.pdf;
    case '.txt':
    case '.md':
    case '.csv':
    case '.tsv':
    case '.json':
    case '.xml':
    case '.log':
      return DocKind.text;
    case '.html':
    case '.htm':
      return DocKind.html;
    case '.docx':
    case '.docm':
      return DocKind.docx;
    case '.xlsx':
    case '.xlsm':
      return DocKind.xlsx;
    case '.pptx':
    case '.pptm':
      return DocKind.pptx;
    case '.epub':
      return DocKind.epub;
    case '.zip':
    case '.tar':
    case '.tgz':
    case '.gz':
    case '.tbz2':
    case '.bz2':
    case '.rar':
    case '.7z':
      return DocKind.archive;
    default:
      return DocKind.external;
  }
}

/// Katta fayllar ekranni qotirmasligi uchun alohida isolate'da o'qiladi.
Future<List<Section>> parseDocumentIsolated(
  String path,
  DocKind kind, {
  String? encoding,
  String? mediaDir,
}) =>
    Isolate.run(
      () => parseDocument(path, kind, encoding: encoding, mediaDir: mediaDir),
    );

/// [mediaDir] berilsa, hujjat ichidagi rasm, video va audio fayllar shu
/// papkaga chiqarilib, matn orasida maxsus qator sifatida qaytariladi.
Future<List<Section>> parseDocument(
  String path,
  DocKind kind, {
  String? encoding,
  String? mediaDir,
}) async {
  final bytes = await File(path).readAsBytes();
  final media = MediaSink(mediaDir);

  switch (kind) {
    case DocKind.text:
      return [Section('', _splitLines(_decodeText(bytes, encoding)))];
    case DocKind.html:
      return [Section('', _htmlLines(_decodeText(bytes, encoding)))];
    case DocKind.docx:
      return [Section('', _docxLines(bytes, media))];
    case DocKind.xlsx:
      return _xlsxSections(bytes, media);
    case DocKind.pptx:
      return _pptxSections(bytes, media);
    case DocKind.epub:
      return _epubSections(bytes, media);
    case DocKind.pdf:
    case DocKind.archive:
    case DocKind.external:
      throw UnsupportedError('Bu format ichki o‘quvchida ochilmaydi');
  }
}

// ---------- Matn ----------

String _decodeText(Uint8List bytes, [String? encoding]) {
  // Foydalanuvchi kodlashni o'zi tanlagan bo'lsa, avtomatik aniqlash o'tkazib yuboriladi
  switch (encoding) {
    case 'utf8':
      return _stripBom(utf8.decode(bytes, allowMalformed: true));
    case 'cp1251':
      return _stripBom(_decodeCp1251(bytes));
    case 'latin1':
      return _stripBom(latin1.decode(bytes));
    case 'utf16le':
      return _decodeUtf16(
        bytes,
        littleEndian: true,
        skip: _hasBom(bytes, 0xFF, 0xFE) ? 2 : 0,
      );
    case 'utf16be':
      return _decodeUtf16(
        bytes,
        littleEndian: false,
        skip: _hasBom(bytes, 0xFE, 0xFF) ? 2 : 0,
      );
  }

  // Windows Notepad "Unicode" (UTF-16) fayllari
  if (bytes.length >= 2 && bytes[0] == 0xFF && bytes[1] == 0xFE) {
    return _decodeUtf16(bytes, littleEndian: true);
  }
  if (bytes.length >= 2 && bytes[0] == 0xFE && bytes[1] == 0xFF) {
    return _decodeUtf16(bytes, littleEndian: false);
  }

  String text;
  try {
    text = utf8.decode(bytes);
  } on FormatException {
    text = _decodeCp1251(bytes);
  }
  return text.startsWith('\uFEFF') ? text.substring(1) : text;
}

String _decodeUtf16(
  Uint8List bytes, {
  required bool littleEndian,
  int skip = 2,
}) {
  final units = <int>[];
  for (var i = skip; i + 1 < bytes.length; i += 2) {
    units.add(
      littleEndian
          ? bytes[i] | (bytes[i + 1] << 8)
          : (bytes[i] << 8) | bytes[i + 1],
    );
  }
  return String.fromCharCodes(units);
}

bool _hasBom(Uint8List bytes, int a, int b) =>
    bytes.length >= 2 && bytes[0] == a && bytes[1] == b;

String _stripBom(String s) => s.startsWith('\uFEFF') ? s.substring(1) : s;

List<String> _splitLines(String s) => s.split(RegExp(r'\r?\n'));

const _cp1251High = <int>[
  0x0402, 0x0403, 0x201A, 0x0453, 0x201E, 0x2026, 0x2020, 0x2021,
  0x20AC, 0x2030, 0x0409, 0x2039, 0x040A, 0x040C, 0x040B, 0x040F,
  0x0452, 0x2018, 0x2019, 0x201C, 0x201D, 0x2022, 0x2013, 0x2014,
  0x0020, 0x2122, 0x0459, 0x203A, 0x045A, 0x045C, 0x045B, 0x045F,
  0x00A0, 0x040E, 0x045E, 0x0408, 0x00A4, 0x0490, 0x00A6, 0x00A7,
  0x0401, 0x00A9, 0x0404, 0x00AB, 0x00AC, 0x00AD, 0x00AE, 0x0407,
  0x00B0, 0x00B1, 0x0406, 0x0456, 0x0491, 0x00B5, 0x00B6, 0x00B7,
  0x0451, 0x2116, 0x0454, 0x00BB, 0x0458, 0x0405, 0x0455, 0x0457,
];

String _decodeCp1251(Uint8List bytes) {
  final sb = StringBuffer();
  for (final b in bytes) {
    if (b < 0x80) {
      sb.writeCharCode(b);
    } else if (b < 0xC0) {
      sb.writeCharCode(_cp1251High[b - 0x80]);
    } else {
      sb.writeCharCode(0x0410 + (b - 0xC0));
    }
  }
  return sb.toString();
}

// ---------- ZIP asosidagi formatlar ----------

/// Office va ePub XML'idagi "w:p", "a:t", "p:sp" kabi element prefikslarini
/// olib tashlaydi, shunda elementlarni oddiy nom bilan topish mumkin.
XmlDocument _parseXml(String xml) => XmlDocument.parse(
      xml.replaceAllMapped(
        RegExp(r'<(/?)[A-Za-z_][\w.-]*:'),
        (m) => '<${m[1]}',
      ),
    );

Archive _zip(Uint8List bytes) {
  try {
    return ZipDecoder().decodeBytes(bytes);
  } catch (_) {
    throw const FormatException('Fayl buzilgan yoki qo‘llab-quvvatlanmaydigan formatda');
  }
}

String? _entryText(Archive archive, String name) {
  final file = archive.findFile(name);
  if (file == null) return null;
  return utf8.decode(file.content as List<int>, allowMalformed: true);
}

String _requireEntry(Archive archive, String name) =>
    _entryText(archive, name) ??
    (throw FormatException('Faylda "$name" topilmadi'));

List<ArchiveFile> _numbered(Archive archive, RegExp pattern) {
  final files = archive.files.where((f) => pattern.hasMatch(f.name)).toList();
  files.sort((a, b) => _trailingNumber(a.name).compareTo(_trailingNumber(b.name)));
  return files;
}

int _trailingNumber(String name) {
  final m = RegExp(r'(\d+)\.xml$').firstMatch(name);
  return m == null ? 0 : int.parse(m.group(1)!);
}

String _childText(XmlElement e, String name) {
  final found = e.findElements(name);
  return found.isEmpty ? '' : found.first.innerText;
}

String _paragraphText(XmlElement para) {
  final sb = StringBuffer();
  for (final node in para.descendants) {
    if (node is! XmlElement) continue;
    final name = node.name.local;
    if (name == 't') {
      sb.write(node.innerText);
    } else if (name == 'tab') {
      final parent = node.parent;
      if (parent is XmlElement && parent.name.local == 'tabs') continue;
      sb.write('\t');
    } else if (name == 'br') {
      sb.write('\n');
    }
  }
  return sb.toString();
}

// ---------- DOCX ----------

class _DocxContext {
  final Archive archive;
  final Map<String, String> rels;
  final MediaSink media;
  _DocxContext(this.archive, this.rels, this.media);
}

List<String> _docxLines(Uint8List bytes, MediaSink media) {
  final archive = _zip(bytes);
  final doc = _parseXml(_requireEntry(archive, 'word/document.xml'));
  final bodies = doc.findAllElements('body');
  if (bodies.isEmpty) {
    return [for (final para in doc.findAllElements('p')) _paragraphText(para)];
  }
  final ctx = _DocxContext(
    archive,
    _relationships(archive, 'word/_rels/document.xml.rels', 'word/'),
    media,
  );
  final lines = <String>[];
  _docxBlocks(bodies.first, lines, ctx);
  return lines;
}

/// Hujjat tanasini tartib bilan o'qiydi: abzaslar va jadval qatorlari.
void _docxBlocks(XmlElement parent, List<String> lines, _DocxContext ctx) {
  for (final node in parent.children) {
    if (node is! XmlElement) continue;
    switch (node.name.local) {
      case 'p':
        final text = _paragraphText(node);
        final images = <String>[];
        for (final e in node.descendants.whereType<XmlElement>()) {
          if (e.name.local != 'blip') continue;
          final id = _attrByLocal(e, 'embed');
          final entry = id == null ? null : ctx.rels[id];
          final line = entry == null ? null : ctx.media.line(ctx.archive, entry);
          if (line != null) images.add(line);
        }
        if (images.isEmpty || text.trim().isNotEmpty) lines.add(text);
        lines.addAll(images);
        break;
      case 'tbl':
        for (final row in node.findElements('tr')) {
          final cells = <String>[];
          for (final cell in row.findElements('tc')) {
            final text = [
              for (final para in cell.findAllElements('p')) _paragraphText(para),
            ].where((t) => t.trim().isNotEmpty).join(' ');
            cells.add(text);
          }
          lines.add(cells.join(' | '));
        }
        lines.add('');
        break;
      case 'sdt':
        for (final content in node.findElements('sdtContent')) {
          _docxBlocks(content, lines, ctx);
        }
        break;
    }
  }
}

// ---------- XLSX ----------

List<Section> _xlsxSections(Uint8List bytes, MediaSink media) {
  final archive = _zip(bytes);
  final dateStyles = _dateStyles(archive);

  final shared = <String>[];
  final sst = _entryText(archive, 'xl/sharedStrings.xml');
  if (sst != null) {
    for (final si in _parseXml(sst).findAllElements('si')) {
      shared.add(si.findAllElements('t').map((t) => t.innerText).join());
    }
  }

  // Varaqlar workbook.xml tartibida olinadi (fayl raqami bilan emas)
  final sheetNames = <String>[];
  final sheets = <ArchiveFile>[];

  final workbook = _entryText(archive, 'xl/workbook.xml');
  final rels = _entryText(archive, 'xl/_rels/workbook.xml.rels');
  if (workbook != null && rels != null) {
    final targets = <String, String>{};
    for (final r in _parseXml(rels).findAllElements('Relationship')) {
      final id = r.getAttribute('Id');
      final target = r.getAttribute('Target');
      if (id != null && target != null) targets[id] = target;
    }

    for (final s in _parseXml(workbook).findAllElements('sheet')) {
      final target = targets[s.getAttribute('r:id') ?? ''];
      if (target == null) continue;
      final path = target.startsWith('/')
          ? target.substring(1)
          : p.posix.normalize(p.posix.join('xl', target));
      final file = archive.findFile(path);
      if (file == null) continue;
      sheets.add(file);
      sheetNames.add(s.getAttribute('name') ?? '');
    }
  }

  if (sheets.isEmpty) {
    sheetNames.clear();
    sheets.addAll(_numbered(archive, RegExp(r'^xl/worksheets/sheet\d+\.xml$')));
  }
  final result = <Section>[];

  for (var i = 0; i < sheets.length; i++) {
    final xml = _parseXml(
      utf8.decode(sheets[i].content as List<int>, allowMalformed: true),
    );

    final lines = <String>[];
    for (final row in xml.findAllElements('row')) {
      final cells = <String>[];
      for (final c in row.findElements('c')) {
        final col = _columnIndex(c.getAttribute('r') ?? '');
        final idx = col < 0 ? cells.length : col;
        while (cells.length <= idx) {
          cells.add('');
        }
        cells[idx] = _cellValue(c, shared, dateStyles);
      }
      if (cells.any((c) => c.isNotEmpty)) {
        lines.add(cells.join('\t'));
      }
    }

    final title = i < sheetNames.length && sheetNames[i].isNotEmpty
        ? sheetNames[i]
        : 'Varaq ${i + 1}';
    result.add(Section(title, lines.isEmpty ? ["(bo'sh varaq)"] : lines));
  }

  if (result.isEmpty) {
    throw const FormatException('Jadval varaqlari topilmadi');
  }

  final pictures = <String>[];
  for (final f in archive.files) {
    if (!f.isFile || !f.name.startsWith('xl/media/')) continue;
    final line = media.line(archive, f.name);
    if (line != null) pictures.add(line);
  }
  if (pictures.isNotEmpty) result.add(Section('Rasmlar', pictures));
  return result;
}

int _columnIndex(String ref) {
  var n = 0;
  for (final ch in ref.codeUnits) {
    if (ch < 65 || ch > 90) break;
    n = n * 26 + (ch - 64);
  }
  return n - 1;
}

String _cellValue(XmlElement c, List<String> shared, Set<int> dateStyles) {
  switch (c.getAttribute('t')) {
    case 's':
      final i = int.tryParse(_childText(c, 'v'));
      return (i != null && i >= 0 && i < shared.length) ? shared[i] : '';
    case 'b':
      return _childText(c, 'v') == '1' ? 'TRUE' : 'FALSE';
    case 'inlineStr':
      return c.findAllElements('t').map((t) => t.innerText).join();
    default:
      final raw = _childText(c, 'v');
      final style = int.tryParse(c.getAttribute('s') ?? '');
      if (raw.isNotEmpty && style != null && dateStyles.contains(style)) {
        return _excelDate(raw);
      }
      return raw;
  }
}

/// Sana ko'rinishidagi katak uslublarining raqamlarini topadi.
Set<int> _dateStyles(Archive archive) {
  final xml = _entryText(archive, 'xl/styles.xml');
  final result = <int>{};
  if (xml == null) return result;

  try {
    final doc = _parseXml(xml);

    final customDates = <int>{};
    for (final nf in doc.findAllElements('numFmt')) {
      final id = int.tryParse(nf.getAttribute('numFmtId') ?? '');
      final code = (nf.getAttribute('formatCode') ?? '').toLowerCase();
      if (id != null && _looksLikeDateFormat(code)) customDates.add(id);
    }

    final cellXfs = doc.findAllElements('cellXfs');
    if (cellXfs.isEmpty) return result;

    var index = 0;
    for (final xf in cellXfs.first.findElements('xf')) {
      final id = int.tryParse(xf.getAttribute('numFmtId') ?? '') ?? 0;
      final builtin = (id >= 14 && id <= 22) || (id >= 45 && id <= 47);
      if (builtin || customDates.contains(id)) result.add(index);
      index++;
    }
  } catch (_) {
    // Uslublar o'qilmasa, sanalar oddiy raqam ko'rinishida chiqadi
  }
  return result;
}

bool _looksLikeDateFormat(String code) {
  final cleaned = code
      .replaceAll(RegExp(r'"[^"]*"'), '')
      .replaceAll(RegExp(r'\[[^\]]*\]'), '')
      .replaceAll(RegExp(r'\\.'), '');
  return RegExp(r'[dmyhs]').hasMatch(cleaned);
}

String _excelDate(String raw) {
  final value = double.tryParse(raw);
  if (value == null || value < 0 || value > 2958465) return raw;

  final days = value.floor();
  final seconds = ((value - days) * 86400).round();
  final date = DateTime.utc(1899, 12, 30).add(
    Duration(days: days, seconds: seconds),
  );

  String two(int n) => n.toString().padLeft(2, '0');
  final day = '${two(date.day)}.${two(date.month)}.${date.year}';
  final time = '${two(date.hour)}:${two(date.minute)}';

  if (days == 0) return time;
  if (seconds == 0) return day;
  return '$day $time';
}

// ---------- PPTX ----------

List<Section> _pptxSections(Uint8List bytes, MediaSink media) {
  final archive = _zip(bytes);
  final slides = _numbered(archive, RegExp(r'^ppt/slides/slide\d+\.xml$'));
  if (slides.isEmpty) {
    throw const FormatException('Slaydlar topilmadi');
  }

  final result = <Section>[];
  for (var i = 0; i < slides.length; i++) {
    final xml = _parseXml(
      utf8.decode(slides[i].content as List<int>, allowMalformed: true),
    );
    final lines = [
      for (final para in xml.findAllElements('p')) _paragraphText(para),
    ].where((l) => l.trim().isNotEmpty).toList();

    // Slayddagi rasm, video va audio fayllar
    final slideFile = p.posix.basename(slides[i].name);
    final rels = _relationships(
      archive,
      'ppt/slides/_rels/$slideFile.rels',
      'ppt/slides/',
    );
    for (final entry in rels.values.toSet()) {
      final line = media.line(archive, entry);
      if (line != null) lines.add(line);
    }

    result.add(Section('Slayd ${i + 1}', lines));
  }
  return result;
}

// ---------- EPUB ----------

List<Section> _epubSections(Uint8List bytes, MediaSink media) {
  final archive = _zip(bytes);

  final container = _parseXml(
    _requireEntry(archive, 'META-INF/container.xml'),
  );
  final rootfiles = container.findAllElements('rootfile');
  if (rootfiles.isEmpty) {
    throw const FormatException('ePub: rootfile topilmadi');
  }

  final opfPath = rootfiles.first.getAttribute('full-path') ?? '';
  final baseDir = opfPath.contains('/')
      ? opfPath.substring(0, opfPath.lastIndexOf('/') + 1)
      : '';

  final opf = _parseXml(_requireEntry(archive, opfPath));

  final manifest = <String, String>{};
  for (final item in opf.findAllElements('item')) {
    final id = item.getAttribute('id');
    final href = item.getAttribute('href');
    if (id != null && href != null) manifest[id] = href;
  }

  final result = <Section>[];
  for (final ref in opf.findAllElements('itemref')) {
    final href = manifest[ref.getAttribute('idref')];
    if (href == null) continue;

    final name = p.posix.normalize(
      p.posix.join(baseDir, _unquote(href.split('#').first)),
    );
    final html = _entryText(archive, name);
    if (html == null) continue;

    final chapterDir = p.posix.dirname(name);
    final marked = html.replaceAllMapped(
      RegExp(
        r'<(?:img|image)\b[^>]*?(?:src|href)\s*=\s*[\x22\x27]([^\x22\x27]+)[\x22\x27][^>]*>',
        caseSensitive: false,
      ),
      (m) => '\n$mediaMark$_refTag$mediaSep${m[1]}\n',
    );

    final lines = <String>[];
    for (final line in _htmlLines(marked)) {
      if (!line.startsWith('$mediaMark$_refTag$mediaSep')) {
        lines.add(line);
        continue;
      }
      final src = line.substring(mediaMark.length + _refTag.length + 1);
      final entry = p.posix.normalize(
        p.posix.join(chapterDir, _unquote(src.split('#').first)),
      );
      final resolved = media.line(archive, entry);
      if (resolved != null) lines.add(resolved);
    }
    if (lines.isNotEmpty) {
      result.add(Section('Bob ${result.length + 1}', lines));
    }
  }

  if (result.isEmpty) {
    throw const FormatException("ePub ichida o'qiladigan matn topilmadi");
  }
  return result;
}

String _unquote(String s) {
  try {
    return Uri.decodeFull(s);
  } catch (_) {
    return s;
  }
}

// ---------- Rasm, video va audio ----------

const _imageExt = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp'};
const _videoExt = {
  '.mp4', '.m4v', '.mov', '.avi', '.wmv', '.mpg', '.mpeg', '.webm', '.mkv', '.3gp',
};
const _audioExt = {
  '.mp3', '.wav', '.m4a', '.wma', '.aac', '.ogg', '.oga', '.mid', '.midi', '.flac',
};

/// Media qatori: `\u0001` + tur (IMG, VID, AUD) + `\u0002` + fayl yo'li.
const mediaMark = '\u0001';
const mediaSep = '\u0002';
const _refTag = 'REF';

/// Arxiv ichidagi mediani diskka chiqarib, matn orasiga qo'yiladigan qator beradi.
class MediaSink {
  final String? dir;
  final Map<String, String> _saved = <String, String>{};
  MediaSink(this.dir);

  String? line(Archive archive, String entryName) {
    final base = dir;
    if (base == null) return null;

    final ext = p.posix.extension(entryName).toLowerCase();
    final String tag;
    if (_imageExt.contains(ext)) {
      tag = 'IMG';
    } else if (_videoExt.contains(ext)) {
      tag = 'VID';
    } else if (_audioExt.contains(ext)) {
      tag = 'AUD';
    } else {
      return null;
    }

    var path = _saved[entryName];
    if (path == null) {
      final file = archive.findFile(entryName);
      if (file == null) return null;
      try {
        final data = file.content as List<int>;
        final folder = Directory(base);
        if (!folder.existsSync()) folder.createSync(recursive: true);
        final safe = p.posix
            .basename(entryName)
            .replaceAll(RegExp(r'[\\/:*?"<>|\x00-\x1F]'), '_');
        final out = File(p.join(base, '${_saved.length}_$safe'));
        if (!out.existsSync() || out.lengthSync() != data.length) {
          out.writeAsBytesSync(data);
        }
        path = out.path;
        _saved[entryName] = path;
      } catch (_) {
        return null;
      }
    }
    return '$mediaMark$tag$mediaSep$path';
  }
}

/// "_rels" faylidagi bog'lanishlar: id -> arxiv ichidagi to'liq nom.
Map<String, String> _relationships(
  Archive archive,
  String relsName,
  String baseDir,
) {
  final map = <String, String>{};
  final xml = _entryText(archive, relsName);
  if (xml == null) return map;
  try {
    for (final r in _parseXml(xml).findAllElements('Relationship')) {
      final id = r.getAttribute('Id');
      final target = r.getAttribute('Target');
      if (id == null || target == null) continue;
      if (r.getAttribute('TargetMode') == 'External') continue;
      map[id] = target.startsWith('/')
          ? target.substring(1)
          : p.posix.normalize(p.posix.join(baseDir, _unquote(target)));
    }
  } catch (_) {
    // Buzilgan bog'lanishlar mediani o'tkazib yuboradi, matn o'qilaveradi
  }
  return map;
}

String? _attrByLocal(XmlElement e, String local) {
  for (final a in e.attributes) {
    if (a.name.local == local) return a.value;
  }
  return null;
}

// ---------- HTML / XHTML ----------

List<String> _htmlLines(String html) {
  var s = html
      .replaceAll(
        RegExp(r'<(script|style|head)[^>]*>[\s\S]*?</\1>', caseSensitive: false),
        '',
      )
      .replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n')
      .replaceAll(
        RegExp(
          r'</?(p|div|h[1-6]|li|tr|section|blockquote)[^>]*>',
          caseSensitive: false,
        ),
        '\n',
      )
      .replaceAll(RegExp(r'<[^>]+>'), '');

  s = _decodeEntities(s);

  return s
      .split('\n')
      .map((l) => l.replaceAll(RegExp(r'\s+'), ' ').trim())
      .where((l) => l.isNotEmpty)
      .toList();
}

const _namedEntities = <String, String>{
  'amp': '&',
  'lt': '<',
  'gt': '>',
  'quot': '"',
  'apos': "'",
  'nbsp': ' ',
  'mdash': '—',
  'ndash': '–',
  'laquo': '«',
  'raquo': '»',
  'hellip': '…',
};

String _decodeEntities(String s) {
  return s.replaceAllMapped(
    RegExp(r'&(#x[0-9a-fA-F]+|#[0-9]+|[a-zA-Z]+);'),
    (m) {
      final e = m.group(1)!;
      if (e.startsWith('#')) {
        final code = e.startsWith('#x')
            ? int.tryParse(e.substring(2), radix: 16)
            : int.tryParse(e.substring(1));
        if (code == null || code <= 0 || code > 0x10FFFF) return m.group(0)!;
        return String.fromCharCode(code);
      }
      return _namedEntities[e] ?? m.group(0)!;
    },
  );
}

// ---------- Boshqa fayllar (office_model.dart) uchun ochiq yordamchilar ----------

XmlDocument parseOfficeXml(String xml) => _parseXml(xml);
Archive openZip(Uint8List bytes) => _zip(bytes);
String? zipText(Archive archive, String name) => _entryText(archive, name);
Map<String, String> zipRelationships(
  Archive archive,
  String relsName,
  String baseDir,
) =>
    _relationships(archive, relsName, baseDir);
String? xmlAttr(XmlElement e, String local) => _attrByLocal(e, local);
String xmlParagraphText(XmlElement para) => _paragraphText(para);
