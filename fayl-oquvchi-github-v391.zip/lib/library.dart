import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

class LibraryItem {
  final File file;
  final int size;
  final DateTime modified;

  const LibraryItem(this.file, this.size, this.modified);

  /// Kutubxonadagi noyob kalit (vaqt belgisi bilan fayl nomi).
  String get key => p.basename(file.path);

  String get name => Library.displayName(file.path);
}

class Library {
  Library._();

  static Future<Directory> _dir() async {
    final base = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(base.path, 'library'));
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir;
  }

  static int _lastStamp = 0;

  /// Har safar oldingisidan katta bo'lgan vaqt belgisi (bir millisekundda
  /// qo'shilgan fayllar bir-birini ustidan yozib yubormasligi uchun).
  static int _nextStamp() {
    var stamp = DateTime.now().millisecondsSinceEpoch;
    if (stamp <= _lastStamp) stamp = _lastStamp + 1;
    _lastStamp = stamp;
    return stamp;
  }

  static Future<Directory> directory() => _dir();

  /// Fayl kutubxona papkasidami (vaqtinchalik kesh emasmi).
  static bool isInLibrary(String path) =>
      p.basename(p.dirname(path)) == 'library';

  static Future<File> importFile(String sourcePath) async {
    final dir = await _dir();
    final stamp = _nextStamp();
    final dest = p.join(dir.path, '${stamp}_${p.basename(sourcePath)}');
    return File(sourcePath).copy(dest);
  }

  static Future<List<LibraryItem>> list() async {
    final dir = await _dir();
    final items = <LibraryItem>[];

    await for (final entity in dir.list()) {
      if (entity is! File) continue;
      final stat = await entity.stat();
      items.add(LibraryItem(entity, stat.size, stat.modified));
    }

    items.sort((a, b) => b.modified.compareTo(a.modified));
    return items;
  }

  static Future<int> totalSize() async {
    final items = await list();
    var total = 0;
    for (final item in items) {
      total += item.size;
    }
    return total;
  }

  /// Faylni qayta nomlaydi. Vaqt belgisi (prefiks) saqlanadi.
  static Future<File> rename(File file, String newName) async {
    final clean =
        newName.replaceAll(RegExp(r'[\\/:*?"<>|\x00-\x1F]'), '_').trim();
    if (clean.isEmpty) {
      throw const FormatException("Fayl nomi bo'sh bo'lmasligi kerak");
    }

    final prefix =
        RegExp(r'^\d+_').firstMatch(p.basename(file.path))?.group(0) ?? '';

    var finalName = clean;
    final oldExt = p.extension(displayName(file.path));
    if (p.extension(clean).isEmpty && oldExt.isNotEmpty) {
      finalName = '$clean$oldExt';
    }

    final dest = p.join(file.parent.path, '$prefix$finalName');
    if (dest == file.path) return file;
    if (await File(dest).exists()) {
      throw const FormatException('Bunday nomli fayl allaqachon mavjud');
    }
    return file.rename(dest);
  }

  static String displayName(String path) =>
      p.basename(path).replaceFirst(RegExp(r'^\d+_'), '');
}

String formatSize(int bytes) {
  if (bytes < 1024) return '$bytes B';
  if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
  return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
}

String formatDate(DateTime d) =>
    '${_two(d.day)}.${_two(d.month)}.${d.year} ${_two(d.hour)}:${_two(d.minute)}';

String _two(int n) => n.toString().padLeft(2, '0');
