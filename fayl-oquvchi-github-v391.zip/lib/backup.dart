import 'dart:convert';
import 'dart:io';
import 'dart:isolate';

import 'package:archive/archive.dart';
import 'package:archive/archive_io.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'library.dart';

/// Zaxira nusxa: kutubxonadagi fayllar va xatcho'plar, sevimlilar, papkalar,
/// sozlamalar bitta ZIP faylga yig'iladi. PIN kod zaxiraga kiritilmaydi.
class Backup {
  Backup._();

  static const _metaName = 'backup_meta.json';
  static const _filesPrefix = 'files/';

  static String _stamp() {
    final d = DateTime.now();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${d.year}${two(d.month)}${two(d.day)}_${two(d.hour)}${two(d.minute)}';
  }

  // ---------- Yaratish ----------

  static Future<File> create() async {
    final prefs = await SharedPreferences.getInstance();
    final data = <String, Object?>{};

    for (final key in prefs.getKeys()) {
      if (key.startsWith('lock')) continue;
      final value = prefs.get(key);
      if (value is String) {
        data[key] = <String, Object?>{'t': 's', 'v': value};
      } else if (value is int) {
        data[key] = <String, Object?>{'t': 'i', 'v': value};
      } else if (value is double) {
        data[key] = <String, Object?>{'t': 'd', 'v': value};
      } else if (value is bool) {
        data[key] = <String, Object?>{'t': 'b', 'v': value};
      } else if (value is List) {
        final list = prefs.getStringList(key);
        if (list != null) data[key] = <String, Object?>{'t': 'l', 'v': list};
      }
    }

    final tmp = await getTemporaryDirectory();
    final metaFile = File(p.join(tmp.path, _metaName));
    await metaFile.writeAsString(
      jsonEncode(<String, Object?>{'version': 1, 'prefs': data}),
    );

    final library = await Library.directory();
    final outPath = p.join(tmp.path, 'FaylOquvchi_zaxira_${_stamp()}.zip');
    final metaPath = metaFile.path;
    final libraryPath = library.path;

    await Isolate.run(() => _zipAll(outPath, metaPath, libraryPath));
    return File(outPath);
  }

  /// archive paketining versiyasiga qarab ZipFileEncoder metodlari sinxron yoki
  /// asinxron bo'lishi mumkin, shuning uchun `dynamic` orqali ikkalasi ham
  /// kutib olinadi (fayl yarim yozilib qolmasligi uchun).
  static Future<void> _zipAll(
    String outPath,
    String metaPath,
    String libraryPath,
  ) async {
    final dynamic encoder = ZipFileEncoder();
    await encoder.create(outPath);
    try {
      await encoder.addFile(File(metaPath), _metaName);
      for (final entity in Directory(libraryPath).listSync()) {
        if (entity is File) {
          await encoder.addFile(
            entity,
            '$_filesPrefix${p.basename(entity.path)}',
          );
        }
      }
    } finally {
      await encoder.close();
    }
  }

  // ---------- Tiklash ----------

  /// Zaxiradan tiklaydi va qo'shilgan fayllar sonini qaytaradi.
  static Future<int> restore(String zipPath) async {
    final library = await Library.directory();
    final libraryPath = library.path;

    final result = await Isolate.run(() => _unzipSync(zipPath, libraryPath));
    final meta = result[0] as String?;
    final count = result[1] as int;

    if (meta == null) {
      throw const FormatException('Bu zaxira fayli emas');
    }

    final decoded = jsonDecode(meta);
    if (decoded is! Map || decoded['prefs'] is! Map) {
      throw const FormatException('Zaxira fayli buzilgan');
    }

    final prefs = await SharedPreferences.getInstance();
    final saved = decoded['prefs'] as Map;

    for (final entry in saved.entries) {
      final key = entry.key;
      final item = entry.value;
      if (key is! String || key.startsWith('lock') || item is! Map) continue;

      final value = item['v'];
      try {
        switch (item['t']) {
          case 's':
            if (value is String) await prefs.setString(key, value);
            break;
          case 'i':
            if (value is int) await prefs.setInt(key, value);
            break;
          case 'd':
            if (value is num) await prefs.setDouble(key, value.toDouble());
            break;
          case 'b':
            if (value is bool) await prefs.setBool(key, value);
            break;
          case 'l':
            if (value is List) {
              await prefs.setStringList(
                key,
                [for (final v in value) v.toString()],
              );
            }
            break;
        }
      } catch (_) {
        // Bitta qiymatni tiklab bo'lmasa, qolganlari davom ettiriladi
      }
    }

    return count;
  }

  static List<Object?> _unzipSync(String zipPath, String libraryPath) {
    final input = InputFileStream(zipPath);
    try {
      final archive = ZipDecoder().decodeBuffer(input);
      String? meta;
      var count = 0;

      for (final file in archive.files) {
        if (!file.isFile) continue;

        if (file.name == _metaName) {
          meta = utf8.decode(file.content as List<int>, allowMalformed: true);
          continue;
        }
        if (!file.name.startsWith(_filesPrefix)) continue;

        // Faqat fayl nomi olinadi: "../" orqali tashqariga chiqishni oldini oladi
        final name = p.posix.basename(file.name);
        if (name.isEmpty) continue;

        final dest = File(p.join(libraryPath, name));
        if (dest.existsSync()) continue;

        dest.writeAsBytesSync(file.content as List<int>);
        count++;
      }
      return <Object?>[meta, count];
    } finally {
      input.close();
    }
  }
}
