package uz.reader.cleanpdf

import io.flutter.embedding.android.FlutterFragmentActivity

// local_auth (barmoq izi) FragmentActivity talab qiladi
class MainActivity : FlutterFragmentActivity()
