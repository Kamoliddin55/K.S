# Maxfiylik siyosati - Fayl O'quvchi

Oxirgi yangilanish: 2026-yil 30-oktabr

Fayl O'quvchi ilovasi sizning shaxsiy ma'lumotlaringizni yig'maydi, uzatmaydi
va sotmaydi.

- **Internet:** ilova internetga ulanish ruxsatini so'ramaydi va hech qanday
  ma'lumotni tarmoq orqali yubormaydi.
- **Fayllar:** siz tanlagan fayllar faqat telefoningizdagi ilova xotirasida
  saqlanadi. Ilovani o'chirsangiz, ular ham o'chadi.
- **Reklama va kuzatuv:** reklama, tahlil (analytics) va kuzatuv vositalari yo'q.
- **PIN kod:** PIN tasodifiy tuz bilan xeshlanib, faqat qurilmada saqlanadi.
  Barmoq izi tekshiruvini Android tizimi bajaradi; ilova biometrik ma'lumotni
  olmaydi.
- **Zaxira nusxa:** faqat siz so'rasangiz yaratiladi va qayerga saqlashni o'zingiz
  tanlaysiz. PIN kod zaxiraga kiritilmaydi.
- **Ovoz chiqarish:** telefondagi ovoz dvigateli ishlatiladi.

Savollar uchun: ksamiyev10@gmail.com
