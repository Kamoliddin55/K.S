import 'package:clean_pdf_reader/xlsx_model.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('ustun nomlari', () {
    expect(columnName(0), 'A');
    expect(columnName(25), 'Z');
    expect(columnName(26), 'AA');
    expect(columnName(27), 'AB');
    expect(cellAddress(2, 1), 'B3');
  });

  test('raqam formatlari', () {
    expect(formatNumber(1234.5, '#,##0.00'), '1,234.50');
    expect(formatNumber(0.256, '0.0%'), '25.6%');
    expect(formatNumber(5, '0'), '5');
    expect(formatNumber(-5, '0;(0)'), '(5)');
    expect(formatNumber(1.5, 'General'), '1.5');
    expect(formatNumber(100, 'General'), '100');
  });

  test('sana formatlari', () {
    expect(formatNumber(45000, 'dd.mm.yyyy'), '15.03.2023');
    expect(formatNumber(0.5, 'h:mm AM/PM'), '12:00 PM');
  });
}
