# Fayl O'quvchi (clean_pdf_reader)

Reklamasiz fayl o'quvchi (Flutter, Android).

## GitHub orqali APK yig'ish
1. Yangi repozitoriy yarating va ushbu papkadagi hamma narsani yuklang (push).
2. GitHub → **Actions** → **Build APK** → **Run workflow**.
3. Tugagach, **Artifacts** ichidan `fayl-oquvchi-apk` ni yuklab oling.

## Mahalliy ishga tushirish
    flutter create --org uz.reader --project-name clean_pdf_reader .
    flutter pub get && flutter run

## v3.8 yangiliklari
- **Excel (.xlsx)** — haqiqiy katak jadvali: A, B, C… ustun va 1, 2, 3… qator sarlavhalari, ustun kengligi/qator balandligi, birlashgan kataklar, shrift/rang/fon/chegara, raqam va sana formatlari, qotirilgan qator/ustunlar, varaq yorliqlari, formula satri, qidiruv, masshtab.
- **Word (.docx)** — sahifa ko'rinishi (qog'oz) va mobil ko'rinish: sarlavhalar, qalin/kursiv/rangli matn, ro'yxatlar, jadvallar (chegara va fon), rasmlar, matn qutilari, mundarija, qidiruv, masshtab.
- **PDF** — sahifa chizg'ichi, birinchi/oxirgi sahifa, uzluksiz varaqlash rejimi.

## v3.9 yangiliklari
- **PowerPoint (.pptx)** — slaydlar haqiqiy ko'rinishda: shakllar, fon va gradient, matn (qalin/kursiv/rang/o'lcham, ro'yxatlar), rasmlar, jadvallar, guruhlangan shakllar, shablon (layout/master) elementlari. Slaydni bosib namoyish rejimiga o'tiladi (surish, kattalashtirish). Video va audio fayllar slayd tagida chiqadi.
